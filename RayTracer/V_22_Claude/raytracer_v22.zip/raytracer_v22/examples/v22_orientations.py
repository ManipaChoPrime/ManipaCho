"""V2.2 : étude complète des 8 orientations de la chaîne
AC254-040-B -> ACN254-040-B -> AC254-080-B (ou de la chaîne V2.1 avec --preset v21).

    python examples/v22_orientations.py [--preset v22|v21]

Pour CHAQUE configuration, la position de fibre est réoptimisée deux fois,
indépendamment (rien n'est repris de la V2.1) :
  d_div : minimum de la divergence radiale RMS (puissance) en sortie ;
  d_opd : minimum de l'OPD RMS (puissance, référence plane 1 mm après L2).
Les grandeurs sont ensuite calculées avec 2401 rayons. Sortie : tableau texte
+ JSON (v22_orientations_<preset>.json) relu par v22_analysis.py.
"""

import itertools
import json
import os
import sys
import warnings

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import chain  # noqa: E402
import study  # noqa: E402

warnings.simplefilter("ignore")
preset = "v22"
if "--preset" in sys.argv:
    preset = sys.argv[sys.argv.index("--preset") + 1]
chain.FORCE_STANDIN = False
LAM = 1.03e-3
OUT = []


def say(s=""):
    print(s, flush=True)
    OUT.append(s)


src_opt = chain.make_source(n_rays=401)
src = chain.make_source(n_rays=2401)
records = []
lab = lambda f: "R" if f else "D"          # R = retournée (flip=True), D = sens du dessin

say(f"Chaîne {preset} : {chain.PRESETS[preset]['collimator']} -> {chain.PRESETS[preset]['l1']} -> "
    f"{chain.PRESETS[preset]['l2']}   (D = sens du dessin, R = retournée)")
hdr = (f"{'cfg':>5} | {'d_div':>7}{'θrad':>7}{'σθx':>7}{'D1e2':>7}{'D4σ':>7}{'Dfit':>7}{'T':>8}"
       f" | {'d_opd':>7}{'fibre':>8}{'OPD':>7}{'PV':>7}{'R_déf':>9}{'OPDsd':>7}{'S':>7}{'Ssd':>7}{'M²*':>7}")
say(hdr)
say(f"{'':>5} | {'mm':>7}{'µrad':>7}{'µrad':>7}{'mm':>7}{'mm':>7}{'mm':>7}{'':>8}"
    f" | {'mm':>7}{'mm':>8}{'λ':>7}{'λ':>7}{'m':>9}{'λ':>7}{'':>7}{'':>7}{'':>7}")
for fc, f1, f2 in itertools.product((False, True), repeat=3):
    chain.set_preset(preset, flip_collimator=fc, flip_l1=f1, flip_l2=f2)
    d_div, d_opd = study.optimize(src_opt)
    a = study.evaluate(d_div, src)
    b = study.evaluate(d_opd, src)
    rec = dict(
        cfg=[fc, f1, f2], label=lab(fc) + lab(f1) + lab(f2),
        d_div=d_div, d_opd=d_opd, fiber_to_vertex_div=a["fiber_to_vertex"],
        fiber_to_vertex_opd=b["fiber_to_vertex"], z_out=b["z_out"], z_out_rel=b["z_out_rel"],
        # à d_div
        theta_rms_radial=a["theta_rms_radial"], sigma_theta_x=a["sigma_theta_x"],
        mean_radial=a["b_out"].mean_radial_angle,
        D_in_1e2=a["b_in"].d_1e2_markers, D_in_4s=a["b_in"].d4sigma, D_in_fit=a["b_in"].d_fit,
        D_out_1e2=a["b_out"].d_1e2_markers, D_out_4s=a["b_out"].d4sigma, D_out_fit=a["b_out"].d_fit,
        T_div=a["T"], strehl_div=a["strehl"], opd_rms_div=a["opd_rms"],
        # à d_opd
        T=b["T"], loss_by_element=b["loss_by_element"],
        surface_losses=[dict(i=e.index, el=e.element, p_inc=e.p_incident, p_lost=e.p_lost,
                             t=e.t_fraction, d4s=e.d4sigma, d1e2=e.d_1e2,
                             t_an=(e.t_analytic if e.analytic_valid else None), note=e.note)
                        for e in b["surfaces"]],
        opd_rms=b["opd_rms"], opd_rms_area=b["opd_rms_area"], opd_pv=b["opd_pv"],
        c2=b["c2"], R_defocus=b["R_defocus"], opd_rms_nodefocus=b["opd_rms_nodefocus"],
        opd_pv_nodefocus=b["opd_pv_nodefocus"], strehl=b["strehl"],
        strehl_nodefocus=b["strehl_nodefocus"], strehl_valid=b["strehl_valid"],
        sigma_theta_x_opd=b["sigma_theta_x"], sigma_amp=b["fm"].sigma_theta_amp,
        sigma_total=b["fm"].sigma_theta, m2=b["fm"].m2, hard_edge=b["fm"].hard_edge,
    )
    records.append(rec)
    say(f"{rec['label']:>5} | {d_div:>+7.3f}{a['theta_rms_radial'] * 1e6:>7.1f}{a['sigma_theta_x'] * 1e6:>7.1f}"
        f"{rec['D_out_1e2']:>7.2f}{rec['D_out_4s']:>7.2f}{rec['D_out_fit']:>7.2f}{a['T']:>8.4f}"
        f" | {d_opd:>+7.3f}{b['fiber_to_vertex']:>8.3f}{b['opd_rms'] / LAM:>7.3f}{b['opd_pv'] / LAM:>7.3f}"
        f"{b['R_defocus'] / 1e3:>9.1f}{b['opd_rms_nodefocus'] / LAM:>7.3f}{b['strehl']:>7.3f}"
        f"{b['strehl_nodefocus']:>7.3f}{b['fm'].m2:>7.3f}{'' if b['strehl_valid'] else ' (S non valide)'}")

say("\nd_div / d_opd : défocus fibre (mm) vs foyer objet paraxial ; fibre = distance fibre -> 1er sommet"
    " (à d_opd). θrad = divergence radiale RMS ; σθx = RMS par axe (= θrad/√2) ; diamètres à 1 mm"
    " après L2 (A : marqueurs ±θ0, B : D4σ ISO, C : ajustement gaussien). OPD, PV, S : référence plane"
    " 1 mm après L2 ; R_déf = rayon de courbure du défocus résiduel (m) ; OPDsd, Ssd : référence"
    " sphérique ajustée. M²* : seconds moments du champ, bord dur exclu.")
for key, name, sign in (("strehl", "Strehl (fibre à d_opd)", -1), ("opd_rms", "OPD RMS", 1),
                        ("sigma_theta_x", "σθx (fibre à d_div)", 1), ("T", "transmission", -1)):
    order = sorted(records, key=lambda r: sign * r[key])
    say(f"Classement {name:<24}: " + " > ".join(f"{r['label']}({r[key] / (LAM if key == 'opd_rms' else 1e-6 if key == 'sigma_theta_x' else 1):.3g})"
                                                 for r in order))

with open(os.path.join(HERE, f"v22_orientations_{preset}.json"), "w") as fh:
    json.dump(records, fh, indent=1, default=float)
with open(os.path.join(HERE, f"v22_orientations_{preset}_report.txt"), "w") as fh:
    fh.write("\n".join(OUT) + "\n")
