"""Évaluation complète d'une configuration de chaîne (V2.2), partagée par les
scripts d'étude. Aucune donnée optique ici : tout vient de chain.py / lens_data.py.

Plans et références (identiques pour toutes les configurations) :
  * plan "avant expander" : 1 mm avant le 1er sommet de L1 ;
  * plan de sortie / référence du front d'onde : 1 mm après le dernier sommet
    de L2 (z_out, donné en absolu et relatif) ;
  * OPD : référence plane en z_out ; défocus résiduel exprimé par le rayon de
    courbure R = 1/(2 c2) ; "hors défocus" = référence sphérique ajustée
    (best_sphere_wavefront, intersection exacte des rayons avec la sphère).
Position de fibre : `defocus` = décalage par rapport au foyer objet paraxial
du collimateur (< 0 : fibre plus proche de la lentille) ; distance absolue
fibre -> 1er sommet = FFD_collimateur + defocus.
"""

from __future__ import annotations

import numpy as np

import chain
from optical_sim import (paraxial, beam_stats, wavefront, best_sphere_wavefront, defocus_radius,
                         field_moments, surface_power_report, weighted_transmission)


def evaluate(defocus: float, source, z_out_offset: float = 1.0) -> dict:
    """Toutes les grandeurs d'une configuration pour une position de fibre donnée."""
    lam = chain.CONFIG["wavelength"]
    c = chain.build_chain(defocus)
    full = c["full"]
    rays = full.trace(source.generate_rays())
    z_out = c["l2"].z_back + z_out_offset
    z_in = c["l1"].z_front - 1.0
    b_in = beam_stats(rays, z_in, source)
    b_out = beam_stats(rays, z_out, source)
    wf = wavefront(rays, lam, "plane", z_ref=z_out)
    wfs = best_sphere_wavefront(rays, lam, z_out)
    fm = field_moments(wf)
    rep = surface_power_report(full, rays, source)
    v = wf.validity()
    ffd = paraxial.cardinal(c["coll"].surfaces)["FFD"]
    return dict(
        defocus=defocus, fiber_to_vertex=ffd + defocus, z_out=z_out,
        z_out_rel=z_out - c["l2"].z_back, chain=c, rays=rays,
        T=weighted_transmission(rays), surfaces=rep,
        loss_by_element={el.name: sum(e.p_lost for e in rep if e.element == el.name)
                         for el in full.elements},
        b_in=b_in, b_out=b_out,
        sigma_theta_x=b_out.sigma_theta_x, theta_rms_radial=b_out.theta_rms,
        opd_rms=wf.rms("power"), opd_rms_area=wf.rms("area"), opd_pv=wf.pv,
        c2=wf.defocus_fit()[1], R_defocus=defocus_radius(wf),
        opd_rms_nodefocus=wfs.rms("power"), opd_pv_nodefocus=wfs.pv,
        strehl=wf.strehl_direct(), strehl_nodefocus=wfs.strehl_direct(),
        strehl_marechal=wf.strehl_marechal(), strehl_valid=v["direct_ok"],
        marechal_valid=v["marechal_ok"], fm=fm, wf=wf, wfs=wfs,
    )


def optimize(source_opt):
    """Positions de fibre optimales (divergence / OPD) pour la configuration courante."""
    d_div, v_div = chain.best_defocus(source=source_opt, target="chain")
    d_opd, v_opd = chain.best_defocus(source=source_opt, target="chain_opd")
    return d_div, d_opd


def expander_paraxial() -> dict:
    """Grandeurs paraxiales du beam expander (L1 au z = 0)."""
    exp_sys, l1, l2, gap = chain.build_expander(0.0)
    f = chain.expander_figures(exp_sys, l1, l2, gap)
    c1, c2 = paraxial.cardinal(l1.surfaces), paraxial.cardinal(l2.surfaces)
    f.update(
        exp_sys=exp_sys, l1=l1, l2=l2,
        H1_from_L1_front=c1["z_H_object"] - l1.z_front, H1p_from_L1_back=c1["z_H_image"] - l1.z_back,
        H2_from_L2_front=c2["z_H_object"] - l2.z_front, H2p_from_L2_back=c2["z_H_image"] - l2.z_back,
        bfd1=c1["BFD"], ffd2=c2["FFD"],
    )
    return f


# ---------------------------------------------------------------------------
# Décomposition exacte de l'OPD : collimateur | beam expander
# ---------------------------------------------------------------------------
def opl_at_z(ray, z: float) -> float:
    """OPL du départ jusqu'au plan z (segment traversant ce plan, interpolé)."""
    h = ray.history
    acc = 0.0
    for k in range(1, len(h)):
        z0, z1 = h[k - 1].position[1], h[k].position[1]
        if min(z0, z1) <= z <= max(z0, z1) and z1 != z0:
            return acc + h[k].n_segment * h[k].distance * (z - z0) / (z1 - z0)
        acc += h[k].n_segment * h[k].distance
    raise ValueError("le rayon ne traverse pas ce plan")


def remove_defocus(wf, opd):
    """Résidu de opd après ajustement c0 + c2 r² (poids puissance)."""
    r2 = wf.x**2
    W = np.sqrt(wf.power)
    A = np.vstack([np.ones_like(r2), r2]).T
    coef, *_ = np.linalg.lstsq(A * W[:, None], opd * W, rcond=None)
    return opd - A @ coef


def opd_split(wf, z_mid: float) -> dict:
    """Pour chaque rayon du front d'onde wf (sortie de chaîne) :
        OPD_chain = OPD_coll + OPD_exp   (EXACT, par additivité de l'OPL le long du rayon)
    OPD_coll = OPL(source -> plan z_mid) - idem rayon axial   (z_mid : entre collimateur et L1)
    OPD_exp  = OPL(plan z_mid -> référence) - idem rayon axial
    """
    i0 = int(np.argmin(np.abs(wf.theta_source)))
    o_mid = np.array([opl_at_z(r, z_mid) for r in wf.rays])
    coll = o_mid - o_mid[i0]
    exp = (wf.opl - o_mid) - (wf.opl[i0] - o_mid[i0])
    return dict(coll=coll, exp=exp, total=coll + exp, check=np.max(np.abs(coll + exp - wf.opd)))
