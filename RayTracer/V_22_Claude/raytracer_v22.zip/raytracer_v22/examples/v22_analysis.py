"""V2.2 : étude complète de la chaîne AC254-040-B -> ACN254-040-B -> AC254-080-B à 1030 nm,
et comparaison avec la chaîne V2.1 (AC254-040-B -> ACN127-030-B -> AC254-060-B).

    python examples/v22_orientations.py --preset v22     # d'abord (≈ 30 min)
    python examples/v22_analysis.py

Toutes les grandeurs sont RECALCULÉES (aucune valeur de la V2.1 n'est reprise).
Produit v22_report.txt, des figures PNG et l'export du champ (v22_field_*.npz / .csv).
"""

import json
import os
import sys
import warnings

import numpy as np
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import chain  # noqa: E402
import lens_data  # noqa: E402
import study  # noqa: E402
from optical_sim import (paraxial, CollimatedSource, wavefront, best_sphere_wavefront,  # noqa: E402
                         defocus_radius, field_moments, radial_field, field_grid, strehl_grid,
                         beam_stats, surface_power_report, weighted_transmission, plot_rays,
                         Lens)

warnings.simplefilter("ignore")
chain.FORCE_STANDIN = False
LAM = 1.03e-3
OUT = []


def say(s=""):
    print(s, flush=True)
    OUT.append(s)


def lam(x):
    return x / LAM


lab = lambda cfg: "".join("R" if f else "D" for f in cfg)
SRC = chain.make_source(n_rays=2401)
SRC_OPT = chain.make_source(n_rays=401)

say("=" * 104)
say("V2.2 — chaîne fibre → AC254-040-B → ACN254-040-B → AC254-080-B, λ0 = 1030 nm (optique géométrique)")
say("=" * 104)

# ============================================================================
# 0. Conventions et corrections explicites
# ============================================================================
say("""
0. CONVENTIONS (inchangées depuis la V2.1) ET CORRECTIONS
   Gaussienne d'intensité I ∝ exp(-2r²/w²) : w = rayon 1/e² ; D(1/e²) = 2w ;
   <r²> = w²/2 ; σx = sqrt(<x²>) = w/2 ; D4σ = 4σx = 2w.
   Champ lointain : demi-angle 1/e² θ = λ/(π w0) ; RMS par axe σθx = θ/2 = λ/(2π w0) ;
   RMS radiale sqrt(<θr²>) = √2 σθx = θ/√2 ; M² = (4π/λ) σx σθx  (= 1 pour une gaussienne).
   Divergence géométrique : σθx = sqrt(<sin²θr>/2) (rayons, poids puissance).
   Divergence de diffraction du profil : σθ,amp² = (1/k²)·½∫A'(r)² dA / P ; totale
   σθ² = σθ,geo² + σθ,amp² (exact : |∂E/∂x|² = A'² + A²(∂φ/∂x)², ∂φ/∂x = k sinθx).
   Corrections V2.2 :
   * rayon « axial » : linspace donnait ±1e-17 au lieu de 0 ; la source lui attribuait le
     disque central entier, le front d'onde une demi-couronne -> intensité doublée pour CE
     rayon (et OPL_ref par extrapolation au lieu du rayon chef). Effet sur la V2.1 : un rayon
     sur 2401 ; vérifié ci-dessous en recalculant la chaîne V2.1 (section 9).
   * σθx (par axe) et θrms radial diffèrent de √2 ; V1.5 utilisait des poids I(θ) qui ne
     sont pas des puissances : ses « θ_rms » ne sont comparables à rien après la V2.1.
   * Strehl : poids de chaque rayon = A·dA = √(P·dA). Il se réduit à « √P » seulement pour
     des cellules d'aire égale ; contrôle indépendant par grille cartésienne uniforme.""")

# ============================================================================
# 1. Prescriptions et géométrie
# ============================================================================
say("\n1. PRESCRIPTIONS À 1030 nm (indices lus dans la table des verres)")
say(f"   {'lentille':<16}{'orient.':>8}{'EFL':>9}{'nom.':>7}{'écart':>8}{'BFD':>9}{'nom.':>7}{'écart':>8}"
    f"{'FFD':>9}{'bord Ø25.4':>11}{'cat.':>6}")
for key in ("AC254-040-B-ML", "ACN254-040-B", "AC254-080-B"):
    d = lens_data.LENSES[key]
    n1, n2 = lens_data.lens_indices(key)
    for flip in (False, True):
        c = paraxial.cardinal(lens_data.build_lens(key, flip=flip).surfaces)
        L = Lens([d["R1"], d["R2"], d["R3"]], [d["tc1"], d["tc2"]], [n1, n2], aperture=d["diameter"])
        say(f"   {key:<16}{'R' if flip else 'D':>8}{c['EFL']:>9.3f}{d['efl_nominal']:>7.1f}"
            f"{100 * (c['EFL'] / d['efl_nominal'] - 1):>+7.2f}%{c['BFD']:>9.3f}"
            f"{d['bfl_nominal']:>7.1f}{c['BFD'] - d['bfl_nominal']:>+8.3f}{c['FFD']:>9.3f}"
            f"{sum(L.edge_thicknesses()):>11.3f}{d['edge_thickness_ref']:>6.1f}")
    say(f"   {'':<16}verres {d['glass1']} (n = {n1}) / {d['glass2']} (n = {n2})"
        + (f" ; NOTE bord : {d['edge_thickness_note']}" if d.get("edge_thickness_note") else ""))
say("   D = sens du dessin (R1 face à la source), R = retournée. BFL nominale comparée au sens D.")

# ============================================================================
# 2. Résultats de l'étude d'orientation
# ============================================================================
rec_path = os.path.join(HERE, "v22_orientations_v22.json")
records = json.load(open(rec_path))
best = max(records, key=lambda r: r["strehl"])
say("\n2. ORIENTATIONS (détail : v22_orientations_v22_report.txt ; fibre réoptimisée pour chacune)")
say(f"   {'cfg':>4}{'d_div':>8}{'σθx':>8}{'T':>8}{'d_opd':>8}{'OPD':>8}{'PV':>7}{'S':>7}{'S sd':>7}{'M²*':>8}")
for r in sorted(records, key=lambda r: -r["strehl"]):
    say(f"   {r['label']:>4}{r['d_div']:>+8.3f}{r['sigma_theta_x'] * 1e6:>7.1f}µ{r['T']:>8.4f}"
        f"{r['d_opd']:>+8.3f}{lam(r['opd_rms']):>7.3f}λ{lam(r['opd_pv']):>6.2f}λ{r['strehl']:>7.3f}"
        f"{r['strehl_nodefocus']:>7.3f}{r['m2']:>8.2f}")
same_div = min(records, key=lambda r: r["sigma_theta_x"])["label"] == best["label"]
say(f"   Configuration retenue (Strehl max) : {best['label']} = collimateur "
    f"{'retourné' if best['cfg'][0] else 'sens dessin'}, ACN254 {'retourné' if best['cfg'][1] else 'sens dessin'}, "
    f"AC254-080 {'retourné' if best['cfg'][2] else 'sens dessin'} ; optimum en divergence "
    f"{'IDENTIQUE' if same_div else 'DIFFÉRENT : ' + min(records, key=lambda r: r['sigma_theta_x'])['label']}")
chain.set_preset("v22", flip_collimator=best["cfg"][0], flip_l1=best["cfg"][1], flip_l2=best["cfg"][2])
chain.PRESETS["v22"].update(flip_collimator=best["cfg"][0], flip_l1=best["cfg"][1], flip_l2=best["cfg"][2])

# ============================================================================
# 3. Collimateur seul
# ============================================================================
say("\n3. COLLIMATEUR AC254-040-B SEUL (orientation retenue ; plan d'analyse 1 mm après le dernier sommet)")
_, coll0 = chain.build_collimator(0.0)
ffd = paraxial.cardinal(coll0.surfaces)["FFD"]
efl_c = paraxial.cardinal(coll0.surfaces)["EFL"]
say(f"   position paraxiale de la fibre : {ffd:.4f} mm avant le 1er sommet (EFL = {efl_c:.4f} mm) ;"
    f" diamètre paraxial 2 f θ0 = {2 * efl_c * SRC.theta0:.3f} mm")
dc_div, _ = chain.best_defocus(source=SRC_OPT, target="collimator")
dc_opd, _ = chain.best_defocus(source=SRC_OPT, target="collimator_opd")
coll_res = {}
for name, dd in (("paraxial", 0.0), ("min divergence", dc_div), ("min OPD", dc_opd)):
    sysc, lens = chain.build_collimator(dd)
    rays = sysc.trace(SRC.generate_rays())
    z1 = lens.z_back + 1.0
    b = beam_stats(rays, z1, SRC)
    wf = wavefront(rays, LAM, "plane", z_ref=z1)
    wfs = best_sphere_wavefront(rays, LAM, z1)
    fm = field_moments(wf)
    coll_res[name] = dict(d=dd, b=b, wf=wf, wfs=wfs, fm=fm)
    say(f"   {name:<15} defocus {dd:+.4f} mm (fibre à {ffd + dd:.4f} mm) : θrad = {b.theta_rms * 1e6:7.1f} µrad,"
        f" σθx = {b.sigma_theta_x * 1e6:6.1f} µrad ; D: A {b.d_1e2_markers:.3f} / B {b.d4sigma:.3f} / C {b.d_fit:.3f} mm")
    say(f"   {'':<15} OPD plan : RMS {lam(wf.rms('power')):.4f} λ, PV {lam(wf.pv):.3f} λ, S {wf.strehl_direct():.4f}"
        f" ; R défocus {defocus_radius(wf) / 1e3:+.2f} m ; sphère ajustée : RMS {lam(wfs.rms('power')):.4f} λ,"
        f" PV {lam(wfs.pv):.3f} λ, S {wfs.strehl_direct():.4f} ; M²* = {fm.m2:.3f}")

# ============================================================================
# 4. Beam expander seul
# ============================================================================
say("\n4. BEAM EXPANDER ACN254-040-B → AC254-080-B SEUL")
ex = study.expander_paraxial()
say(f"   EFL à 1030 nm : f1 = {ex['f1']:.4f} mm, f2 = {ex['f2']:.4f} mm ; G = -f2/f1 = {ex['G_from_efl']:.5f}"
    f" (nominal 80,3/40 = {80.3 / 40:.5f})")
say(f"   séparation afocale SOMMET-SOMMET (L1 dernier sommet → L2 1er sommet) = {ex['afocal_gap_vertex']:.4f} mm")
say(f"   séparation des plans principaux H'1 → H2 = {ex['principal_plane_separation']:.4f} mm = f1 + f2"
    f" ({ex['f1'] + ex['f2']:.4f}) ≠ 40 + 80,3 = 120,3 (somme des |f|, non pertinente pour un Galilée)")
say(f"   plans principaux : H1 à {ex['H1_from_L1_front']:+.3f} mm du 1er sommet de L1, H'1 à "
    f"{ex['H1p_from_L1_back']:+.3f} mm du dernier sommet de L1 ; H2 à {ex['H2_from_L2_front']:+.3f} mm du 1er"
    f" sommet de L2, H'2 à {ex['H2p_from_L2_back']:+.3f} mm de son dernier sommet")
say(f"   matrice : A = {ex['A']:.6f}, C = {ex['C']:.1e} mm⁻¹, D = {ex['D']:.6f} → G paraxial = {ex['G_paraxial']:.5f}")
exp_sys, l1, l2 = ex["exp_sys"], ex["l1"], ex["l2"]
from optical_sim import Ray  # noqa: E402
for h in (0.01, 1.0, 4.36, 5.5, 6.0):
    r = exp_sys.trace(Ray([h, -10.0], [0.0, 1.0]))
    if r.status != "alive":
        say(f"   tracé exact, rayon // axe h = {h:5.2f} mm : ARRÊTÉ par l'ouverture de la surface "
            f"{r.blocked_at} (hauteur ≈ {abs(r.blocked_point[0]):.2f} mm > {exp_sys.surfaces[r.blocked_at].semi_aperture:.3f})")
        continue
    say(f"   tracé exact, rayon // axe h = {h:5.2f} mm : G = {r.x / h:.5f} (au dernier sommet), "
        f"angle de sortie {r.theta * 1e6:+9.2f} µrad")
w_in = coll_res["min OPD"]["b"].d_fit / 2
src_c = CollimatedSource(z=-10.0, half_width=3.0 * w_in, n_rays=2401, w=w_in)
rays_e = exp_sys.trace(src_c.generate_rays())
z_e = l2.z_back + 1.0
b_e = beam_stats(rays_e, z_e)
wf_e = wavefront(rays_e, LAM, "plane", z_ref=z_e)
wfs_e = best_sphere_wavefront(rays_e, LAM, z_e)
say(f"   entrée : onde plane gaussienne idéale w = {w_in:.3f} mm (ajustement du faisceau collimaté) :")
say(f"   T = {weighted_transmission(rays_e):.5f} ; D sortie A(2·G·w) {2 * ex['G_paraxial'] * w_in:.3f} / B {b_e.d4sigma:.3f}"
    f" / C {b_e.d_fit:.3f} mm ; divergence résiduelle σθx = {b_e.sigma_theta_x * 1e6:.2f} µrad, <θr> = "
    f"{b_e.mean_radial_angle * 1e6:+.2f} µrad")
say(f"   aberration propre : OPD RMS {lam(wf_e.rms('power')):.4f} λ, PV {lam(wf_e.pv):.4f} λ, S {wf_e.strehl_direct():.4f}"
    f" ; sphère ajustée : RMS {lam(wfs_e.rms('power')):.4f} λ, S {wfs_e.strehl_direct():.4f}"
    f" (R défocus {defocus_radius(wf_e) / 1e3:+.1f} m)")

# ============================================================================
# 5. Chaîne complète : bilan de puissance et convergence
# ============================================================================
d_div, d_opd = best["d_div"], best["d_opd"]
res = study.evaluate(d_opd, SRC)
c = res["chain"]
say(f"\n5. CHAÎNE COMPLÈTE {best['label']} — fibre à d_opd = {d_opd:+.4f} mm (fibre → 1er sommet "
    f"{res['fiber_to_vertex']:.4f} mm) ; d_div = {d_div:+.4f} mm")
say("   Bilan de puissance par surface (sommes de ray.power ; P0 = 1, puissance du mode dans ±3θ0 ≈ 1 - 1,5e-8)")
say(f"   {'surf':>4} {'élément':<15}{'a':>7}{'P inc.':>10}{'P perdue':>10}{'T surf':>9}{'T cumulée':>10}"
    f"{'r_rms':>8}{'D4σ':>8}{'D1/e²':>8}{'T analyt.':>10}  note")
for e in res["surfaces"]:
    ta = f"{e.t_analytic:10.5f}" if e.analytic_valid else f"{'—':>10}"
    say(f"   {e.index:>4} {e.element[:15]:<15}{e.semi_aperture:>7.3f}{e.p_incident:>10.6f}{e.p_lost:>10.2e}"
        f"{e.t_fraction:>9.5f}{e.p_transmitted:>10.6f}{e.r_rms:>8.3f}{e.d4sigma:>8.3f}{e.d_1e2:>8.3f}{ta}  {e.note}")
say("   D1/e² (marqueurs ±θ0) n'a de sens de « diamètre 1/e² » que tant que la note dit 'hypothèses vérifiées'.")

say("\n   Convergence avec le nombre de rayons (fibre à d_opd)")
say(f"   {'N':>6}{'échant.':>8}{'T':>10}{'perte L2':>10}{'OPD RMS':>10}{'PV':>8}{'S rayons':>10}{'S grille':>10}{'M²*':>8}")
conv = []
for n in (601, 1201, 2401, 4801, 9601):
    for samp in ("angle", "power"):
        s_ = chain.make_source(n_rays=n)
        s_.sampling = samp
        r_ = c["full"].trace(s_.generate_rays())
        wf_ = wavefront(r_, LAM, "plane", z_ref=res["z_out"])
        rp = surface_power_report(c["full"], r_, s_)
        lossL2 = sum(e.p_lost for e in rp if e.element == c["l2"].name)
        sg = strehl_grid(field_grid(wf_, n=1024))
        fm_ = field_moments(wf_)
        conv.append((n, samp, weighted_transmission(r_), lossL2, wf_.rms("power"), wf_.pv, wf_.strehl_direct(), sg, fm_.m2))
        say(f"   {n:>6}{samp:>8}{conv[-1][2]:>10.5f}{100 * lossL2:>9.3f}%{lam(conv[-1][4]):>9.4f}λ"
            f"{lam(conv[-1][5]):>7.3f}λ{conv[-1][6]:>10.4f}{sg:>10.4f}{fm_.m2:>8.3f}")

# ============================================================================
# 6. Faisceau de sortie
# ============================================================================
say(f"\n6. FAISCEAU DE SORTIE — plans comptés depuis le dernier sommet de L2 (z = {c['l2'].z_back:.3f} mm)")
say("   A = marqueurs ±θ0 / enveloppe ; B = moments ISO (puissance) ; C = ajustement gaussien (intensité locale)")
say(f"   {'Δz':>6}{'A: D1/e²':>10}{'A: 2rmax':>10}{'B: D4σ':>9}{'B: <x>':>10}{'C: Dfit':>9}{'C: résidu':>10}"
    f"{'θrad':>9}{'σθx':>8}{'<θr>':>9}")
outs = {}
for dz in (1.0, 100.0, 500.0, 1000.0):
    b = beam_stats(res["rays"], c["l2"].z_back + dz, SRC)
    outs[dz] = b
    say(f"   {dz:>6.0f}{b.d_1e2_markers:>10.3f}{b.r_max_pos + b.r_max_neg:>10.3f}{b.d4sigma:>9.3f}"
        f"{b.centroid:>10.1e}{b.d_fit:>9.3f}{100 * b.fit_residual:>9.2f}%{b.theta_rms * 1e6:>8.1f}µ"
        f"{b.sigma_theta_x * 1e6:>7.1f}µ{b.mean_radial_angle * 1e6:>+8.1f}µ")
fm = res["fm"]
w_fit = outs[1.0].d_fit / 2
dwdz = (outs[100.0].d_fit - outs[1.0].d_fit) / 2 / 99.0
say("   Divergences (NE PAS les confondre) :")
say(f"   * radiale RMS géométrique  sqrt(<θr²>)                 = {outs[1.0].theta_rms * 1e6:7.2f} µrad")
say(f"   * par axe RMS géométrique  σθx = θrad/√2               = {outs[1.0].sigma_theta_x * 1e6:7.2f} µrad")
say(f"   * du paramètre gaussien    dw_fit/dz (1 → 100 mm)       = {dwdz * 1e6:+7.2f} µrad (forme du profil, pas un angle de rayon)")
say(f"   * diffraction gaussienne idéale de w = {w_fit:.3f} mm : demi-angle 1/e² λ/(πw) = {LAM / (np.pi * w_fit) * 1e6:.2f} µrad,"
    f" σθx = λ/(2πw) = {LAM / (2 * np.pi * w_fit) * 1e6:.2f} µrad")
say(f"   * seconds moments du champ (bord dur exclu) : σθ,geo = {fm.sigma_theta_geo * 1e6:.2f}, σθ,amp = "
    f"{fm.sigma_theta_amp * 1e6:.2f}, σθ total = {fm.sigma_theta * 1e6:.2f} µrad ; σx = {fm.sigma_x:.4f} mm ;"
    f" M²* = {fm.m2:.3f}{' (BORD DUR : M² ISO strict infini)' if fm.hard_edge else ''}")
say(f"   Validité géométrique : Fresnel au bord sqrt(λz) = {np.sqrt(LAM * 100):.2f} mm à 100 mm, "
    f"{np.sqrt(LAM * 1000):.2f} mm à 1 m ; échelle du profil d'OPD ≈ 5 mm → diffraction notable vers"
    f" {5.0**2 / LAM / 1e3:.0f} m ; les plans ≥ 1 m ne sont donnés qu'à titre indicatif.")

# ============================================================================
# 7. Front d'onde et décomposition collimateur / expander
# ============================================================================
wf, wfs = res["wf"], res["wfs"]
say(f"\n7. FRONT D'ONDE (référence plane en z = {res['z_out']:.3f} mm, soit {res['z_out_rel']:.1f} mm après L2)")
say(f"   OPD RMS puissance {lam(wf.rms('power')):.4f} λ ({wf.rms('power') * 1e6:.1f} nm) ; pupille uniforme "
    f"{lam(wf.rms('area')):.4f} λ ; PV {lam(wf.pv):.4f} λ")
say(f"   défocus : c2 = {res['c2']:.3e} mm⁻¹ → R = {res['R_defocus'] / 1e3:+.2f} m "
    f"({'divergent' if res['R_defocus'] > 0 else 'convergent'}) ; OPD de défocus au bord ≈ "
    f"{lam(res['c2'] * radial_field(wf).r_edge ** 2):+.4f} λ")
say(f"   sphère de référence ajustée (centre à {wfs.z_center / 1e3:+.2f} m) : RMS {lam(wfs.rms('power')):.4f} λ,"
    f" PV {lam(wfs.pv):.4f} λ")
v = wf.validity()
say(f"   Strehl (somme directe, poids √(P dA)) : plan {wf.strehl_direct():.4f}, sphère ajustée {wfs.strehl_direct():.4f} ;"
    f" Maréchal {wf.strehl_marechal():.4f} ({'valide' if v['marechal_ok'] else 'HORS domaine : σ > λ/14'}) ;"
    f" max|Δφ| voisins {v['max |Δφ| voisins (rad)']:.3f} rad")
z_mid = c["coll"].z_back + 0.5 * chain.CONFIG["gap_coll_l1"]
sp = study.opd_split(wf, z_mid)
cov = np.sum(wf.power * (sp["coll"] - np.average(sp["coll"], weights=wf.power))
             * (sp["exp"] - np.average(sp["exp"], weights=wf.power))) / wf.power.sum()
say(f"   Décomposition EXACTE le long de chaque rayon (plan de coupure z = {z_mid:.2f} mm, entre collimateur et L1 ;"
    f" résidu d'additivité {sp['check']:.1e} mm) :")
for name, o in (("collimateur", sp["coll"]), ("expander", sp["exp"]), ("chaîne", sp["total"])):
    say(f"   {name:<12} RMS {lam(wf.rms('power', o)):.4f} λ, hors défocus {lam(wf.rms('power', study.remove_defocus(wf, o))):.4f} λ,"
        f" PV {lam(o.max() - o.min()):.4f} λ, Strehl seul {wf.strehl_direct(o):.4f}")
say(f"   covariance 2·cov(coll, exp) = {2 * cov / LAM**2:+.5f} λ²  (σ²_chaîne = σ²_coll + σ²_exp + 2cov)")

# ============================================================================
# 8. Sensibilité à l'ouverture claire de L2
# ============================================================================
say("\n8. SENSIBILITÉ À L'OUVERTURE CLAIRE DE L'AC254-080-B (fibre à d_opd)")
ca0 = lens_data.LENSES["AC254-080-B"]["clear_aperture"]
ca_res = []
for ca in (22.86, 23.5, 24.0, 24.5, 25.4):
    lens_data.LENSES["AC254-080-B"]["clear_aperture"] = ca
    r_ = study.evaluate(d_opd, SRC)
    ca_res.append((ca, r_["T"], r_["opd_rms"], r_["strehl"], r_["b_out"].d4sigma))
    say(f"   Ø utile {ca:5.2f} mm : T = {r_['T']:.5f} ; OPD {lam(r_['opd_rms']):.4f} λ ; S = {r_['strehl']:.4f} ;"
        f" D4σ sortie {r_['b_out'].d4sigma:.3f} mm")
lens_data.LENSES["AC254-080-B"]["clear_aperture"] = ca0

# ============================================================================
# 9. Comparaison avec la chaîne V2.1 (recalculée avec le code V2.2)
# ============================================================================
say("\n9. COMPARAISON AVEC LA CHAÎNE V2.1 (recalculée ici, même procédure, même N)")
new = res
NEW_FLIPS = dict(flip_collimator=best["cfg"][0], flip_l1=best["cfg"][1], flip_l2=best["cfg"][2])
# --- ancienne chaîne (préréglage v21 = orientation RDR, optimale en V2.1) ---
chain.set_preset("v21")
od_div, od_opd = study.optimize(SRC_OPT)          # positions de fibre réoptimisées ici
old = study.evaluate(od_opd, SRC)
old_div = study.evaluate(od_div, SRC)
G_old = paraxial.system_matrix(chain.build_expander(0.0)[0].surfaces)[0, 0]
# --- nouvelle chaîne ---
chain.set_preset("v22", **NEW_FLIPS)
new_div = study.evaluate(d_div, SRC)
G_new = paraxial.system_matrix(chain.build_expander(0.0)[0].surfaces)[0, 0]
loss_div_old = old["loss_by_element"]["ACN127-030-B"]
loss_div_new = new["loss_by_element"]["ACN254-040-B"]
rows = [
    ("position fibre d_opd (fibre → sommet)", f"{od_opd:+.3f} ({old['fiber_to_vertex']:.3f}) mm", f"{d_opd:+.3f} ({new['fiber_to_vertex']:.3f}) mm"),
    ("position fibre d_div", f"{od_div:+.3f} mm", f"{d_div:+.3f} mm"),
    ("D avant expander A / B / C", f"{old['b_in'].d_1e2_markers:.2f} / {old['b_in'].d4sigma:.2f} / {old['b_in'].d_fit:.2f} mm",
     f"{new['b_in'].d_1e2_markers:.2f} / {new['b_in'].d4sigma:.2f} / {new['b_in'].d_fit:.2f} mm"),
    ("D après expander A / B / C", f"{old['b_out'].d_1e2_markers:.2f} / {old['b_out'].d4sigma:.2f} / {old['b_out'].d_fit:.2f} mm",
     f"{new['b_out'].d_1e2_markers:.2f} / {new['b_out'].d4sigma:.2f} / {new['b_out'].d_fit:.2f} mm"),
    ("grandissement paraxial", f"{G_old:.4f}", f"{G_new:.4f}"),
    ("σθx géométrique (fibre à d_div)", f"{old_div['sigma_theta_x'] * 1e6:.1f} µrad", f"{new_div['sigma_theta_x'] * 1e6:.1f} µrad"),
    ("σθx géométrique (fibre à d_opd)", f"{old['sigma_theta_x'] * 1e6:.1f} µrad", f"{new['sigma_theta_x'] * 1e6:.1f} µrad"),
    ("σθ total du champ (bord exclu)", f"{old['fm'].sigma_theta * 1e6:.1f} µrad", f"{new['fm'].sigma_theta * 1e6:.1f} µrad"),
    ("transmission", f"{old['T']:.4f}", f"{new['T']:.4f}"),
    ("perte au divergent", f"{100 * loss_div_old:.3f} %", f"{100 * loss_div_new:.4f} %"),
    ("perte à la lentille positive", f"{100 * old['loss_by_element']['AC254-060-B']:.3f} %", f"{100 * new['loss_by_element']['AC254-080-B']:.3f} %"),
    ("OPD RMS (puissance) / pupille unif.", f"{lam(old['opd_rms']):.4f} / {lam(old['opd_rms_area']):.4f} λ", f"{lam(new['opd_rms']):.4f} / {lam(new['opd_rms_area']):.4f} λ"),
    ("OPD PV", f"{lam(old['opd_pv']):.4f} λ", f"{lam(new['opd_pv']):.4f} λ"),
    ("OPD RMS hors défocus", f"{lam(old['opd_rms_nodefocus']):.4f} λ", f"{lam(new['opd_rms_nodefocus']):.4f} λ"),
    ("Strehl (plan / sphère ajustée)", f"{old['strehl']:.4f} / {old['strehl_nodefocus']:.4f}", f"{new['strehl']:.4f} / {new['strehl_nodefocus']:.4f}"),
    ("M²* (bord dur exclu)", f"{old['fm'].m2:.3f}", f"{new['fm'].m2:.3f}"),
]
say(f"   {'grandeur':<38}{'ancienne (V2.1, RDR)':>28}{'nouvelle (' + best['label'] + ')':>28}")
for g, a, b in rows:
    say(f"   {g:<38}{a:>28}{b:>28}")

# ============================================================================
# 10. Export du champ pour la propagation ondulatoire
# ============================================================================
rf = radial_field(wf)
grid = field_grid(wf, n=1024)
say(f"\n10. CHAMP D'ENTRÉE POUR LA PROPAGATION (plan z = {res['z_out']:.3f} mm)")
say(f"   ouverture effective (bord du dernier rayon transmis) r_edge = {rf.r_edge:.4f} mm (Ø{2 * rf.r_edge:.3f}) ;"
    f" intensité au bord / centre = {rf.edge_intensity_ratio:.4f} → troncature {'NETTE (bord dur)' if rf.hard_edge else 'négligeable'}")
say(f"   diamètres : D4σ {fm.d4sigma:.3f} mm, ajustement gaussien {outs[1.0].d_fit:.3f} mm")
say(f"   grille 1024² de pas {grid['dx'] * 1e3:.1f} µm sur ±{grid['x'][-1]:.2f} mm ; normalisation Σ|E|²dA = P "
    f"(facteur {grid['norm_factor']:.5f}) ; Strehl grille {strehl_grid(grid):.4f}")
np.savez_compressed(os.path.join(HERE, "v22_field_grid.npz"), x=grid["x"], y=grid["y"], E=grid["E"].astype(np.complex64),
                    wavelength_mm=LAM, z_mm=res["z_out"], r_edge_mm=rf.r_edge)
np.savetxt(os.path.join(HERE, "v22_field_radial.csv"),
           np.column_stack([rf.r, rf.I, rf.A, rf.opd * 1e6, rf.phase]), delimiter=",",
           header="r_mm,intensite_P_par_mm2,amplitude,OPD_nm,phase_rad", comments="")
say("   fichiers : v22_field_grid.npz (E complexe, x, y en mm), v22_field_radial.csv (profil radial)")

# ============================================================================
# Figures
# ============================================================================
fig1, (a1, a2) = plt.subplots(2, 1, figsize=(14, 9), height_ratios=[1.3, 1])
step = max(1, SRC.n_rays // 60)
rays_plot = c["full"].trace([r for i, r in enumerate(SRC.generate_rays()) if i % step == 0],
                            z_final=c["l2"].z_back + 40)
plot_rays(rays_plot, c["full"], ax=a1, source=SRC, equal_aspect=False, legend_loc="lower right",
          title=f"Chaîne V2.2 ({best['label']}), fibre à {res['fiber_to_vertex']:.3f} mm du collimateur")
zz = np.linspace(1.0, c["l2"].z_back + 150, 500)
bz = [beam_stats(res["rays"], z, SRC) for z in zz]
a2.plot(zz, [b.d_1e2_markers for b in bz], "-", color="tab:red", label="A : marqueurs ±θ0")
a2.plot(zz, [b.d4sigma for b in bz], "--", color="tab:blue", label="B : D4σ ISO")
a2.plot(zz, [b.d_fit for b in bz], "-.", color="tab:green", label="C : ajustement gaussien")
for el in c["full"].elements:
    a2.axvspan(el.z_front, el.z_back, color="tab:cyan", alpha=0.25, lw=0)
    a2.plot([el.z_front, el.z_back], [2 * el.semi_aperture] * 2, color="k", lw=3)
a2.set_xlabel("z [mm]")
a2.set_ylabel("diamètre [mm]")
a2.set_title("Diamètre du faisceau selon trois définitions (traits noirs : ouvertures claires)")
a2.legend(fontsize=8)
a2.grid(alpha=0.3)
fig1.tight_layout()
fig1.savefig(os.path.join(HERE, "v22_fig1_chain.png"), dpi=120)

fig2, axs = plt.subplots(1, 3, figsize=(15, 4.2))
recs = sorted(records, key=lambda r: -r["strehl"])
labels = [r["label"] for r in recs]
axs[0].bar(labels, [r["strehl"] for r in recs], color=["tab:green" if r is best else "0.6" for r in recs])
axs[0].set_title("Strehl (fibre à d_opd)")
axs[1].bar(labels, [r["sigma_theta_x"] * 1e6 for r in recs], color="tab:purple")
axs[1].set_yscale("log")
axs[1].set_title("σθx géométrique [µrad] (fibre à d_div)")
axs[2].bar(labels, [100 * (1 - r["T"]) for r in recs], color="tab:red")
axs[2].set_title("perte totale [%]")
for a_ in axs:
    a_.grid(alpha=0.3, axis="y")
    a_.set_xlabel("collimateur / ACN254 / AC254-080  (D dessin, R retournée)", fontsize=8)
fig2.tight_layout()
fig2.savefig(os.path.join(HERE, "v22_fig2_orientations.png"), dpi=120)

fig3, axs = plt.subplots(1, 3, figsize=(16, 4.6))
o = np.argsort(wf.x)
for arr, name, col in ((sp["total"], "chaîne", "k"), (sp["coll"], "part collimateur", "tab:blue"),
                       (sp["exp"], "part expander", "tab:orange")):
    axs[0].plot(wf.x[o], lam(arr[o]), color=col, label=name)
wo = old["wf"]
oo = np.argsort(wo.x)
axs[0].plot(wo.x[oo], lam(wo.opd[oo]), ":", color="0.4", label="chaîne V2.1 (référence)")
axs[0].set_title("OPD / plan, décomposition exacte")
axs[0].set_xlabel("hauteur sur la référence [mm]")
axs[0].set_ylabel("OPD [λ]")
axs[0].legend(fontsize=7)
axs[0].grid(alpha=0.3)
axs[1].plot(rf.r, rf.I / rf.I.max(), color="tab:red", label="intensité P/dA (V2.2)")
axs[1].plot(rf.r, rf.A / rf.A.max(), color="tab:blue", label="amplitude √I (V2.2)")
rfo = radial_field(wo)
axs[1].plot(rfo.r, rfo.I / rfo.I.max(), ":", color="tab:red", label="intensité (V2.1)")
axs[1].axvline(rf.r_edge, color="k", lw=0.8)
axs[1].set_title("Profil transverse au plan de sortie")
axs[1].set_xlabel("r [mm]")
axs[1].legend(fontsize=7)
axs[1].grid(alpha=0.3)
ns = sorted(set(x[0] for x in conv))
for samp, mk in (("angle", "o-"), ("power", "s--")):
    sel = [x for x in conv if x[1] == samp]
    axs[2].semilogx([x[0] for x in sel], [x[6] for x in sel], mk, label=f"Strehl rayons ({samp})")
    axs[2].semilogx([x[0] for x in sel], [x[7] for x in sel], mk, alpha=0.5, label=f"Strehl grille ({samp})")
axs[2].set_xlabel("nombre de rayons")
axs[2].set_title("Convergence du Strehl")
axs[2].legend(fontsize=7)
axs[2].grid(alpha=0.3, which="both")
fig3.tight_layout()
fig3.savefig(os.path.join(HERE, "v22_fig3_wavefront.png"), dpi=120)

with open(os.path.join(HERE, "v22_report.txt"), "w") as fh:
    fh.write("\n".join(OUT) + "\n")
print("rapport et figures écrits dans", HERE)
