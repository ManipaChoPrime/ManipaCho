"""Source ponctuelle : un éventail de rayons issus d'un même point."""

from __future__ import annotations

import numpy as np

from .ray import Ray


def symmetric_cell_powers(u, density, u_max_total, n_fine: int = 200001):
    """Puissance relative de chaque rayon d'un éventail symétrique en u (angle
    ou hauteur), pour une distribution DE RÉVOLUTION de densité de puissance
    radiale  dP = density(|u|) d|u|  (density inclut déjà le jacobien,
    sin(theta) ou r).

    Chaque rayon représente la couronne [u_lo, u_hi] limitée par les milieux
    avec ses voisins de même signe (premier bord à 0, dernier bord symétrique).
    La couronne est partagée entre les rayons +u et -u (facteur 1/2) ; un rayon
    exactement en u = 0 porte seul le disque central. Les puissances sont
    normalisées à la puissance TOTALE de la distribution sur [0, u_max_total]
    (et non à celle de l'éventail tracé) : leur somme est la fraction de
    puissance contenue dans l'éventail.
    """
    u = np.asarray(u, dtype=float)
    a = np.abs(u)
    grid = np.linspace(0.0, max(u_max_total, a.max() * 1.0001), n_fine)
    cum = np.concatenate([[0.0], np.cumsum(0.5 * (density(grid[1:]) + density(grid[:-1]))
                                           * np.diff(grid))])
    total = np.interp(u_max_total, grid, cum)
    F = lambda v: np.interp(v, grid, cum)
    out = np.zeros_like(a)
    # regroupement de ±u avec une tolérance relative (les angles ±u peuvent
    # différer de quelques ulp : sans cela, +u et -u recevraient des couronnes
    # différentes et le faisceau deviendrait artificiellement asymétrique)
    scale = a.max() if a.max() > 0 else 1.0
    key = np.round(a / scale, 10)
    uniq_keys, first = np.unique(key, return_index=True)
    pos = a[first]                       # valeurs distinctes de |u| (triées)
    mids = 0.5 * (pos[1:] + pos[:-1])
    lo = np.concatenate([[0.0], mids])
    hi = np.concatenate([mids, [pos[-1] + (pos[-1] - lo[-1]) if len(pos) > 1 else pos[-1] * 2]])
    for k, v in enumerate(pos):
        p_ring = F(hi[k]) - F(lo[k])
        same = np.where(key == uniq_keys[k])[0]
        out[same] = p_ring / len(same)   # ±v se partagent la couronne ; v = 0 : seul
    return out / total


class PointSource:
    """Source ponctuelle en (x, z), dans un milieu d'indice n.

    Les angles sont mesurés depuis l'axe +z, positifs vers +x :
        direction = (sin theta, cos theta)
    et uniformément répartis dans [theta_center - theta_max, theta_center + theta_max].
    (Pour un éventail vers -z, prendre theta_center = pi.)
    """

    def __init__(self, x: float = 0.0, z: float = 0.0, theta_max: float = np.deg2rad(10),
                 n_rays: int = 101, n: float = 1.0, theta_center: float = 0.0):
        self.x = float(x)
        self.z = float(z)
        self.theta_max = float(theta_max)
        self.n_rays = int(n_rays)
        self.n = float(n)
        self.theta_center = float(theta_center)

    @property
    def position(self) -> np.ndarray:
        return np.array([self.x, self.z])

    def angles(self) -> np.ndarray:
        """Angles uniformément espacés, construits par MIROIR EXACT (+u, -u
        rigoureusement opposés) pour préserver la symétrie de révolution."""
        if self.n_rays == 1:
            return np.array([self.theta_center])
        half = np.linspace(-self.theta_max, self.theta_max, self.n_rays)[self.n_rays // 2:]
        half = np.abs(half[half >= 0]) if self.n_rays % 2 else np.abs(half)
        if self.n_rays % 2:
            half[0] = 0.0          # V2.2 : rayon axial EXACTEMENT nul (sinon ~1e-17, voir rapport)
            body = np.concatenate([-half[:0:-1], half])
        else:
            body = np.concatenate([-half[::-1], half])
        return self.theta_center + body

    def generate_rays(self) -> list[Ray]:
        """Puissance uniforme 1/N par rayon : simple étiquette, sans sens radiométrique."""
        th = self.angles()
        rays = [Ray(self.position, (np.sin(t), np.cos(t)), n=self.n) for t in th]
        for r in rays:
            r.power = 1.0 / len(th)
        return rays


class CollimatedSource:
    """Faisceau de rayons parallèles (objet à l'infini).

    Les rayons partent du plan z = z, aux hauteurs x uniformément réparties
    dans [x_center - half_width, x_center + half_width], tous avec la même
    direction d'angle `theta` (mesuré depuis +z, positif vers +x).
    Pour theta = 0, l'image paraxiale est le foyer image du système.
    """

    def __init__(self, z: float, half_width: float, n_rays: int = 101,
                 theta: float = 0.0, x_center: float = 0.0, n: float = 1.0,
                 w: float = None):
        self.z = float(z)
        self.half_width = float(half_width)
        self.n_rays = int(n_rays)
        self.theta = float(theta)
        self.x_center = float(x_center)
        self.n = float(n)
        self.w = None if w is None else float(w)   # rayon 1/e² d'un profil gaussien (optionnel)

    def weight(self, x, mode: str = "cut"):
        """Poids d'un faisceau gaussien collimaté de rayon 1/e² w, centré en x_center.

        "cut"    : I(x) ∝ exp(-2 (x - xc)² / w²)  (coupe méridienne, moments)
        "radial" : I(r) |r|  avec r = x - xc  (puissance dans l'anneau 2π r dr ;
                   exact pour un faisceau de révolution centré sur l'axe d'un
                   système de révolution, rayons méridiens)
        Sans w, tous les poids valent 1 ("cut") ou |r| ("radial").
        """
        r = np.asarray(x, dtype=float) - self.x_center
        I = np.ones_like(r) if self.w is None else np.exp(-2.0 * r**2 / self.w**2)
        if mode == "radial":
            return I * np.abs(r)
        if mode != "cut":
            raise ValueError("mode ∈ {'cut', 'radial'}")
        return I

    def ray_weights(self, rays, mode: str = "cut") -> np.ndarray:
        from .beam import source_ray
        return self.weight([source_ray(r).history[0].position[0] for r in rays], mode)

    def heights(self) -> np.ndarray:
        """Hauteurs uniformes, symétriques par miroir exact autour de x_center."""
        if self.n_rays == 1:
            return np.array([self.x_center])
        full = np.linspace(-self.half_width, self.half_width, self.n_rays)
        half = np.abs(full[self.n_rays // 2:])
        if self.n_rays % 2:
            half[0] = 0.0          # V2.2 : rayon axial EXACTEMENT nul
        body = (np.concatenate([-half[:0:-1], half]) if self.n_rays % 2
                else np.concatenate([-half[::-1], half]))
        return self.x_center + body

    def generate_rays(self) -> list[Ray]:
        d = (np.sin(self.theta), np.cos(self.theta))
        xs = self.heights()
        rays = [Ray((x, self.z), d, n=self.n) for x in xs]
        if self.w is not None:
            # faisceau gaussien de révolution : dP = exp(-2 r²/w²) 2π r dr, normalisé à 1
            P = symmetric_cell_powers(xs - self.x_center,
                                      lambda r: np.exp(-2 * r**2 / self.w**2) * r, 6 * self.w)
        else:
            P = np.full(len(xs), 1.0 / len(xs))        # poids uniformes (sans sens physique)
        for r, p in zip(rays, P):
            r.power = float(p)
        return rays


class GaussianFiberSource(PointSource):
    """Sortie de fibre monomode : source ponctuelle + POIDS gaussiens.

    MODÈLE
    ------
    * Le mode est approché par un faisceau gaussien de waist w0 = MFD / 2 situé
      sur la face de la fibre (point (x, z)).
    * Divergence gaussienne (demi-angle à 1/e² en intensité, champ lointain,
      approximation paraxiale) :
            theta0 = lambda0 / (pi * w0)
      C'est une propriété du MODE, distincte de l'ouverture numérique nominale
      de la fibre (NA = sin de l'angle d'acceptance du guide, définie par le
      profil d'indice). `na_nominal` n'est conservée qu'à titre d'information
      et n'intervient dans aucun calcul.
    * Intensité angulaire en champ lointain :  I(theta) ∝ exp(-2 theta² / theta0²).
    * Les rayons sont des directions uniformément espacées dans
      [-k theta0, +k theta0] (k = theta_factor, 3 par défaut : la puissance hors
      du cône est exp(-2 k²) ≈ 1.5e-8). Chaque rayon porte un poids.

    POIDS (fonction `weight(theta, mode)`)
    ---------------------------------------
    * mode="cut"    : w ∝ I(theta).  Profil dans une coupe méridienne (1D).
                      Sert aux moments du second ordre : D4σ = 4 sqrt(<x²>).
    * mode="radial" : w ∝ I(theta) |sin theta|.  Puissance dans le cône
                      élémentaire 2π sin(theta) dtheta : pour un point source
                      SUR L'AXE d'un système de révolution, tous les rayons sont
                      méridiens, chaque rayon tracé représente donc tout un
                      cône et ce poids donne des fractions de puissance 3D
                      exactes (au sens de l'optique géométrique).
    Les longueurs suivent l'unité du reste du code (mm dans les exemples) :
    wavelength et mfd sont donc à donner dans cette unité.
    """

    def __init__(self, x: float = 0.0, z: float = 0.0, wavelength: float = 1.03e-3,
                 mfd: float = 6e-3, n_rays: int = 401, theta_factor: float = 3.0,
                 n: float = 1.0, na_nominal: float = None, total_power: float = 1.0,
                 sampling: str = "angle"):
        if sampling not in ("angle", "power"):
            raise ValueError("sampling ∈ {'angle', 'power'}")
        self.sampling = sampling
        self.total_power = float(total_power)
        self.wavelength = float(wavelength)
        self.mfd = float(mfd)
        self.w0 = self.mfd / 2.0
        self.theta0 = self.wavelength / (np.pi * self.w0)
        self.theta_factor = float(theta_factor)
        self.na_nominal = na_nominal
        super().__init__(x=x, z=z, theta_max=self.theta_factor * self.theta0,
                         n_rays=n_rays, n=n)

    # ------------------------------------------------------------------ #
    # Puissance par rayon (V2.1)
    # ------------------------------------------------------------------ #
    def power_density(self, theta):
        """Densité de puissance par unité d'angle polaire (champ lointain,
        faisceau de révolution) : dP/dtheta ∝ I(theta) 2π sin(theta),
        I(theta) ∝ exp(-2 theta²/theta0²) (intensité RADIANTE, W/sr).
        Le champ (amplitude) correspondant est ∝ exp(-theta²/theta0²)."""
        theta = np.asarray(theta, dtype=float)
        return np.exp(-2.0 * theta**2 / self.theta0**2) * np.sin(theta)

    def angles(self) -> np.ndarray:
        """Angles des rayons.
        sampling="angle" : uniformes dans [-k theta0, k theta0] (comme en V1.5).
        sampling="power" : chaque demi-éventail découpé en couronnes de même
        puissance (quantiles de la distribution radiale), rayon au milieu en
        puissance de chaque couronne ; nombre impair de rayons -> rayon axial."""
        if self.sampling == "angle":
            return super().angles()
        n_half = self.n_rays // 2
        th_max = self.theta_max
        grid = np.linspace(0.0, th_max, 200001)
        dens = self.power_density(grid)
        cum = np.concatenate([[0.0], np.cumsum(0.5 * (dens[1:] + dens[:-1]) * np.diff(grid))])
        q = (np.arange(n_half) + 0.5) / n_half * cum[-1]
        half = np.interp(q, cum, grid)
        mid = [0.0] if self.n_rays % 2 else []
        return np.concatenate([-half[::-1], mid, half])

    def _fan_fraction(self) -> float:
        """Fraction de la puissance du mode contenue dans le cône |theta| <= theta_max."""
        grid = np.linspace(0.0, np.pi / 2, 400001)
        d = self.power_density(grid)
        cum = np.concatenate([[0.0], np.cumsum(0.5 * (d[1:] + d[:-1]) * np.diff(grid))])
        return float(np.interp(self.theta_max, grid, cum) / cum[-1])

    def ray_powers(self, thetas) -> np.ndarray:
        """Puissance (absolue, unité de total_power) de chaque rayon.

        sampling="angle" : intégrale exacte de la densité sur la couronne du
        rayon (bornes aux milieux entre rayons voisins, symmetric_cell_powers),
        normalisée à la puissance totale du mode (intégrée jusqu'à pi/2).
        sampling="power" : couronnes de même puissance, bornées par les
        quantiles ; chaque couronne est partagée entre ±theta ; le rayon axial
        (s'il existe) ne porte aucune couronne (puissance 0, il sert de rayon
        chef pour l'OPD)."""
        thetas = np.asarray(thetas, dtype=float)
        if self.sampling == "angle":
            return self.total_power * symmetric_cell_powers(thetas, self.power_density, np.pi / 2)
        n_half = self.n_rays // 2
        p_ray = self.total_power * self._fan_fraction() / n_half / 2.0
        return np.where(thetas == 0.0, 0.0, p_ray)

    def generate_rays(self) -> list:
        th = self.angles()
        P = self.ray_powers(th)
        rays = [Ray(self.position, (np.sin(t), np.cos(t)), n=self.n) for t in th]
        for r, p in zip(rays, P):
            r.power = float(p)
        return rays

    @property
    def rayleigh_range(self) -> float:
        """z_R = pi w0² / lambda (dans le vide), longueur de Rayleigh du waist de fibre."""
        return np.pi * self.w0**2 / self.wavelength

    def weight(self, theta, mode: str = "cut"):
        theta = np.asarray(theta, dtype=float)
        w = np.exp(-2.0 * theta**2 / self.theta0**2)
        if mode == "radial":
            w = w * np.abs(np.sin(theta))
        elif mode != "cut":
            raise ValueError("mode ∈ {'cut', 'radial'}")
        return w

    def ray_weights(self, rays, mode: str = "cut") -> np.ndarray:
        from .beam import source_theta
        return self.weight([source_theta(r) for r in rays], mode)
