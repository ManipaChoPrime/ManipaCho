"""Tests V2.2 : nouvelles prescriptions (ACN254-040-B, AC254-080-B), nouveau
beam expander, puissance / clipping / OPD / Strehl sur la nouvelle chaîne,
relations de facteurs 2 et √2, seconds moments du champ.

Exécution :  python tests/test_v22_chain.py   (ou  pytest tests/)
"""

import os
import sys
import warnings

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "examples"))
from optical_sim import (Lens, OpticalSystem, Ray, Aperture, CollimatedSource, PointSource,  # noqa: E402
                         GaussianFiberSource, paraxial, axis_crossing, beam_stats, wavefront,
                         best_sphere_wavefront, defocus_radius, field_moments, field_grid,
                         strehl_grid, surface_power_report, weighted_transmission, ray_powers)
from optical_sim.ray import ALIVE  # noqa: E402
import chain  # noqa: E402
import lens_data  # noqa: E402

LAM = 1.03e-3
NEW = ("ACN254-040-B", "AC254-080-B")
D_OPT = -0.05     # position de fibre de travail pour les tests (proche de l'optimum, voir rapport)


def setup_function(function):
    chain.FORCE_STANDIN = False
    chain.set_preset("v22")


def _chain(n_rays=1201, sampling="angle", defocus=D_OPT, theta_factor=None):
    c = chain.build_chain(defocus)
    src = chain.make_source(n_rays=n_rays, theta_factor=theta_factor)
    src.sampling = sampling
    return c, src, c["full"].trace(src.generate_rays())


# ========================================================================== #
# Prescriptions
# ========================================================================== #
def test_new_prescriptions_exact():
    exp = {"ACN254-040-B": (-24.43, 27.86, 332.30, 2.0, 4.0, -40.0, -43.4),
           "AC254-080-B": (38.7, -43.2, 374.0, 6.6, 2.0, 80.3, 73.5)}
    for k, (R1, R2, R3, t1, t2, efl, bfl) in exp.items():
        d = lens_data.LENSES[k]
        assert (d["R1"], d["R2"], d["R3"], d["tc1"], d["tc2"]) == (R1, R2, R3, t1, t2)
        assert (d["glass1"], d["glass2"]) == ("N-BAF10", "N-SF6HT")
        assert (d["efl_nominal"], d["bfl_nominal"]) == (efl, bfl)
        assert (d["diameter"], d["clear_aperture"]) == (25.4, 22.86)
        assert "n1" not in d and "n2" not in d                      # indices non recopiés
        assert lens_data.lens_indices(k) == (1.654584, 1.774338)
    # le collimateur est inchangé par rapport à la V2.1
    d = lens_data.LENSES["AC254-040-B-ML"]
    assert (d["R1"], d["R2"], d["R3"], d["tc1"], d["tc2"]) == (26.12, -21.28, -137.09, 10.0, 2.5)


def test_new_sequence_both_orientations():
    for k in NEW:
        d = lens_data.LENSES[k]
        n1, n2 = lens_data.lens_indices(k)
        s1, s2, s3 = lens_data.build_lens(k, z_front=3.0).surfaces
        assert (s1.R, s2.R, s3.R) == (d["R1"], d["R2"], d["R3"])
        assert np.isclose(s2.z_vertex - s1.z_vertex, d["tc1"])
        assert np.isclose(s3.z_vertex - s2.z_vertex, d["tc2"])
        assert [(s.n1, s.n2) for s in (s1, s2, s3)] == [(1.0, n1), (n1, n2), (n2, 1.0)]
        f1, f2, f3 = lens_data.build_lens(k, flip=True).surfaces
        assert (f1.R, f2.R, f3.R) == (-d["R3"], -d["R2"], -d["R1"])
        assert np.isclose(f2.z_vertex - f1.z_vertex, d["tc2"])
        assert [(s.n1, s.n2) for s in (f1, f2, f3)] == [(1.0, n2), (n2, n1), (n1, 1.0)]


def test_new_edge_thickness():
    """ACN254-040-B : 9,80 mm calculés au Ø25,4 = 9,8 mm catalogue.
    AC254-080-B : 6,67 mm calculés vs 6,4 mm catalogue -> écart CONNU et documenté."""
    for k in NEW:
        d = lens_data.LENSES[k]
        n1, n2 = lens_data.lens_indices(k)
        L = Lens([d["R1"], d["R2"], d["R3"]], [d["tc1"], d["tc2"]], [n1, n2], aperture=d["diameter"])
        et = sum(L.edge_thicknesses())
        assert all(t > 0 for t in L.edge_thicknesses())
        if d["edge_thickness_note"] is None:
            assert abs(et - d["edge_thickness_ref"]) < 0.06, (k, et)
        else:
            assert abs(et - 6.672) < 0.002 and 0.2 < et - d["edge_thickness_ref"] < 0.3


def test_new_efl_bfl_at_1030():
    """EFL/BFL à 1030 nm (sens du dessin) vs nominales (contrôles, autre λ) : < 0,5 %."""
    for k in NEW:
        d = lens_data.LENSES[k]
        c = paraxial.cardinal(lens_data.build_lens(k).surfaces)
        assert abs(c["EFL"] / d["efl_nominal"] - 1) < 0.005, (k, c["EFL"])
        assert abs(c["BFD"] / d["bfl_nominal"] - 1) < 0.005, (k, c["BFD"])
        cf = paraxial.cardinal(lens_data.build_lens(k, flip=True).surfaces)
        assert abs(cf["EFL"] - c["EFL"]) < 1e-10                  # EFL invariant au retournement
        assert abs(cf["BFD"] - c["FFD"]) < 1e-10 and abs(cf["FFD"] - c["BFD"]) < 1e-10
        assert abs(cf["BFD"] - d["bfl_nominal"]) > 1.0            # la BFL fiche = sens du dessin


def test_R3_sign_confirmed_by_efl():
    for k in NEW:
        d = dict(lens_data.LENSES[k])
        d["R3"] = -d["R3"]
        c = paraxial.cardinal(lens_data.build_lens(d).surfaces)
        assert abs(c["EFL"] / d["efl_nominal"] - 1) > 0.2


# ========================================================================== #
# Beam expander V2.2
# ========================================================================== #
def test_expander_magnification_and_afocal_gap():
    exp_sys, l1, l2, gap = chain.build_expander(0.0)
    f = chain.expander_figures(exp_sys, l1, l2, gap)
    assert abs(f["C"]) < 1e-12
    assert abs(f["G_paraxial"] - (-f["f2"] / f["f1"])) < 1e-9
    assert abs(f["G_paraxial"] - 2.0) < 0.005                   # ≈ 2,0013 avec les EFL à 1030 nm
    assert abs(f["principal_plane_separation"] - (f["f1"] + f["f2"])) < 1e-9
    assert abs(f["principal_plane_separation"] - 40.24) < 0.01
    assert abs(gap - f["principal_plane_separation"]) > 5.0      # sommets ≠ plans principaux
    assert gap > 0


def test_afocal_gap_by_ray_tracing():
    """Rayon // axe à faible hauteur : sortie // axe à la séparation calculée,
    et l'angle de sortie change de signe quand on déplace L2 de ±0,1 mm."""
    exp_sys, l1, l2, gap = chain.build_expander(0.0)
    angles = []
    for dg in (-0.1, 0.0, 0.1):
        l2b = chain.make_lens("l2", l1.z_back + gap + dg)
        r = OpticalSystem([l1, l2b]).trace(Ray([0.01, -10.0], [0.0, 1.0]))
        angles.append(r.theta)
    assert abs(angles[1]) < 1e-9
    assert np.sign(angles[0]) == -np.sign(angles[2]) and abs(angles[0]) > 1e-7


def test_expander_ray_magnification_converges():
    exp_sys, l1, l2, gap = chain.build_expander(0.0)
    G = paraxial.system_matrix(exp_sys.surfaces)[0, 0]
    errs = []
    for h in (2.0, 1.0, 0.5, 0.25):
        r = exp_sys.trace(Ray([h, -10.0], [0.0, 1.0]))
        errs.append(abs(r.x / h - G))
    assert np.all(np.diff(errs) < 0) and errs[-1] < 2e-4


# ========================================================================== #
# Puissance, clipping
# ========================================================================== #
def test_power_conservation_without_clipping():
    """Éventail limité à ±1,2 θ0 : faisceau < ouvertures partout -> aucune perte."""
    c, src, rays = _chain(n_rays=801, theta_factor=1.2)
    rep = surface_power_report(c["full"], rays, src)
    assert all(e.p_lost == 0.0 for e in rep)
    assert all(r.status == ALIVE for r in rays)
    assert abs(weighted_transmission(rays) - 1.0) < 1e-15
    # échantillonnage uniforme en angle : la cellule du dernier rayon s'étend
    # jusqu'à θmax + Δθ/2 -> puissance tracée = fraction du mode dans ce cône
    dth = 2 * src.theta_max / (src.n_rays - 1)
    g = np.linspace(0, np.pi / 2, 400001)
    dens = src.power_density(g)
    cum = np.concatenate([[0], np.cumsum(0.5 * (dens[1:] + dens[:-1]) * np.diff(g))])
    frac = np.interp(src.theta_max + dth / 2, g, cum) / cum[-1]
    assert abs(ray_powers(rays).sum() - frac) < 1e-9


def test_clipping_location_and_convergence():
    """La perte se fait sur l'AC254-080-B ; l'ACN254-040-B ne coupe que les
    ailes extrêmes ; la transmission converge avec N."""
    T = {}
    for n in (2401, 4801):
        for sampling in ("angle", "power"):
            c, src, rays = _chain(n_rays=n, sampling=sampling)
            T[(n, sampling)] = weighted_transmission(rays)
    assert abs(T[(4801, "angle")] - T[(2401, "angle")]) < 3e-4
    assert abs(T[(4801, "angle")] - T[(4801, "power")]) < 3e-4
    c, src, rays = _chain(n_rays=2401)
    rep = surface_power_report(c["full"], rays, src)
    loss = {el: sum(e.p_lost for e in rep if e.element == el) for el in ("ACN254-040-B", "AC254-080-B")}
    assert loss["ACN254-040-B"] < 1e-4 < 0.01 < loss["AC254-080-B"]


# ========================================================================== #
# Front d'onde : convergence, invariance, retour inverse, eikonale
# ========================================================================== #
def test_opd_and_strehl_converge():
    res = {}
    for n in (1201, 2401, 4801):
        c, src, rays = _chain(n_rays=n)
        wf = wavefront(rays, LAM, "plane", z_ref=c["l2"].z_back + 1.0)
        res[n] = (wf.rms("power"), wf.strehl_direct(), wf.pv)
    assert abs(res[4801][0] - res[2401][0]) < 2e-3 * LAM
    assert abs(res[4801][1] - res[2401][1]) < 2e-3
    assert abs(res[4801][1] - res[1201][1]) < 5e-3


def test_strehl_ray_sum_equals_uniform_grid():
    """Strehl par somme sur les rayons (poids √(P dA)) = Strehl sur grille
    uniforme (cellules d'aire égale, poids ∝ √P de la cellule)."""
    c, src, rays = _chain(n_rays=2401)
    wf = wavefront(rays, LAM, "plane", z_ref=c["l2"].z_back + 1.0)
    g = field_grid(wf, n=1024)
    assert abs(g["norm_factor"] - 1) < 2e-3
    assert abs(strehl_grid(g) - wf.strehl_direct()) < 5e-3


def test_opd_invariant_to_constant():
    c, src, rays = _chain(n_rays=801)
    wf = wavefront(rays, LAM, "plane", z_ref=c["l2"].z_back + 1.0)
    for k in (0.37, -12.0):
        assert abs(wf.rms("power", wf.opd + k) - wf.rms("power")) < 1e-15
        assert abs(wf.strehl_direct(wf.opd + k) - wf.strehl_direct()) < 1e-12


def test_reverse_light_new_chain():
    c, src, rays = _chain(n_rays=101)
    rev = OpticalSystem()
    rev.surfaces = c["full"].surfaces[::-1]
    for r in rays:
        if r.status != ALIVE:
            continue
        start = r.point_at(10.0)
        back = rev.trace(Ray(start, -r.direction, n=r.n))
        assert back.status == ALIVE
        t = -back.z / back.direction[1]
        assert abs((back.position + t * back.direction)[0]) < 1e-9
        assert abs((back.opl() + t) - (r.opl() + 10.0)) < 1e-9


def test_eikonal_new_chain():
    c, src, rays = _chain(n_rays=2401)
    wf = wavefront(rays, LAM, "plane", z_ref=c["l2"].z_back + 1.0)
    side = wf.x > 0
    o = np.argsort(wf.x[side])
    x, opl = wf.x[side][o], wf.opl[side][o]
    sin_t = np.array([r.direction[0] for r in np.array(wf.rays, dtype=object)[side][o]])
    err = np.abs(np.gradient(opl, x)[2:-2] - sin_t[2:-2])
    assert err.max() < 2e-3 * np.abs(sin_t).max() + 1e-7


# ========================================================================== #
# Facteurs 2 et √2 ; seconds moments du champ ; référence sphérique
# ========================================================================== #
def test_factor_relations_gaussian():
    """Faisceau gaussien collimaté idéal (rayon 1/e² w) :
    D4σ = 2w, D_fit = 2w, σx = w/2, σθ,amp = λ/(2πw), M² = 1."""
    w = 4.0
    system = OpticalSystem([Aperture(10.0, 1e3)])
    src = CollimatedSource(z=0.0, half_width=3.5 * w, n_rays=1601, w=w)
    rays = system.trace(src.generate_rays())
    b = beam_stats(rays, 20.0)
    assert abs(b.d4sigma / (2 * w) - 1) < 1e-4
    assert abs(b.d_fit / (2 * w) - 1) < 1e-3
    wf = wavefront(rays, LAM, "plane", z_ref=20.0)
    fm = field_moments(wf)
    assert abs(fm.sigma_x / (w / 2) - 1) < 1e-4
    assert abs(fm.sigma_theta_amp / (LAM / (2 * np.pi * w)) - 1) < 1e-3
    assert fm.sigma_theta_geo == 0.0 and abs(fm.m2 - 1) < 1e-3 and not fm.hard_edge


def test_factor_relations_fiber_far_field():
    """Source fibrée en espace libre, plan à L : marqueurs ±θ0 -> D = 2 L tanθ0 ;
    divergence par axe σθx ≈ θ0/2 ; radiale RMS ≈ θ0/√2 (petits angles)."""
    src = GaussianFiberSource(wavelength=1e-4, mfd=0.02, n_rays=2001)       # θ0 ≈ 3,2 mrad
    rays = OpticalSystem([Aperture(50.0, 1e3)]).trace(src.generate_rays())
    L = 100.0
    b = beam_stats(rays, L, src)
    assert abs(b.d_1e2_markers - 2 * L * np.tan(src.theta0)) < 1e-9
    assert abs(b.sigma_theta_x / (src.theta0 / 2) - 1) < 2e-3
    assert abs(b.theta_rms / (src.theta0 / np.sqrt(2)) - 1) < 2e-3
    assert abs(b.d4sigma / b.d_1e2_markers - 1) < 2e-3


def test_m2_invariant_geometric_transport_free_space():
    c, src, rays = _chain(n_rays=2401)
    z0 = c["l2"].z_back
    m = [field_moments(wavefront(rays, LAM, "plane", z_ref=z0 + dz)).m2 for dz in (1.0, 50.0)]
    assert abs(m[1] - m[0]) < 0.01 * m[0]


def test_m2_independent_of_sampling():
    """Le terme d'amplitude ignore les rayons de puissance nulle (rayon chef de
    l'échantillonnage à puissance égale) : M² identique dans les deux cas."""
    m = {}
    for sampling in ("angle", "power"):
        c, src, rays = _chain(n_rays=2401, sampling=sampling)
        m[sampling] = field_moments(wavefront(rays, LAM, "plane", z_ref=c["l2"].z_back + 1.0)).m2
    assert abs(m["power"] / m["angle"] - 1) < 0.01, m


def test_best_sphere_reference():
    """Point source à L du plan : défocus -> R ≈ L (> 0, divergent) ; la sphère
    ajustée centrée près de la source annule presque l'OPD."""
    src = PointSource(0.0, 0.0, theta_max=np.deg2rad(2), n_rays=81)
    rays = OpticalSystem([Aperture(10.0, 1e3)]).trace(src.generate_rays())
    L = 200.0
    wf = wavefront(rays, LAM, "plane", z_ref=L)
    R = defocus_radius(wf)
    assert R > 0 and abs(R / L - 1) < 1e-3
    wfs = best_sphere_wavefront(rays, LAM, L)
    assert wfs.rms("area") < 1e-3 * wf.rms("area")


def test_axial_ray_exactly_zero():
    for n in (401, 1201, 2401):
        assert chain.make_source(n_rays=n).angles()[n // 2] == 0.0
        assert CollimatedSource(z=0, half_width=5.0, n_rays=n).heights()[n // 2] == 0.0


if __name__ == "__main__":
    warnings.simplefilter("ignore")
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        setup_function(fn)
        fn()
        print(f"OK  {name}")
    print(f"\n{len(tests)} tests réussis.")
