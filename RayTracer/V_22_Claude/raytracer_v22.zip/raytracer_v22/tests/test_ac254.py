"""Test G : AC254-060-B contre les spécifications constructeur.

Les données viennent de examples/lens_data.py (entrée "AC254-060-B"). Tant que ce
bloc n'est pas rempli, le test est sauté (SKIP), pas réussi.

Ce qui est comparable au modèle :
  * EFL paraxiale vs focale nominale (à la longueur d'onde de la fiche ;
    tolérance `efl_rel_tolerance` à élargir si les indices sont pris à une
    autre longueur d'onde) ;
  * BFL paraxiale vs BFL nominale (si fournie) ;
  * cohérence interne : foyer du tracé exact (h -> 0) == foyer paraxial ;
  * géométrie physique : épaisseurs au bord > 0 ;
  * un doublet achromatique a une LSA bien plus faible qu'un singulet de
    même focale et même ouverture (comparaison qualitative, pas une spec).
"""

import os
import sys
import importlib.util

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from optical_sim import (OpticalSystem, ThickLens, Ray, CollimatedSource,  # noqa: E402
                         focus_analysis, axis_crossing)


class SkipTest(Exception):
    pass


def _skip(msg):
    try:
        import pytest
        pytest.skip(msg)
    except ImportError:
        raise SkipTest(msg)


def _load_example():
    spec = importlib.util.spec_from_file_location(
        "ac254_060_b", os.path.join(ROOT, "examples", "ac254_060_b.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _system():
    mod = _load_example()
    miss = mod.missing_fields()
    if miss:
        _skip("DATA AC254-060-B incomplètes (" + ", ".join(miss) + ")")
    return mod, OpticalSystem([mod.build_ac254_060_b()])


def test_G_efl_bfl_vs_spec():
    mod, system = _system()
    d = mod.DATA
    par = system.paraxial()
    assert abs(par["EFL"] - d["efl_nominal"]) / d["efl_nominal"] < d["efl_rel_tolerance"], par["EFL"]
    if d["bfl_nominal"] is not None:
        assert abs(par["BFD"] - d["bfl_nominal"]) < d["bfl_abs_tolerance"], par["BFD"]


def test_G_exact_trace_matches_paraxial_and_geometry():
    mod, system = _system()
    lens = system.elements[0]
    assert all(t > 0 for t in lens.edge_thicknesses())
    ray = system.trace(Ray([1e-4, -50.0], [0.0, 1.0]))
    assert abs(axis_crossing(ray) - system.paraxial()["z_back_focus"]) < 1e-6


def test_G_doublet_less_spherical_aberration_than_singlet():
    mod, system = _system()
    d = mod.DATA
    ca = d["clear_aperture"] or d["diameter"]
    src = CollimatedSource(z=-10.0, half_width=0.4 * ca, n_rays=21)
    lsa_doublet = focus_analysis(system.trace_bundle(src), system=system, source=src).lsa
    # singulet biconvexe symétrique de même EFL dans le verre 1 (référence qualitative)
    n, efl = mod.lens_data.lens_indices(d)[0], system.paraxial()["EFL"]
    R = 2 * (n - 1) * efl            # lentille mince : 1/f = (n-1) 2/R
    single = OpticalSystem([ThickLens(R, -R, d["tc1"], n, aperture=ca)])
    lsa_single = focus_analysis(single.trace_bundle(src), system=single, source=src).lsa
    assert abs(lsa_doublet) < abs(lsa_single)


if __name__ == "__main__":
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        try:
            fn()
            print(f"OK    {name}")
        except BaseException as e:                  # SkipTest ou pytest Skipped (BaseException)
            if type(e).__name__ not in ("SkipTest", "Skipped"):
                raise
            print(f"SKIP  {name} : {e}")
