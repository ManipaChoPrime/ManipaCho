"""Source ponctuelle : un éventail de rayons issus d'un même point."""

from __future__ import annotations

import numpy as np

from .ray import Ray


class PointSource:
    """Source ponctuelle en (x, z), dans un milieu d'indice n.

    Les angles sont mesurés depuis l'axe +z, positifs vers +x :
        direction = (sin theta, cos theta)
    et uniformément répartis dans [theta_center - theta_max, theta_center + theta_max].
    (Pour un éventail vers -z, prendre theta_center = pi.)
    """

    def __init__(self, x: float = 0.0, z: float = 0.0, theta_max: float = np.deg2rad(10),
                 n_rays: int = 101, n: float = 1.0, theta_center: float = 0.0):
        self.x = float(x)
        self.z = float(z)
        self.theta_max = float(theta_max)
        self.n_rays = int(n_rays)
        self.n = float(n)
        self.theta_center = float(theta_center)

    @property
    def position(self) -> np.ndarray:
        return np.array([self.x, self.z])

    def angles(self) -> np.ndarray:
        if self.n_rays == 1:
            return np.array([self.theta_center])
        return self.theta_center + np.linspace(-self.theta_max, self.theta_max, self.n_rays)

    def generate_rays(self) -> list[Ray]:
        return [Ray(self.position, (np.sin(th), np.cos(th)), n=self.n) for th in self.angles()]


class CollimatedSource:
    """Faisceau de rayons parallèles (objet à l'infini).

    Les rayons partent du plan z = z, aux hauteurs x uniformément réparties
    dans [x_center - half_width, x_center + half_width], tous avec la même
    direction d'angle `theta` (mesuré depuis +z, positif vers +x).
    Pour theta = 0, l'image paraxiale est le foyer image du système.
    """

    def __init__(self, z: float, half_width: float, n_rays: int = 101,
                 theta: float = 0.0, x_center: float = 0.0, n: float = 1.0,
                 w: float = None):
        self.z = float(z)
        self.half_width = float(half_width)
        self.n_rays = int(n_rays)
        self.theta = float(theta)
        self.x_center = float(x_center)
        self.n = float(n)
        self.w = None if w is None else float(w)   # rayon 1/e² d'un profil gaussien (optionnel)

    def weight(self, x, mode: str = "cut"):
        """Poids d'un faisceau gaussien collimaté de rayon 1/e² w, centré en x_center.

        "cut"    : I(x) ∝ exp(-2 (x - xc)² / w²)  (coupe méridienne, moments)
        "radial" : I(r) |r|  avec r = x - xc  (puissance dans l'anneau 2π r dr ;
                   exact pour un faisceau de révolution centré sur l'axe d'un
                   système de révolution, rayons méridiens)
        Sans w, tous les poids valent 1 ("cut") ou |r| ("radial").
        """
        r = np.asarray(x, dtype=float) - self.x_center
        I = np.ones_like(r) if self.w is None else np.exp(-2.0 * r**2 / self.w**2)
        if mode == "radial":
            return I * np.abs(r)
        if mode != "cut":
            raise ValueError("mode ∈ {'cut', 'radial'}")
        return I

    def ray_weights(self, rays, mode: str = "cut") -> np.ndarray:
        from .beam import source_ray
        return self.weight([source_ray(r).history[0].position[0] for r in rays], mode)

    def heights(self) -> np.ndarray:
        if self.n_rays == 1:
            return np.array([self.x_center])
        return self.x_center + np.linspace(-self.half_width, self.half_width, self.n_rays)

    def generate_rays(self) -> list[Ray]:
        d = (np.sin(self.theta), np.cos(self.theta))
        return [Ray((x, self.z), d, n=self.n) for x in self.heights()]


class GaussianFiberSource(PointSource):
    """Sortie de fibre monomode : source ponctuelle + POIDS gaussiens.

    MODÈLE
    ------
    * Le mode est approché par un faisceau gaussien de waist w0 = MFD / 2 situé
      sur la face de la fibre (point (x, z)).
    * Divergence gaussienne (demi-angle à 1/e² en intensité, champ lointain,
      approximation paraxiale) :
            theta0 = lambda0 / (pi * w0)
      C'est une propriété du MODE, distincte de l'ouverture numérique nominale
      de la fibre (NA = sin de l'angle d'acceptance du guide, définie par le
      profil d'indice). `na_nominal` n'est conservée qu'à titre d'information
      et n'intervient dans aucun calcul.
    * Intensité angulaire en champ lointain :  I(theta) ∝ exp(-2 theta² / theta0²).
    * Les rayons sont des directions uniformément espacées dans
      [-k theta0, +k theta0] (k = theta_factor, 3 par défaut : la puissance hors
      du cône est exp(-2 k²) ≈ 1.5e-8). Chaque rayon porte un poids.

    POIDS (fonction `weight(theta, mode)`)
    ---------------------------------------
    * mode="cut"    : w ∝ I(theta).  Profil dans une coupe méridienne (1D).
                      Sert aux moments du second ordre : D4σ = 4 sqrt(<x²>).
    * mode="radial" : w ∝ I(theta) |sin theta|.  Puissance dans le cône
                      élémentaire 2π sin(theta) dtheta : pour un point source
                      SUR L'AXE d'un système de révolution, tous les rayons sont
                      méridiens, chaque rayon tracé représente donc tout un
                      cône et ce poids donne des fractions de puissance 3D
                      exactes (au sens de l'optique géométrique).
    Les longueurs suivent l'unité du reste du code (mm dans les exemples) :
    wavelength et mfd sont donc à donner dans cette unité.
    """

    def __init__(self, x: float = 0.0, z: float = 0.0, wavelength: float = 1.03e-3,
                 mfd: float = 6e-3, n_rays: int = 401, theta_factor: float = 3.0,
                 n: float = 1.0, na_nominal: float = None):
        self.wavelength = float(wavelength)
        self.mfd = float(mfd)
        self.w0 = self.mfd / 2.0
        self.theta0 = self.wavelength / (np.pi * self.w0)
        self.theta_factor = float(theta_factor)
        self.na_nominal = na_nominal
        super().__init__(x=x, z=z, theta_max=self.theta_factor * self.theta0,
                         n_rays=n_rays, n=n)

    @property
    def rayleigh_range(self) -> float:
        """z_R = pi w0² / lambda (dans le vide), longueur de Rayleigh du waist de fibre."""
        return np.pi * self.w0**2 / self.wavelength

    def weight(self, theta, mode: str = "cut"):
        theta = np.asarray(theta, dtype=float)
        w = np.exp(-2.0 * theta**2 / self.theta0**2)
        if mode == "radial":
            w = w * np.abs(np.sin(theta))
        elif mode != "cut":
            raise ValueError("mode ∈ {'cut', 'radial'}")
        return w

    def ray_weights(self, rays, mode: str = "cut") -> np.ndarray:
        from .beam import source_theta
        return self.weight([source_theta(r) for r in rays], mode)
