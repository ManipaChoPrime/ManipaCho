"""Analyse géométrique d'un faisceau : position x(z), diamètres, clipping, divergence.

Tout ici reste de l'OPTIQUE GÉOMÉTRIQUE pondérée : pas de diffraction, pas
de phase. Les diamètres "gaussiens" sont des images géométriques du cône à
1/e² de la source ; ils coïncident avec le diamètre d'un vrai faisceau
gaussien tant que l'on est loin de tout point de focalisation, que les
distances restent petites devant la longueur de Rayleigh du faisceau
considéré, et que les aberrations sont faibles.

DÉFINITIONS DES DIAMÈTRES
-------------------------
* D_1e2(z) = |x(+theta0, z)| + |x(-theta0, z)| : écart entre les deux rayons
  lancés exactement à ±theta0 (interpolés en angle initial). C'est le
  diamètre 1/e² du faisceau tant que l'application theta -> x reste
  monotone. Indéfini si l'un de ces rayons est bloqué avant z.
* D4σ(z) = 4 sqrt(<x²>_w) (moment du 2nd ordre, coupe méridienne, poids "cut"),
  calculé sur les rayons PRÉSENTS en z (les rayons arrêtés sont exclus).
  Pour un profil gaussien d'intensité exp(-2x²/w²), <x²> = w²/4 donc
  D4σ = 2w = D_1e2. Il diminue si les ailes sont coupées.
* D_env(z) = 2 max|x| des rayons présents (enveloppe géométrique, dépend de
  theta_factor : c'est l'étendue du tracé, pas une grandeur du faisceau).

CLIPPING GAUSSIEN — RÉFÉRENCE ANALYTIQUE
----------------------------------------
Faisceau gaussien circulaire de rayon 1/e² w, CENTRÉ sur une ouverture
circulaire de rayon a, profil non aberré :
        T = 1 - exp(-2 a² / w²)
Le calcul par rayons pondérés (poids "radial") est l'estimation géométrique
générale ; il ne coïncide avec la formule que sous ces hypothèses.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .ray import Ray, ALIVE


def source_ray(ray):
    """Rayon d'origine (suit les liens `parent` créés par restart_rays)."""
    while getattr(ray, "parent", None) is not None:
        ray = ray.parent
    return ray


def source_theta(ray) -> float:
    """Angle initial du rayon À LA SOURCE (suit les liens `parent` créés par
    restart_rays, pour qu'un rayon redémarré garde le poids de son origine)."""
    return source_ray(ray).theta_initial


def weighted_transmission(rays, source) -> float:
    """Fraction de puissance transmise (poids "radial" de la source) :
    rayons ressortis du système / tous les rayons tracés."""
    w = source.ray_weights(rays, "radial")
    ok = np.array([r.status == ALIVE for r in rays])
    return float(w[ok].sum() / w.sum())


# ============================================================================
# Position d'un rayon dans un plan z
# ============================================================================
def x_at_z(ray, z: float, extend: bool = True, extend_blocked: bool = False) -> Optional[float]:
    """Hauteur x du rayon dans le plan z, ou None s'il n'y passe pas.

    On cherche le segment de l'historique qui contient z (interpolation
    linéaire, exacte puisque les segments sont rectilignes). Au-delà du
    dernier point, un rayon VIVANT est prolongé en ligne droite (extend=True) ;
    un rayon arrêté (MISSED/TIR) n'existe pas au-delà de son dernier point,
    sauf si extend_blocked=True (prolongement géométrique de son dernier
    segment, utile pour mesurer le faisceau incident sur l'ouverture qui l'a arrêté).
    Suppose que z varie de façon monotone le long du rayon (cas séquentiel
    standard, rayons allant vers +z).
    """
    h = ray.history
    for k in range(1, len(h)):
        z0, z1 = h[k - 1].position[1], h[k].position[1]
        if min(z0, z1) <= z <= max(z0, z1) and z1 != z0:
            s = (z - z0) / (z1 - z0)
            return float(h[k - 1].position[0] + s * (h[k].position[0] - h[k - 1].position[0]))
    last = h[-1]
    if extend and (ray.status == ALIVE or extend_blocked) and z >= last.position[1]:
        dx, dz = ray.direction
        if dz <= 1e-15:
            return None
        return float(last.position[0] + (z - last.position[1]) * dx / dz)
    if len(h) == 1 and z == h[0].position[1]:
        return float(h[0].position[0])
    return None


def direction_at_z(ray, z: float) -> Optional[np.ndarray]:
    """Direction (dx, dz) du segment du rayon qui traverse le plan z (None sinon)."""
    h = ray.history
    for k in range(1, len(h)):
        z0, z1 = h[k - 1].position[1], h[k].position[1]
        if min(z0, z1) <= z <= max(z0, z1) and z1 != z0:
            return h[k - 1].direction.copy()
    if ray.status == ALIVE and z >= h[-1].position[1]:
        return ray.direction.copy()
    return None


def gaussian_transmission(a: float, w: float) -> float:
    """T = 1 - exp(-2 a²/w²) : faisceau gaussien centré, ouverture circulaire."""
    return float(1.0 - np.exp(-2.0 * a**2 / w**2))


# ============================================================================
# Diamètres en fonction de z
# ============================================================================
@dataclass
class BeamProfile:
    z: np.ndarray
    d_1e2: np.ndarray        # diamètre des rayons ±theta0 (NaN si indéfini)
    d4sigma: np.ndarray      # 4 sqrt(<x²>) pondéré "cut" sur les rayons présents
    d_env: np.ndarray        # enveloppe géométrique des rayons présents
    n_present: np.ndarray    # nombre de rayons présents en z


def _theta0_ray_heights(rays, theta0, z, first_surface=None):
    """Hauteurs interpolées des rayons ±theta0 dans le plan z (NaN si impossible).

    first_surface : si donné, faisceau INCIDENT sur l'élément commençant à
    cette surface : les rayons qui l'ont atteint sont prolongés jusqu'à z même
    s'ils y ont été arrêtés ; ceux arrêtés avant sont exclus."""
    out = []
    for sign in (+1, -1):
        th, xs = [], []
        for r in rays:
            t = source_theta(r) * sign
            if t < 0:
                continue
            if first_surface is None:
                x = x_at_z(r, z)
            elif r.blocked_at is not None and r.blocked_at < first_surface:
                x = None
            else:
                x = x_at_z(r, z, extend_blocked=True)
            th.append(t)
            xs.append(np.nan if x is None else x)
        th, xs = np.asarray(th), np.asarray(xs)
        order = np.argsort(th)
        th, xs = th[order], xs[order]
        # rayons encadrant theta0, tous deux présents
        i = np.searchsorted(th, theta0)
        if i == 0 or i >= len(th) or np.isnan(xs[i - 1]) or np.isnan(xs[i]):
            out.append(np.nan)
        else:
            s = (theta0 - th[i - 1]) / (th[i] - th[i - 1])
            out.append(xs[i - 1] + s * (xs[i] - xs[i - 1]))
    return out


def beam_profile(rays, source, zs) -> BeamProfile:
    """Diamètres du faisceau dans chaque plan de `zs` (voir définitions en tête)."""
    zs = np.atleast_1d(np.asarray(zs, dtype=float))
    w_cut = source.ray_weights(rays, "cut")
    d1, d4, de, npres = [], [], [], []
    for z in zs:
        xs = np.array([np.nan if (x := x_at_z(r, z)) is None else x for r in rays])
        ok = ~np.isnan(xs)
        npres.append(int(ok.sum()))
        if ok.sum() < 2:
            d4.append(np.nan); de.append(np.nan); d1.append(np.nan)
            continue
        w = w_cut[ok]
        xm = np.sum(w * xs[ok]) / np.sum(w)
        d4.append(4.0 * np.sqrt(np.sum(w * (xs[ok] - xm) ** 2) / np.sum(w)))
        de.append(2.0 * np.max(np.abs(xs[ok])))
        xp, xn = _theta0_ray_heights(rays, source.theta0, z)
        d1.append(abs(xp - xn) if not (np.isnan(xp) or np.isnan(xn)) else np.nan)
    return BeamProfile(zs, np.array(d1), np.array(d4), np.array(de), np.array(npres))


# ============================================================================
# Clipping par élément
# ============================================================================
@dataclass
class ClipEntry:
    name: str
    semi_aperture: float
    z_entry: float
    w_entry: float           # rayon 1/e² (rayons ±theta0) au 1er sommet de l'élément
    w_worst: float           # rayon 1/e² à la surface la plus défavorable (a/w minimal)
    n_blocked: int
    p_incident: float        # fraction de la puissance source arrivant sur l'élément
    p_blocked: float         # fraction de la puissance source arrêtée par l'élément
    t_rays: float            # transmission mesurée (rayons pondérés) = 1 - blocked/incident
    t_analytic: float        # 1 - exp(-2 a²/w²) à la surface la plus défavorable (réf., cas centré)


@dataclass
class ClipReport:
    entries: list
    transmitted: float       # fraction de la puissance source transmise par tout le système
    lost_outside_fan: float  # puissance hors du cône tracé (exp(-2 k²)) : non comptée

    def table(self) -> str:
        lines = [f"{'élément':<22}{'a (mm)':>8}{'w entrée':>10}{'w max':>8}{'T rayons':>11}{'T analyt.':>11}{'rayons coupés':>15}"]
        for e in self.entries:
            lines.append(f"{e.name:<22}{e.semi_aperture:>8.3f}{e.w_entry:>10.3f}{e.w_worst:>8.3f}"
                         f"{e.t_rays:>11.5f}{e.t_analytic:>11.5f}{e.n_blocked:>15d}")
        lines.append(f"transmission totale (rayons pondérés) : {self.transmitted:.5f}"
                     f"   [hors cône tracé : {self.lost_outside_fan:.1e}]")
        return "\n".join(lines)


def clipping_report(system, rays, source) -> ClipReport:
    """Bilan de puissance par élément (poids "radial", source sur l'axe).

    Pour chaque élément : puissance incidente (rayons qui l'atteignent),
    puissance arrêtée (rayons dont blocked_at est une de ses surfaces), et
    transmission T_rays = 1 - P_arrêtée / P_incidente, comparée à la formule
    analytique 1 - exp(-2 a²/w²) évaluée À CHAQUE SURFACE de l'élément (w =
    rayon 1/e² au sommet de la surface, a = sa demi-ouverture), en gardant la
    plus défavorable : dans une lentille épaisse divergente, le faisceau
    s'élargit d'une surface à l'autre et c'est souvent la dernière qui coupe.
    La comparaison n'a de sens que si le faisceau est centré, gaussien, peu
    aberré, et pas déjà tronqué en amont (sinon la formule surestime les pertes).
    """
    w_rad = source.ray_weights(rays, "radial")
    total = w_rad.sum()
    blocked_at = np.array([-1 if r.blocked_at is None else r.blocked_at for r in rays])
    entries = []
    for el in system.elements:
        idx = system.element_surface_indices(el)
        first = idx[0]
        # un rayon atteint l'élément s'il n'a pas été arrêté avant sa 1re surface
        reached = (blocked_at < 0) | (blocked_at >= first)
        blocked = np.isin(blocked_at, idx)
        p_inc = w_rad[reached].sum() / total
        p_blk = w_rad[blocked].sum() / total
        z_e = system.surfaces[first].z_vertex
        ws, ts = [], []
        for i in idx:
            surf = system.surfaces[i]
            xp, xn = _theta0_ray_heights(rays, source.theta0, surf.z_vertex, first_surface=first)
            w_i = 0.5 * abs(xp - xn) if not (np.isnan(xp) or np.isnan(xn)) else np.nan
            ws.append(w_i)
            ts.append(gaussian_transmission(surf.semi_aperture, w_i) if np.isfinite(w_i) else np.nan)
        k_worst = int(np.nanargmin(ts)) if np.any(np.isfinite(ts)) else 0
        entries.append(ClipEntry(
            name=el.name or type(el).__name__, semi_aperture=el.semi_aperture, z_entry=z_e,
            w_entry=ws[0], w_worst=ws[k_worst],
            n_blocked=int(blocked.sum()), p_incident=p_inc, p_blocked=p_blk,
            t_rays=1.0 - p_blk / p_inc if p_inc > 0 else np.nan,
            t_analytic=ts[k_worst]))
    transmitted = w_rad[blocked_at < 0].sum() / total
    return ClipReport(entries, transmitted, float(np.exp(-2 * source.theta_factor**2)))


# ============================================================================
# Divergence de sortie
# ============================================================================
@dataclass
class Divergence:
    x: np.ndarray            # hauteur au plan de référence
    theta: np.ndarray        # angle de sortie (rad)
    weight: np.ndarray       # poids "cut" (1 si pas de source gaussienne)
    theta_rms: float         # sqrt(<theta²>_w)
    theta_1e2: float         # demi-différence des angles des rayons ±theta0 (NaN si absent)


def output_divergence(rays, z_ref: float, source=None) -> Divergence:
    """Angles des rayons transmis AU PLAN z_ref (direction du segment qui le
    traverse), en fonction de leur hauteur en z_ref. Seuls les rayons qui
    sortent du système (statut ALIVE) sont comptés."""
    xs, th, ti = [], [], []
    for r in rays:
        if r.status != ALIVE:
            continue
        x = x_at_z(r, z_ref)
        if x is None:
            continue
        d = direction_at_z(r, z_ref)
        xs.append(x)
        th.append(float(np.arctan2(d[0], d[1])))
        ti.append(source_theta(r))
    xs, th, ti = map(np.asarray, (xs, th, ti))
    if source is not None and hasattr(source, "theta0"):
        w = source.weight(ti, "cut")
        order = np.argsort(ti)
        t1 = 0.5 * (np.interp(source.theta0, ti[order], th[order])
                    - np.interp(-source.theta0, ti[order], th[order]))
    elif source is not None and hasattr(source, "ray_weights"):
        alive_rays = [r for r in rays if r.status == ALIVE and x_at_z(r, z_ref) is not None]
        w = source.ray_weights(alive_rays, "cut")
        t1 = np.nan
    else:
        w = np.ones_like(th)
        t1 = np.nan
    rms = float(np.sqrt(np.sum(w * th**2) / np.sum(w))) if len(th) else np.nan
    return Divergence(xs, th, w, rms, float(t1))


# ============================================================================
# Redémarrage : sortie d'un sous-système -> entrée du suivant
# ============================================================================
def restart_rays(rays) -> list:
    """Nouveaux objets Ray partant de la position / direction / indice actuels
    des rayons VIVANTS (pour tracer un sous-système séparément).
    L'attribut `parent` garde le lien vers le rayon d'origine."""
    out = []
    for r in rays:
        if r.status != ALIVE:
            continue
        nr = Ray(r.position, r.direction, n=r.n)
        nr.parent = r
        out.append(nr)
    return out
