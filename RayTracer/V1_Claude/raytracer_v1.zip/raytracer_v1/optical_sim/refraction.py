"""Loi de Snell-Descartes sous forme vectorielle.

ÉQUATION UTILISÉE
-----------------
Soit d la direction incidente (unitaire), N la normale unitaire à la
surface au point d'incidence, ORIENTÉE CONTRE le rayon (d . N < 0),
et eta = n1 / n2.

    cos_i = -d . N                         (cosinus de l'angle d'incidence, >= 0)
    k     = 1 - eta^2 (1 - cos_i^2)        (= cos_t^2, cosinus² de l'angle réfracté)

    si k < 0 : réflexion totale interne (pas de rayon transmis)
    sinon    : t = eta d + (eta cos_i - sqrt(k)) N

JUSTIFICATION
-------------
On décompose d en partie tangentielle d_par = d + cos_i N et normale
-cos_i N. La loi de Snell n1 sin(i) = n2 sin(t) impose t_par = eta d_par
(conservation de la composante tangentielle de n * direction). La
composante normale de t est fixée par |t| = 1 : t_perp = -sqrt(k) N
(le rayon continue du même côté). En sommant :
    t = eta (d + cos_i N) - sqrt(k) N.
On vérifie que |t|^2 = eta^2 sin^2 i + k = 1.

ORIENTATION DE LA NORMALE
-------------------------
La fonction accepte une normale orientée dans un sens ou dans l'autre :
si d . N > 0, elle est retournée. Le résultat ne dépend donc que de la
géométrie, pas de la convention d'orientation de la normale, et le
même code marche pour une surface traversée vers +z ou vers -z.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class RefractionResult:
    direction: Optional[np.ndarray]   # direction transmise, None si TIR
    transmitted: bool                 # False en cas de réflexion totale interne
    cos_incidence: float              # cos(angle d'incidence) >= 0
    cos_transmission: Optional[float] # cos(angle de réfraction), None si TIR


def refract(ray_direction, surface_normal, n1: float, n2: float) -> RefractionResult:
    """Réfracte `ray_direction` (milieu n1) à travers une interface (vers n2).

    `surface_normal` peut être orientée dans un sens ou dans l'autre.
    Les deux vecteurs sont renormalisés par sécurité.
    """
    d = np.asarray(ray_direction, dtype=float)
    d = d / np.linalg.norm(d)
    N = np.asarray(surface_normal, dtype=float)
    N = N / np.linalg.norm(N)

    cos_i = -float(np.dot(d, N))
    if cos_i < 0.0:          # normale du mauvais côté : on la retourne
        N = -N
        cos_i = -cos_i
    cos_i = min(cos_i, 1.0)  # protection contre les erreurs d'arrondi

    eta = n1 / n2
    k = 1.0 - eta**2 * (1.0 - cos_i**2)

    if k < 0.0:
        return RefractionResult(None, False, cos_i, None)

    cos_t = np.sqrt(k)
    t = eta * d + (eta * cos_i - cos_t) * N
    t = t / np.linalg.norm(t)   # |t| = 1 analytiquement ; on nettoie l'arrondi
    return RefractionResult(t, True, cos_i, float(cos_t))
