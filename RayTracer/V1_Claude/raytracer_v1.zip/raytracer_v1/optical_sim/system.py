"""Système optique : liste ordonnée de surfaces, traversées séquentiellement.

Tracé SÉQUENTIEL : le rayon rencontre les surfaces dans l'ordre de la liste
(comme dans un logiciel de conception optique classique), pas "la surface la
plus proche".

On peut ajouter des surfaces isolées ou des éléments (Lens, ThickLens...) :
un élément est simplement "déplié" en ses surfaces.
"""

from __future__ import annotations

from typing import Optional
import warnings

import numpy as np

from .ray import Ray, MISSED, TIR, ALIVE
from .surface import SphericalSurface


class OpticalSystem:
    def __init__(self, items: Optional[list] = None):
        self.surfaces: list[SphericalSurface] = []
        self.elements: list = []          # éléments ajoutés (pour l'affichage / l'inspection)
        for it in items or []:
            self.add(it)

    def add(self, item) -> "OpticalSystem":
        """Ajoute une SphericalSurface ou un OpticalElement (en fin de liste)."""
        if isinstance(item, SphericalSurface):
            new = [item]
        elif hasattr(item, "surfaces"):
            new = list(item.surfaces)
            self.elements.append(item)
        else:
            raise TypeError(f"Objet non reconnu : {item!r}")
        if self.surfaces:
            last = self.surfaces[-1]
            if new[0].z_vertex <= last.z_vertex:
                warnings.warn("Surfaces non ordonnées en z : le tracé séquentiel suit "
                              "l'ordre d'ajout, vérifier que c'est voulu.")
            if not np.isclose(last.n2, new[0].n1):
                warnings.warn(f"Indices incohérents entre surfaces successives : "
                              f"{last.n2} puis {new[0].n1}.")
        self.surfaces.extend(new)
        return self

    # ------------------------------------------------------------------ #
    # Tracé
    # ------------------------------------------------------------------ #
    def trace(self, rays, z_final: Optional[float] = None):
        """Trace un Ray (retourne le Ray) ou une liste de Ray (retourne la liste).

        Les rayons sont modifiés EN PLACE (leur historique est complété) :
        ne pas tracer deux fois le même objet Ray.
        """
        if isinstance(rays, Ray):
            return self._trace_one(rays, z_final)
        return [self._trace_one(r, z_final) for r in rays]

    def trace_all(self, rays, z_final: Optional[float] = None) -> list:
        return [self._trace_one(r, z_final) for r in rays]

    def trace_bundle(self, source, z_final: Optional[float] = None) -> list:
        """Génère les rayons d'une source (PointSource, CollimatedSource) et les trace."""
        return self.trace_all(source.generate_rays(), z_final=z_final)

    def _trace_one(self, ray: Ray, z_final: Optional[float] = None) -> Ray:
        """À chaque surface :
          1. intersection exacte -> distance t (None : rayon perdu, statut MISSED)
          2. propagation rectiligne de t dans le milieu courant (n_segment = n courant)
          3. réfraction vectorielle ; réflexion totale : statut TIR et arrêt
        Si `z_final` est donné, les rayons survivants sont ensuite propagés
        jusqu'au plan z = z_final (s'il est devant eux).
        """
        for i, surf in enumerate(self.surfaces):
            if not ray.alive:
                break
            t = surf.intersect(ray.position, ray.direction)
            if t is None:
                ray.status = MISSED
                ray.history[-1].status = MISSED
                break

            ray.propagate(t, surface=i)
            result, n_in, n_out = surf.refract(ray.direction, ray.position)

            if not np.isclose(n_in, ray.n):
                warnings.warn(
                    f"Surface {i} : le rayon arrive avec n = {ray.n} mais la "
                    f"surface attend n = {n_in} de ce côté. Vérifier la "
                    f"cohérence des indices entre surfaces successives."
                )

            if result.transmitted:
                ray.update_after_surface(result.direction, n_out, ALIVE)
            else:
                ray.update_after_surface(None, n_in, TIR)
                break

        if z_final is not None and ray.alive:
            dz = ray.direction[1]
            if abs(dz) > 1e-15 and (z_final - ray.z) / dz > 0:
                ray.propagate_to_z(z_final)
        return ray

    # ------------------------------------------------------------------ #
    # Raccourcis vers les analyses
    # ------------------------------------------------------------------ #
    def intercept_at_plane(self, rays, z_final: float, **kw):
        from .opl import intercept_at_plane
        return intercept_at_plane(rays, z_final, **kw)

    def paraxial(self) -> dict:
        """Grandeurs cardinales paraxiales (EFL, BFD, FFD...) du système complet."""
        from .paraxial import cardinal
        return cardinal(self.surfaces)

    def paraxial_image(self, z_object: float) -> float:
        from .paraxial import image_position
        return image_position(self.surfaces, z_object)
