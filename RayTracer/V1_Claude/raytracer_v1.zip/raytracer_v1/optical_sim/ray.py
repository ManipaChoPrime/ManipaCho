"""Rayon lumineux 2D.

Un rayon est la demi-droite  r(t) = r0 + t * d,  t >= 0,
où r0 = (x, z) est la position courante et d = (dx, dz) une direction
UNITAIRE. Avec |d| = 1, le paramètre t est directement la distance
géométrique parcourue.

CHEMIN OPTIQUE (OPL) — CONVENTION
---------------------------------
L'historique est une suite d'événements E_0, E_1, ..., E_N (départ, puis
chaque surface ou plan atteint). Le segment k (de E_{k-1} à E_k) a une
longueur géométrique L_k = E_k.distance et il est parcouru dans le milieu
où se trouvait le rayon AVANT la réfraction en E_k. Cet indice est stocké
explicitement dans E_k.n_segment au moment de la propagation (donc avant
toute réfraction) :

    OPL = somme_{k=1..N}  E_k.n_segment * E_k.distance

E_k.n est, lui, l'indice du milieu dans lequel le rayon REPART après E_k
(c'est l'indice qui servira au segment suivant). On a donc toujours
E_k.n_segment == E_{k-1}.n, ce qui est vérifié par les tests.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

# Statuts possibles d'un rayon
ALIVE = "alive"      # toujours en propagation
MISSED = "missed"    # n'a pas rencontré une surface (ou hors ouverture)
TIR = "tir"          # réflexion totale interne : non transmis


def normalize(v) -> np.ndarray:
    """Retourne v / |v| ; lève une erreur pour un vecteur nul."""
    v = np.asarray(v, dtype=float)
    norm = np.hypot(v[0], v[1])
    if norm == 0.0:
        raise ValueError("Impossible de normaliser un vecteur nul.")
    return v / norm


@dataclass
class RayEvent:
    """Un point de l'historique du rayon.

    position  : point (x, z) atteint
    direction : direction (dx, dz) APRÈS l'événement (après réfraction)
    n         : indice du milieu dans lequel le rayon repart (après l'événement)
    distance  : longueur géométrique du segment qui vient d'être parcouru
                pour arriver à ce point (0 pour le point de départ)
    n_segment : indice du milieu dans lequel CE segment a été parcouru
    surface   : indice de la surface rencontrée (None si pas de surface :
                point de départ ou plan final)
    status    : statut du rayon après l'événement
    """

    position: np.ndarray
    direction: np.ndarray
    n: float
    distance: float
    surface: Optional[int]
    status: str = ALIVE
    n_segment: float = 1.0


@dataclass
class Ray:
    position: np.ndarray
    direction: np.ndarray
    n: float = 1.0
    status: str = ALIVE
    history: list = field(default_factory=list)

    def __post_init__(self):
        self.position = np.asarray(self.position, dtype=float).copy()
        self.direction = normalize(self.direction)
        if not self.history:
            self._record(distance=0.0, surface=None)

    # ------------------------------------------------------------------ #
    # Accès simples
    # ------------------------------------------------------------------ #
    @property
    def x(self) -> float:
        return float(self.position[0])

    @property
    def z(self) -> float:
        return float(self.position[1])

    @property
    def alive(self) -> bool:
        return self.status == ALIVE

    def point_at(self, t: float) -> np.ndarray:
        """Point r0 + t d (sans modifier le rayon)."""
        return self.position + t * self.direction

    @property
    def geometric_length(self) -> float:
        """Longueur géométrique totale parcourue depuis le départ."""
        return float(sum(ev.distance for ev in self.history))

    def path(self) -> np.ndarray:
        """Tableau (N, 2) des points successifs (x, z) de l'historique."""
        return np.array([ev.position for ev in self.history])

    @property
    def theta(self) -> float:
        """Angle courant de la direction avec +z (positif vers +x), en rad."""
        return float(np.arctan2(self.direction[0], self.direction[1]))

    @property
    def theta_initial(self) -> float:
        d = self.history[0].direction
        return float(np.arctan2(d[0], d[1]))

    def segments(self) -> list:
        """Liste des segments [(début, fin, n_segment, L), ...]."""
        h = self.history
        return [(h[k - 1].position, h[k].position, h[k].n_segment, h[k].distance)
                for k in range(1, len(h))]

    def opl(self) -> float:
        """Chemin optique total  OPL = somme n_k L_k  (voir convention en tête)."""
        return float(sum(ev.n_segment * ev.distance for ev in self.history[1:]))

    # ------------------------------------------------------------------ #
    # Propagation rectiligne dans un milieu homogène
    # ------------------------------------------------------------------ #
    def propagate(self, t: float, surface: Optional[int] = None) -> None:
        """Avance le rayon d'une distance t >= 0 le long de sa direction.

        La direction et l'indice ne changent pas ici : le changement de
        direction est fait séparément par la réfraction, puis enregistré
        par `update_after_surface`.
        """
        if t < 0:
            raise ValueError(f"Propagation vers l'arrière interdite (t = {t}).")
        self.position = self.point_at(t)
        self._record(distance=t, surface=surface)

    def propagate_to_z(self, z_target: float) -> None:
        """Propage le rayon jusqu'au plan z = z_target.

        t = (z_target - z) / dz. Lève une erreur si le plan est derrière le
        rayon ou si le rayon est parallèle au plan.
        """
        dz = self.direction[1]
        if abs(dz) < 1e-15:
            raise ValueError("Rayon parallèle au plan z = cste.")
        t = (z_target - self.z) / dz
        if t < -1e-12:
            raise ValueError("Le plan cible est derrière le rayon.")
        self.propagate(max(t, 0.0))

    def update_after_surface(self, new_direction, new_n: float, status: str = ALIVE) -> None:
        """Met à jour direction / indice / statut au point d'incidence courant,
        et répercute ces valeurs sur le dernier événement de l'historique."""
        if new_direction is not None:
            self.direction = normalize(new_direction)
        self.n = float(new_n)
        self.status = status
        last = self.history[-1]
        last.direction = self.direction.copy()
        last.n = self.n
        last.status = status

    def _record(self, distance: float, surface: Optional[int]) -> None:
        self.history.append(
            RayEvent(
                position=self.position.copy(),
                direction=self.direction.copy(),
                n=self.n,
                distance=float(distance),
                surface=surface,
                status=self.status,
                n_segment=self.n,   # indice du milieu traversé, AVANT réfraction
            )
        )
