"""Éléments optiques : groupes de surfaces sphériques consécutives.

Une seule abstraction suffit à ce stade :

    OpticalElement  — liste ordonnée de SphericalSurface + un nom
    Lens            — OpticalElement construit à partir d'une "prescription"
                      (rayons, épaisseurs, indices), comme dans une fiche constructeur
    ThickLens       — cas particulier à un seul verre (2 surfaces)

Ces objets ne font QUE fabriquer des surfaces correctement placées et
indexées. Le tracé reste celui de la V0 (OpticalSystem), entièrement
séquentiel. Aucune lentille réelle n'est codée ici : les données d'un
catalogue sont passées en paramètres par le script utilisateur.

CONVENTIONS (identiques à la V0)
--------------------------------
* z = axe optique, la lumière est supposée entrer par le côté -z.
* Rayons de courbure : convention "centre de courbure" :
      R > 0  -> centre vers +z  (surface convexe vue depuis -z)
      R < 0  -> centre vers -z  (surface concave vue depuis -z)
      R = np.inf -> surface plane
  Ainsi une lentille biconvexe a R1 > 0 et R2 < 0 (convention des fiches
  Thorlabs/Zemax, où la lumière arrive par la surface 1).
* thickness / thicknesses : épaisseurs AU CENTRE (sur l'axe), entre sommets.
* aperture : DIAMÈTRE utile (clear aperture), commun à toutes les surfaces.
* z_front : position z du sommet de la première surface.
"""

from __future__ import annotations

from typing import Optional, Sequence
import warnings

import numpy as np

from .surface import SphericalSurface


class OpticalElement:
    """Groupe ordonné de surfaces (ce que l'on ajoute à un OpticalSystem)."""

    def __init__(self, surfaces: Sequence[SphericalSurface], name: str = ""):
        self.surfaces = list(surfaces)
        self.name = name

    @property
    def z_front(self) -> float:
        return self.surfaces[0].z_vertex

    @property
    def z_back(self) -> float:
        return self.surfaces[-1].z_vertex

    @property
    def n_before(self) -> float:
        return self.surfaces[0].n1

    @property
    def n_after(self) -> float:
        return self.surfaces[-1].n2

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r}, {len(self.surfaces)} surfaces, z = {self.z_front:g} → {self.z_back:g})"


class Lens(OpticalElement):
    """Lentille générique à N surfaces et N-1 milieux intérieurs.

    Paramètres
    ----------
    radii       : [R1, ..., RN]  rayons de courbure (convention ci-dessus)
    thicknesses : [t1, ..., t_{N-1}]  épaisseurs au centre entre surfaces i et i+1
    n_glasses   : [n_1, ..., n_{N-1}]  indices des milieux entre surfaces i et i+1,
                  À LA LONGUEUR D'ONDE ÉTUDIÉE (fournis par l'utilisateur)
    n_before    : indice avant la 1re surface (air : 1.0)
    n_after     : indice après la dernière surface (par défaut = n_before)
    aperture    : diamètre utile (None : calotte maximale |R| pour chaque surface)
    z_front     : position du sommet de la 1re surface

    Exemple, doublet collé (3 surfaces, 2 verres) :
        Lens(radii=[R1, R2, R3], thicknesses=[tc1, tc2], n_glasses=[nA, nB])
    Exemple, dioptre seul (1 surface, aucun verre intérieur) :
        Lens(radii=[R], thicknesses=[], n_glasses=[], n_before=1.0, n_after=1.5)
    """

    def __init__(self, radii, thicknesses, n_glasses, n_before: float = 1.0,
                 n_after: Optional[float] = None, aperture: Optional[float] = None,
                 z_front: float = 0.0, name: str = ""):
        radii = [float(r) for r in radii]
        thicknesses = [float(t) for t in thicknesses]
        n_glasses = [float(n) for n in n_glasses]
        if len(radii) < 1:
            raise ValueError("Il faut au moins une surface.")
        if len(thicknesses) != len(radii) - 1 or len(n_glasses) != len(radii) - 1:
            raise ValueError("Il faut len(thicknesses) == len(n_glasses) == len(radii) - 1.")
        if any(t <= 0 for t in thicknesses):
            raise ValueError("Les épaisseurs au centre doivent être > 0.")
        n_after = n_before if n_after is None else float(n_after)

        media = [float(n_before)] + n_glasses + [n_after]   # media[i] = milieu avant la surface i
        semi = None if aperture is None else aperture / 2.0
        z = float(z_front)
        surfaces = []
        for i, R in enumerate(radii):
            surfaces.append(SphericalSurface(z, R, media[i], media[i + 1],
                                             semi_aperture=semi, name=f"{name} S{i + 1}".strip()))
            if i < len(thicknesses):
                z += thicknesses[i]
        super().__init__(surfaces, name)
        self.radii, self.thicknesses, self.n_glasses = radii, thicknesses, n_glasses
        self.aperture = aperture
        self._check_edge_thickness()

    def edge_thicknesses(self) -> list:
        """Épaisseurs au bord (à |x| = aperture/2) entre surfaces successives.

        t_edge,i = t_i + sag_{i+1}(h) - sag_i(h)  (avec sag mesurée depuis chaque sommet).
        """
        if self.aperture is None:
            return []
        h = self.aperture / 2.0
        out = []
        for i in range(len(self.surfaces) - 1):
            s1, s2 = self.surfaces[i], self.surfaces[i + 1]
            out.append(float(s2.sag(h) - s1.sag(h)))
        return out

    def _check_edge_thickness(self):
        for i, te in enumerate(self.edge_thicknesses()):
            if te <= 0:
                warnings.warn(f"{self.name or 'Lens'} : épaisseur au bord négative ou nulle "
                              f"entre S{i + 1} et S{i + 2} ({te:.4g}) : géométrie non physique "
                              f"pour l'ouverture choisie.")


class ThickLens(Lens):
    """Lentille épaisse à un seul verre (2 surfaces).

        ThickLens(R1, R2, thickness, n_glass, n_air=1.0, aperture=None, z_front=0.0)

    Biconvexe : R1 > 0, R2 < 0. Plan-convexe (convexe en entrée) : R1 > 0, R2 = np.inf.
    """

    def __init__(self, R1: float, R2: float, thickness: float, n_glass: float,
                 n_air: float = 1.0, aperture: Optional[float] = None,
                 z_front: float = 0.0, name: str = ""):
        super().__init__([R1, R2], [thickness], [n_glass], n_before=n_air,
                         aperture=aperture, z_front=z_front, name=name)
        self.R1, self.R2, self.thickness = float(R1), float(R2), float(thickness)
        self.n_glass, self.n_air = float(n_glass), float(n_air)

    def paraxial_formula(self) -> dict:
        """Formule analytique de la lentille épaisse (milieu extérieur n0 = n_air).

        Puissances des dioptres (convention de signe ci-dessus, 1/inf = 0) :
            P1 = (n - n0) / R1          P2 = (n0 - n) / R2
        Puissance totale (formule de Gullstrand) :
            P  = P1 + P2 - (d / n) P1 P2
        Focale effective (distance points principaux -> foyers, dans n0) :
            EFL = n0 / P
        Distances frontales mesurées depuis les sommets :
            BFD = EFL (1 - d P1 / n)    foyer image à  z_S2 + BFD
            FFD = EFL (1 - d P2 / n)    foyer objet à  z_S1 - FFD
        Plans principaux (depuis les sommets) :  dH' = BFD - EFL (depuis S2),
                                                 dH  = EFL - FFD (depuis S1).
        Pour n0 = 1 on retrouve 1/f = (n-1)[1/R1 - 1/R2 + (n-1) d / (n R1 R2)].
        """
        n, n0, d = self.n_glass, self.n_air, self.thickness
        P1 = (n - n0) / self.R1      # 1/inf = 0 en flottant : plan géré
        P2 = (n0 - n) / self.R2
        P = P1 + P2 - d / n * P1 * P2
        if P == 0:
            return dict(P=0.0, EFL=np.inf, BFD=np.inf, FFD=np.inf)
        efl = n0 / P
        bfd = efl * (1 - d * P1 / n)
        ffd = efl * (1 - d * P2 / n)
        return dict(P=P, EFL=efl, BFD=bfd, FFD=ffd,
                    z_back_focus=self.z_back + bfd, z_front_focus=self.z_front - ffd)
