"""optical_sim — ray tracer 2D non-paraxial (plan x-z), version V1.

CONVENTIONS GLOBALES (utilisées partout dans le package)
--------------------------------------------------------
* Repère : z = axe optique, x = coordonnée transverse. Lumière entrant par -z.
* Tous les vecteurs 2D sont des tableaux NumPy dans l'ordre (x, z).
* Une direction de rayon est toujours un vecteur unitaire (dx, dz).
* Angle d'un rayon : theta mesuré depuis +z, positif vers +x,
  donc direction = (sin theta, cos theta).
* Surface sphérique : sommet en z_vertex sur l'axe, rayon de courbure R
  (convention "centre de courbure") :
      R > 0 : centre en z_vertex + R, situé vers +z (convexe vue de -z)
      R < 0 : centre situé vers -z (concave vue de -z)
      R = inf : surface plane
* Indices : chaque surface porte n1 (milieu côté -z) et n2 (milieu côté +z).
* OPL = somme n_k L_k, avec n_k l'indice du milieu où le segment k est
  parcouru (RayEvent.n_segment, enregistré AVANT réfraction).
* Unités de longueur : arbitraires mais cohérentes (les exemples sont en mm).
"""

from .ray import Ray, RayEvent
from .refraction import refract, RefractionResult
from .surface import SphericalSurface
from .lens import OpticalElement, Lens, ThickLens
from .system import OpticalSystem
from .source import PointSource, CollimatedSource
from .opl import intercept_at_plane, PlaneIntercept
from .analysis import focus_analysis, FocusAnalysis, axis_crossing
from . import paraxial
from .plotting import plot_system, plot_rays, plot_focus, plot_opl

__all__ = [
    "Ray", "RayEvent", "refract", "RefractionResult", "SphericalSurface",
    "OpticalElement", "Lens", "ThickLens", "OpticalSystem",
    "PointSource", "CollimatedSource", "intercept_at_plane", "PlaneIntercept",
    "focus_analysis", "FocusAnalysis", "axis_crossing", "paraxial",
    "plot_system", "plot_rays", "plot_focus", "plot_opl",
]
