"""Chemin optique sur un plan commun : préparation de l'OPD (V2).

Pour chaque rayon tracé, on part de son point d'impact sur la DERNIÈRE
SURFACE traversée (E_s, ou du point de départ s'il n'a traversé aucune
surface) et on prolonge la droite de sortie jusqu'au plan z = z_plane,
sans modifier le rayon :

    t      = (z_plane - z_s) / dz_s                (distance le long du rayon)
    x      = x_s + t dx_s
    OPL    = OPL(départ -> E_s) + n_s * t

où n_s est l'indice du milieu après la dernière surface. Les éventuelles
propagations libres faites ensuite (z_final du tracé) sont ignorées : elles
sont sur la même droite, le résultat ne dépend donc pas de z_final.

Si t < 0, le plan est AVANT la dernière surface : le point d'intersection
est virtuel et la contribution n_s * t est négative.
C'est exactement ce qu'il faut pour une image virtuelle ou une sphère de
référence placée avant la sortie, mais ce n'est pas un trajet physique.
Par défaut ces rayons sont exclus ; `allow_virtual=True` les garde et les
signale dans `virtual`.

Remarque : l'OPL sur un plan n'est PAS encore un front d'onde. Les rayons
d'un front d'onde (surface d'OPL constant) n'arrivent pas tous sur le même
plan au même OPL ; l'OPD se définira en V2 par rapport à une sphère de
référence centrée sur le point image.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .ray import ALIVE


@dataclass
class PlaneIntercept:
    z_plane: float
    x: np.ndarray            # hauteur d'arrivée sur le plan
    theta: np.ndarray        # angle final de la direction avec +z (rad)
    opl: np.ndarray          # OPL depuis le point de départ jusqu'au plan
    n: np.ndarray            # indice du milieu au niveau du plan
    virtual: np.ndarray      # True si le plan est avant la dernière surface (t < 0)
    theta_initial: np.ndarray
    x_pupil: np.ndarray      # hauteur d'impact sur la 1re surface (NaN si aucune)
    ray_index: np.ndarray    # indice du rayon dans la liste d'origine
    rays: list               # objets Ray correspondants (historique complet)

    @property
    def z(self) -> np.ndarray:
        return np.full_like(self.x, self.z_plane)

    def __len__(self) -> int:
        return len(self.x)


def pupil_height(ray) -> float:
    """Hauteur x du rayon sur la première surface rencontrée."""
    for ev in ray.history[1:]:
        if ev.surface is not None:
            return float(ev.position[0])
    return np.nan


def last_surface_state(ray):
    """(position, direction, n, OPL) au départ de la dernière surface traversée."""
    h = ray.history
    k = max([i for i, ev in enumerate(h) if ev.surface is not None], default=0)
    opl = sum(ev.n_segment * ev.distance for ev in h[1:k + 1])
    return h[k].position, h[k].direction, h[k].n, float(opl)


def intercept_at_plane(rays, z_plane: float, allow_virtual: bool = False) -> PlaneIntercept:
    """Intersection de chaque rayon survivant avec le plan z = z_plane."""
    cols = {k: [] for k in ("x", "theta", "opl", "n", "virtual", "theta_initial",
                            "x_pupil", "ray_index", "rays")}
    for i, ray in enumerate(rays):
        if ray.status != ALIVE:
            continue
        pos, (dx, dz), n_s, opl_s = last_surface_state(ray)
        if abs(dz) < 1e-15:
            continue
        t = (z_plane - pos[1]) / dz
        virtual = t < -1e-12
        if virtual and not allow_virtual:
            continue
        cols["x"].append(pos[0] + t * dx)
        cols["theta"].append(float(np.arctan2(dx, dz)))
        cols["opl"].append(opl_s + n_s * t)
        cols["n"].append(n_s)
        cols["virtual"].append(virtual)
        cols["theta_initial"].append(ray.theta_initial)
        cols["x_pupil"].append(pupil_height(ray))
        cols["ray_index"].append(i)
        cols["rays"].append(ray)
    arr = {k: np.asarray(v) for k, v in cols.items() if k != "rays"}
    return PlaneIntercept(z_plane=float(z_plane), rays=cols["rays"], **arr)
