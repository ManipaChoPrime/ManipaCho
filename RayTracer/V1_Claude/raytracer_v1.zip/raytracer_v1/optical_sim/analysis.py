"""Analyse du foyer : z_f(theta), foyer paraxial, foyer marginal, LSA.

MÉTHODE
-------
Pour chaque rayon survivant, on prend sa position (x, z) et sa direction
(dx, dz) APRÈS la dernière surface (si le rayon a été propagé jusqu'à un
plan, c'est la même droite). Le croisement de cette droite avec l'axe x = 0 :

    z_f = z - x * dz / dx

Le rayon axial (dx = 0, x = 0) n'a pas de croisement défini : il est exclu.
Si z_f est avant la dernière surface, le croisement est VIRTUEL (rayons
divergents en sortie) ; il est conservé et signalé.

Cette analyse suppose un objet SUR L'AXE (source ponctuelle en x = 0 ou
faisceau collimaté d'angle 0) : c'est alors la symétrie de révolution qui
fait que tous les rayons recoupent l'axe. Pour un objet hors axe, le
croisement avec l'axe n'a pas de sens physique (ce sera le rôle de l'OPD).

DÉFINITIONS
-----------
* x_pupil : hauteur d'impact du rayon sur la 1re surface.
* foyer paraxial z_par : limite de z_f quand x_pupil -> 0. Il est pris
  analytiquement (matrices de transfert) si le système et l'objet sont
  fournis, sinon estimé par un ajustement polynomial z_f = a0 + a1 h^2 + a2 h^4
  (h = x_pupil), dont a0 est l'extrapolation à h = 0.
* foyer marginal z_marg : z_f du rayon de plus grand |x_pupil| ayant traversé.
* LSA (aberration sphérique longitudinale) : LSA = z_marg - z_par.
  Signe : LSA < 0 -> les rayons marginaux focalisent AVANT le foyer paraxial
  (sous-correction, cas typique d'une lentille simple convergente).
Aucune de ces grandeurs ne suppose que l'optique paraxiale est valable pour
les rayons marginaux : z_f vient toujours du tracé exact.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np

from .ray import ALIVE
from .opl import pupil_height


@dataclass
class FocusAnalysis:
    theta: np.ndarray        # angle initial de chaque rayon (rad)
    x_pupil: np.ndarray      # hauteur sur la 1re surface
    x_start: np.ndarray      # hauteur initiale (utile pour un faisceau collimaté)
    z_f: np.ndarray          # croisement avec l'axe
    virtual: np.ndarray      # croisement virtuel (avant la dernière surface)
    z_paraxial: float
    z_paraxial_fit: float    # extrapolation h -> 0 du tracé exact (contrôle)
    z_marginal: float
    paraxial_source: str     # "analytique" ou "extrapolation"

    @property
    def lsa(self) -> float:
        return self.z_marginal - self.z_paraxial

    def summary(self) -> str:
        return (f"foyer paraxial ({self.paraxial_source}) : z = {self.z_paraxial:.6g}\n"
                f"extrapolation h->0 du tracé exact  : z = {self.z_paraxial_fit:.6g}\n"
                f"foyer marginal (|h| = {np.max(np.abs(self.x_pupil)):.4g}) : z = {self.z_marginal:.6g}\n"
                f"LSA = z_marg - z_par = {self.lsa:.6g}")


def axis_crossing(ray) -> float:
    """z où la droite portant le dernier segment du rayon coupe x = 0 (NaN si parallèle)."""
    dx, dz = ray.direction
    if abs(dx) < 1e-14:
        return np.nan
    return ray.z - ray.x * dz / dx


def focus_analysis(rays, system=None, source=None, z_paraxial: Optional[float] = None,
                   fit_order: int = 4) -> FocusAnalysis:
    """Calcule z_f pour chaque rayon et les foyers paraxial / marginal.

    z_paraxial : valeur imposée ; sinon calculée analytiquement si `system` et
    `source` sont donnés (PointSource : image paraxiale de la source ;
    CollimatedSource d'angle 0 : foyer image) ; sinon extrapolée.
    """
    th, hp, x0, zf, virt = [], [], [], [], []
    z_last = None
    for ray in rays:
        if ray.status != ALIVE:
            continue
        z = axis_crossing(ray)
        if np.isnan(z):
            continue
        last_surface_z = max((ev.position[1] for ev in ray.history if ev.surface is not None),
                             default=ray.history[0].position[1])
        th.append(ray.theta_initial)
        hp.append(pupil_height(ray))
        x0.append(ray.history[0].position[0])
        zf.append(z)
        virt.append(z < last_surface_z)
        z_last = last_surface_z if z_last is None else max(z_last, last_surface_z)
    th, hp, x0, zf, virt = map(np.asarray, (th, hp, x0, zf, virt))
    if len(zf) < 2:
        raise ValueError("Pas assez de rayons utilisables pour l'analyse du foyer.")

    # Extrapolation h -> 0 (z_f est une fonction paire de h par symétrie).
    order = min(fit_order, max(1, len(zf) // 3))
    coeffs = np.polyfit(hp**2, zf, order)
    z_fit = float(np.polyval(coeffs, 0.0))

    source_label = "imposé"
    if z_paraxial is None and system is not None and source is not None:
        from .source import CollimatedSource
        if isinstance(source, CollimatedSource):
            if abs(source.theta) > 0:
                raise ValueError("Faisceau collimaté incliné : objet hors axe.")
            z_paraxial = system.paraxial()["z_back_focus"]
        else:
            if abs(source.x) > 0:
                raise ValueError("Source hors axe : z_f(axe) n'a pas de sens.")
            z_paraxial = system.paraxial_image(source.z)
        source_label = "analytique"
    if z_paraxial is None:
        z_paraxial, source_label = z_fit, "extrapolation"

    i_marg = int(np.argmax(np.abs(hp)))
    return FocusAnalysis(theta=th, x_pupil=hp, x_start=x0, z_f=zf, virtual=virt,
                         z_paraxial=float(z_paraxial), z_paraxial_fit=z_fit,
                         z_marginal=float(zf[i_marg]), paraxial_source=source_label)
