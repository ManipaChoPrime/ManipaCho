"""Tests V1 : lentilles (Lens, ThickLens) contre l'optique paraxiale.

Exécution :  python tests/test_lens.py   (ou  pytest tests/)

Principe : trois calculs indépendants doivent coïncider dans la limite
paraxiale — formule analytique écrite à la main, matrices de transfert
(paraxial.py) et tracé EXACT avec des rayons de très faible hauteur.
Les rayons marginaux ne sont jamais comparés aux formules paraxiales :
on vérifie seulement la convergence quand h -> 0 et le signe de la LSA.
"""

import os
import sys
import warnings

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from optical_sim import (Lens, ThickLens, OpticalSystem, Ray, PointSource,  # noqa: E402
                         CollimatedSource, focus_analysis, axis_crossing, paraxial)
from optical_sim.ray import ALIVE  # noqa: E402

N_BK7 = 1.5168   # valeur d'exemple (≈ N-BK7 à 587.6 nm), sans prétention de catalogue


def exact_back_focus(system, h=1e-4, z_start=-1e3):
    """Foyer image par tracé exact d'un rayon // axe à très faible hauteur."""
    ray = system.trace(Ray([h, z_start], [0.0, 1.0], n=system.surfaces[0].n1))
    assert ray.status == ALIVE
    return axis_crossing(ray)


def exact_front_focus(system, h=1e-4, z_start=1e3):
    """Foyer objet : rayon // axe venant de +z (tracé vers -z, à travers les
    surfaces dans l'ordre inverse)."""
    rev = OpticalSystem()
    rev.surfaces = system.surfaces[::-1]          # ordre séquentiel inversé
    ray = rev.trace(Ray([h, z_start], [0.0, -1.0], n=system.surfaces[-1].n2))
    assert ray.status == ALIVE
    return axis_crossing(ray)


def exact_image(system, z_obj, theta=1e-5):
    ray = system.trace(Ray([0.0, z_obj], [np.sin(theta), np.cos(theta)], n=system.surfaces[0].n1))
    return axis_crossing(ray)


# ========================================================================== #
# Test A — lentille à deux surfaces planes (lame)
# ========================================================================== #
def test_A_plane_plate():
    d, n = 5.0, 1.5
    plate = Lens([np.inf, np.inf], [d], [n], aperture=50, z_front=10.0)
    system = OpticalSystem([plate])

    # Puissance nulle
    assert abs(system.paraxial()["P"]) < 1e-15

    # Tracé exact à grands angles : direction de sortie = direction d'entrée,
    # et traversée de la lame conforme à Snell : dx_lame = d tan(theta_t)
    for th in np.deg2rad([0, 10, 30, 60]):
        ray = system.trace(Ray([0.0, 0.0], [np.sin(th), np.cos(th)]))
        assert np.allclose(ray.direction, [np.sin(th), np.cos(th)], atol=1e-12)
        p1, p2 = ray.history[1].position, ray.history[2].position
        th_t = np.arcsin(np.sin(th) / n)
        assert abs((p2[0] - p1[0]) - d * np.tan(th_t)) < 1e-12

    # Décalage paraxial de l'image d'un point : delta = d (1 - 1/n)
    z_obj = 0.0
    z_img_par = system.paraxial_image(z_obj)
    assert abs((z_img_par - z_obj) - d * (1 - 1 / n)) < 1e-12
    assert abs(exact_image(system, z_obj) - z_img_par) < 1e-8      # image virtuelle, petits angles


# ========================================================================== #
# Test B — "lentille" à une seule surface sphérique (dioptre)
# ========================================================================== #
def test_B_single_surface_lens():
    n1, n2, R = 1.0, 1.5, 20.0
    dioptre = Lens([R], [], [], n_before=n1, n_after=n2, z_front=0.0)
    system = OpticalSystem([dioptre])
    for s in (100.0, 60.0, 250.0):
        s_formula = n2 / ((n2 - n1) / R - n1 / s)        # n1/s + n2/s' = (n2-n1)/R
        z_mat = system.paraxial_image(-s)
        z_exact = exact_image(system, -s)
        assert abs(z_mat - s_formula) < 1e-9
        assert abs(z_exact - s_formula) / s_formula < 1e-7


# ========================================================================== #
# Test C — lentille épaisse symétrique
# ========================================================================== #
def test_C_symmetric_thick_lens():
    R, d = 50.0, 8.0
    lens = ThickLens(R, -R, d, N_BK7, aperture=30.0, z_front=0.0)
    system = OpticalSystem([lens])
    f = lens.paraxial_formula()
    m = system.paraxial()

    # Formule de lentille épaisse == matrices
    for k in ("EFL", "BFD", "FFD"):
        assert abs(f[k] - m[k]) < 1e-10
    # Forme "lensmaker" explicite, n0 = 1
    n = N_BK7
    inv_f = (n - 1) * (1 / R - 1 / (-R) + (n - 1) * d / (n * R * (-R)))
    assert abs(f["EFL"] - 1 / inv_f) < 1e-10
    # Symétrie : BFD = FFD
    assert abs(f["BFD"] - f["FFD"]) < 1e-12

    # Tracé exact (rayon de hauteur 1e-4) dans les deux sens
    assert abs(exact_back_focus(system) - f["z_back_focus"]) < 1e-6
    assert abs(exact_front_focus(system) - f["z_front_focus"]) < 1e-6


def test_thick_lens_formula_general_cases():
    """Ménisque, plan-convexe, et lentille dans un milieu d'indice n0 != 1."""
    cases = [
        dict(R1=30.0, R2=80.0, thickness=6.0, n_glass=1.7, n_air=1.0),        # ménisque
        dict(R1=40.0, R2=np.inf, thickness=5.0, n_glass=N_BK7, n_air=1.0),    # plan-convexe
        dict(R1=np.inf, R2=-40.0, thickness=5.0, n_glass=N_BK7, n_air=1.0),   # retournée
        dict(R1=60.0, R2=-45.0, thickness=7.0, n_glass=1.8, n_air=1.333),     # dans l'eau
        dict(R1=-40.0, R2=40.0, thickness=3.0, n_glass=N_BK7, n_air=1.0),     # divergente
    ]
    for c in cases:
        lens = ThickLens(**c, aperture=20.0, z_front=5.0)
        system = OpticalSystem([lens])
        f, m = lens.paraxial_formula(), system.paraxial()
        for k in ("EFL", "BFD", "FFD"):
            assert abs(f[k] - m[k]) < 1e-9 * max(1, abs(f[k])), (c, k)
        z_exact = exact_back_focus(system)
        assert abs(z_exact - f["z_back_focus"]) < 1e-5 * max(1, abs(f["EFL"])), c


def test_thin_lens_limit():
    R, n = 50.0, N_BK7
    for d in (1.0, 0.1, 0.01):
        # pas d'ouverture : la vérification d'épaisseur au bord est sans objet ici
        efl = ThickLens(R, -R, d, n).paraxial_formula()["EFL"]
        f_thin = 1 / ((n - 1) * 2 / R)
        assert abs(efl - f_thin) < 0.06 * d * f_thin       # écart d'ordre d


def test_cemented_doublet_three_surfaces():
    """Doublet générique (valeurs arbitraires) : matrices == tracé exact."""
    lens = Lens([50.0, -40.0, -200.0], [6.0, 2.5], [1.65, 1.75], aperture=25.0, z_front=0.0)
    system = OpticalSystem([lens])
    assert [s.n1 for s in lens.surfaces] == [1.0, 1.65, 1.75]
    assert [s.n2 for s in lens.surfaces] == [1.65, 1.75, 1.0]
    assert np.allclose([s.z_vertex for s in lens.surfaces], [0.0, 6.0, 8.5])
    m = system.paraxial()
    assert abs(exact_back_focus(system) - m["z_back_focus"]) < 1e-6
    assert abs(exact_front_focus(system) - m["z_front_focus"]) < 1e-6
    for z_obj in (-300.0, -150.0):
        assert abs(exact_image(system, z_obj) - system.paraxial_image(z_obj)) < 1e-5


def test_edge_thickness_warning():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        ThickLens(20.0, -20.0, 2.0, 1.5, aperture=30.0)       # bord négatif
        assert any("bord" in str(x.message) for x in w)


def test_lens_in_system_with_other_elements():
    sys2 = OpticalSystem()
    sys2.add(ThickLens(50.0, -50.0, 5.0, N_BK7, aperture=20, z_front=0.0))
    sys2.add(ThickLens(80.0, -80.0, 4.0, N_BK7, aperture=20, z_front=30.0))
    assert len(sys2.surfaces) == 4 and len(sys2.elements) == 2
    assert abs(exact_back_focus(sys2) - sys2.paraxial()["z_back_focus"]) < 1e-6


# ========================================================================== #
# Test F — convergence vers l'optique paraxiale quand h, theta -> 0
# ========================================================================== #
def test_F_convergence_to_paraxial_collimated():
    lens = ThickLens(50.0, -50.0, 8.0, N_BK7, aperture=30.0)
    system = OpticalSystem([lens])
    z_par = system.paraxial()["z_back_focus"]
    hs = np.array([8.0, 4.0, 2.0, 1.0, 0.5, 0.25, 0.125, 0.0625])
    err = []
    for h in hs:
        ray = system.trace(Ray([h, -10.0], [0.0, 1.0]))
        err.append(axis_crossing(ray) - z_par)
    err = np.array(err)
    assert np.all(err < 0)                          # LSA négative (lentille convergente simple)
    assert np.all(np.diff(np.abs(err)) < 0)         # décroît quand h diminue
    ratios = err[:-1] / err[1:]
    assert np.all(np.abs(ratios[1:] - 4.0) < 0.1)   # LSA ∝ h² à l'ordre le plus bas
    assert abs(err[-1]) / abs(lens.paraxial_formula()["EFL"]) < 1e-5


def test_F_convergence_point_source_and_focus_analysis():
    lens = ThickLens(50.0, -50.0, 8.0, N_BK7, aperture=30.0, z_front=0.0)
    system = OpticalSystem([lens])
    src = PointSource(0.0, -150.0, theta_max=np.deg2rad(4), n_rays=121)
    rays = system.trace(src.generate_rays())
    fa = focus_analysis(rays, system=system, source=src)
    assert fa.paraxial_source == "analytique"
    # l'extrapolation h -> 0 du tracé exact retrouve le foyer paraxial analytique,
    # de mieux en mieux quand on augmente l'ordre du développement en h^2
    assert abs(fa.z_paraxial_fit - fa.z_paraxial) / fa.z_paraxial < 1e-8
    errs = [abs(focus_analysis(rays, system=system, source=src, fit_order=o).z_paraxial_fit
                - fa.z_paraxial) for o in (2, 3, 4, 5)]
    assert np.all(np.diff(errs) < 0)
    assert fa.lsa < 0
    # z_f est pair en theta et s'éloigne monotonement du foyer paraxial
    pos = fa.theta > 0
    order = np.argsort(fa.theta[pos])
    assert np.all(np.diff(fa.z_f[pos][order]) < 0)


if __name__ == "__main__":
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        fn()
        print(f"OK  {name}")
    print(f"\n{len(tests)} tests réussis.")
