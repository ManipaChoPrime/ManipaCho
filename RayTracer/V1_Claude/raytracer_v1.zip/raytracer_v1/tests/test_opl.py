"""Tests V1 : chemin optique (OPL) et interception sur un plan commun.

Exécution :  python tests/test_opl.py   (ou  pytest tests/)
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from optical_sim import (Lens, ThickLens, OpticalSystem, SphericalSurface, Ray,  # noqa: E402
                         PointSource, CollimatedSource, intercept_at_plane, axis_crossing)


# ========================================================================== #
# Test D — conservation de l'OPL dans des cas triviaux
# ========================================================================== #
def test_D_homogeneous_medium_opl_equals_nL():
    n = 1.33
    ray = Ray([0.0, 0.0], [np.sin(0.3), np.cos(0.3)], n=n)
    ray.propagate_to_z(10.0)
    ray.propagate_to_z(25.0)
    L = 25.0 / np.cos(0.3)
    assert abs(ray.geometric_length - L) < 1e-12
    assert abs(ray.opl() - n * L) < 1e-12


def test_D_index_matched_surfaces_are_invisible():
    """Surfaces séparant deux milieux de même indice : ni déviation, ni changement d'OPL."""
    n = 1.5
    lens = Lens([30.0, -25.0], [6.0], [n], n_before=n, aperture=20.0, z_front=5.0)
    system = OpticalSystem([lens])
    for th in np.deg2rad([0, 5, 15]):
        ray = system.trace(Ray([0.0, 0.0], [np.sin(th), np.cos(th)], n=n), z_final=40.0)
        assert np.allclose(ray.direction, [np.sin(th), np.cos(th)], atol=1e-12)
        assert abs(ray.opl() - n * 40.0 / np.cos(th)) < 1e-10


def test_segment_index_convention():
    """n_segment de chaque segment = indice du milieu où il est parcouru
    = indice de départ de l'événement précédent (et non l'indice après réfraction)."""
    lens = ThickLens(40.0, -40.0, 6.0, 1.7, aperture=20.0, z_front=10.0)
    system = OpticalSystem([lens])
    ray = system.trace(Ray([0.0, 0.0], [np.sin(0.1), np.cos(0.1)]), z_final=60.0)
    h = ray.history
    assert [ev.n_segment for ev in h[1:]] == [1.0, 1.7, 1.0]
    for k in range(1, len(h)):
        assert h[k].n_segment == h[k - 1].n
    # OPL recalculé à la main à partir des positions
    manual = sum(n * np.linalg.norm(b - a) for a, b, n, _ in ray.segments())
    assert abs(manual - ray.opl()) < 1e-12


def test_plate_opl_analytic():
    """Source ponctuelle, lame plane [a, a+d], plan d'observation Z :
    OPL = n0 a/cos(t0) + n d/cos(t1) + n0 (Z - a - d)/cos(t0)."""
    a, d, n, Z = 10.0, 5.0, 1.5, 30.0
    system = OpticalSystem([Lens([np.inf, np.inf], [d], [n], aperture=100, z_front=a)])
    src = PointSource(0, 0, theta_max=np.deg2rad(40), n_rays=21)
    data = system.intercept_at_plane(system.trace(src.generate_rays()), Z)
    t0 = data.theta_initial
    t1 = np.arcsin(np.sin(t0) / n)
    expected = a / np.cos(t0) + n * d / np.cos(t1) + (Z - a - d) / np.cos(t0)
    assert np.allclose(data.opl, expected, atol=1e-11)
    assert np.allclose(data.theta, t0, atol=1e-12)          # theta_final = theta initial


def test_collimated_through_plate_keeps_plane_wave():
    """Onde plane normale à travers une lame : OPL identique pour toutes les hauteurs."""
    system = OpticalSystem([Lens([np.inf, np.inf], [4.0], [1.6], aperture=50, z_front=0.0)])
    src = CollimatedSource(z=-5.0, half_width=10.0, n_rays=11)
    data = system.intercept_at_plane(system.trace_bundle(src), 20.0)
    assert np.ptp(data.opl) < 1e-12
    assert abs(data.opl[0] - (5.0 + 1.6 * 4.0 + 16.0)) < 1e-12


# ========================================================================== #
# Test E — système homogène : OPL = n x longueur géométrique pour chaque rayon
# ========================================================================== #
def test_E_two_rays_homogeneous_system():
    n = 1.4
    system = OpticalSystem([SphericalSurface(10.0, 30.0, n, n),
                            SphericalSurface(20.0, -30.0, n, n)])
    r1 = system.trace(Ray([0.0, 0.0], [np.sin(0.05), np.cos(0.05)], n=n))
    r2 = system.trace(Ray([0.0, 0.0], [np.sin(0.25), np.cos(0.25)], n=n))
    data = intercept_at_plane([r1, r2], 50.0)
    for k, ray in enumerate([r1, r2]):
        assert abs(ray.opl() - n * ray.geometric_length) < 1e-12
        dist = np.hypot(data.x[k], 50.0)                     # source -> point du plan
        assert abs(data.opl[k] - n * dist) < 1e-10
    assert data.opl[1] > data.opl[0]


# ========================================================================== #
# Cas exact non paraxial : points aplanétiques d'une sphère
# ========================================================================== #
def test_aplanatic_points_exact_stigmatism_and_opl():
    """Sphère de rayon r, verre n à l'intérieur, air dehors. Un point objet à
    r/n du centre a une image virtuelle EXACTE (tous angles) à n r du centre,
    du même côté. Vérifie le tracé exact et l'OPL :
        OPL(objet -> surface) - n_air |P - image| = constante  (= 0 ici)."""
    n, r = 1.5, 10.0
    surf = SphericalSurface(0.0, -r, n, 1.0)             # centre en z = -10, verre côté -z
    zc = surf.center[1]
    z_obj, z_img = zc - r / n, zc - n * r
    system = OpticalSystem([surf])
    src = PointSource(0.0, z_obj, theta_max=np.deg2rad(45), n_rays=61, n=n)
    rays = system.trace(src.generate_rays())
    assert all(r.status == "alive" for r in rays)
    consts = []
    for ray in rays:
        if abs(ray.direction[0]) < 1e-12:
            continue
        assert abs(axis_crossing(ray) - z_img) < 1e-9          # stigmatisme exact
        P = ray.position
        consts.append(ray.opl() - 1.0 * np.hypot(P[0], P[1] - z_img))
    assert np.ptp(consts) < 1e-10
    assert abs(consts[0] - (n * (0 - z_obj) - (0 - z_img))) < 1e-10


# ========================================================================== #
# Interception sur un plan : champs et cas virtuels
# ========================================================================== #
def test_intercept_fields_and_virtual():
    lens = ThickLens(50.0, -50.0, 6.0, 1.5, aperture=30.0, z_front=0.0)
    system = OpticalSystem([lens])
    src = CollimatedSource(z=-10.0, half_width=8.0, n_rays=9)
    rays = system.trace_bundle(src, z_final=100.0)
    # plan avant la dernière surface -> virtuel
    assert len(system.intercept_at_plane(rays, -20.0)) == 0
    data = system.intercept_at_plane(rays, -20.0, allow_virtual=True)
    assert len(data) == 9 and np.all(data.virtual)
    # plan réel, même s'il est AVANT z_final : le résultat ne dépend pas de z_final
    d60 = system.intercept_at_plane(rays, 60.0)
    rays2 = system.trace_bundle(src)                      # sans z_final
    d60b = system.intercept_at_plane(rays2, 60.0)
    assert np.allclose(d60.x, d60b.x) and np.allclose(d60.opl, d60b.opl)
    assert not np.any(d60.virtual)
    # plan au-delà de z_final : OPL = OPL(rayon jusqu'à z_final) + distance restante
    data = system.intercept_at_plane(rays, 120.0)
    assert np.allclose(data.z, 120.0)
    assert np.allclose(data.x_pupil, src.heights(), atol=1e-12)  # collimaté : pupille = hauteur
    for k, i in enumerate(data.ray_index):
        assert data.rays[k] is rays[i]
        assert np.isclose(data.theta[k], rays[i].theta)
        assert np.isclose(data.opl[k], rays[i].opl() + (120.0 - 100.0) / rays[i].direction[1])


if __name__ == "__main__":
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        fn()
        print(f"OK  {name}")
    print(f"\n{len(tests)} tests réussis.")
