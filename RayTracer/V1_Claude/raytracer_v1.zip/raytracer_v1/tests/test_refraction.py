"""Tests de la loi de Snell vectorielle (optical_sim.refraction.refract).

Exécution :  python tests/test_refraction.py   (ou  pytest tests/  si pytest est installé)
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from optical_sim import refract  # noqa: E402

TOL = 1e-12
N_PLANE = np.array([0.0, -1.0])   # normale d'une interface z = cste (orientée vers -z)


def direction(theta):
    """Direction faisant l'angle theta avec +z (positif vers +x)."""
    return np.array([np.sin(theta), np.cos(theta)])


def angle_to_axis(d):
    """Angle (signé) d'une direction avec l'axe z, ramené dans [-pi/2, pi/2]."""
    return np.arctan(d[0] / d[1])


# --- Test 1 : incidence normale ------------------------------------------- #
def test_normal_incidence_no_deviation():
    for n1, n2 in [(1.0, 1.5), (1.5, 1.0), (1.0, 3.5)]:
        res = refract([0.0, 1.0], N_PLANE, n1, n2)
        assert res.transmitted
        assert np.allclose(res.direction, [0.0, 1.0], atol=TOL)


# --- Test 2 : loi de Snell n1 sin(t1) = n2 sin(t2) ------------------------- #
def test_snell_law_air_to_glass():
    n1, n2 = 1.0, 1.5
    for th1 in np.deg2rad(np.linspace(-89, 89, 179)):
        res = refract(direction(th1), N_PLANE, n1, n2)
        assert res.transmitted
        th2 = angle_to_axis(res.direction)
        assert abs(n1 * np.sin(th1) - n2 * np.sin(th2)) < 1e-12
        assert np.sign(th2) == np.sign(th1) or th1 == 0        # même côté de la normale
        assert abs(th2) <= abs(th1) + TOL                      # se rapproche de la normale
        assert abs(np.linalg.norm(res.direction) - 1) < TOL    # reste unitaire
        assert res.direction[1] > 0                            # continue vers +z


def test_snell_law_glass_to_air_below_critical():
    n1, n2 = 1.5, 1.0
    theta_c = np.arcsin(n2 / n1)
    for th1 in np.linspace(-0.999 * theta_c, 0.999 * theta_c, 101):
        res = refract(direction(th1), N_PLANE, n1, n2)
        assert res.transmitted
        th2 = angle_to_axis(res.direction)
        assert abs(n1 * np.sin(th1) - n2 * np.sin(th2)) < 1e-12
        assert abs(th2) >= abs(th1) - TOL                      # s'écarte de la normale


# --- Test 3 : réflexion totale interne ------------------------------------ #
def test_total_internal_reflection():
    n1, n2 = 1.5, 1.0
    theta_c = np.arcsin(n2 / n1)                               # ~41.81°
    for th1 in np.linspace(1.001 * theta_c, np.deg2rad(89.9), 50):
        for s in (+1, -1):
            res = refract(direction(s * th1), N_PLANE, n1, n2)
            assert not res.transmitted
            assert res.direction is None


def test_critical_angle_boundary():
    n1, n2 = 1.5, 1.0
    theta_c = np.arcsin(n2 / n1)
    assert refract(direction(theta_c * (1 - 1e-9)), N_PLANE, n1, n2).transmitted
    assert not refract(direction(theta_c * (1 + 1e-9)), N_PLANE, n1, n2).transmitted


# --- Orientation de la normale et sens de propagation --------------------- #
def test_result_independent_of_normal_orientation():
    d = direction(np.deg2rad(30))
    a = refract(d, N_PLANE, 1.0, 1.5)
    b = refract(d, -N_PLANE, 1.0, 1.5)
    assert np.allclose(a.direction, b.direction, atol=TOL)


def test_backward_propagation_is_mirror_of_forward():
    """Un rayon allant vers -z doit être le symétrique (z -> -z) du cas vers +z."""
    th = np.deg2rad(25)
    fwd = refract(direction(th), N_PLANE, 1.0, 1.5).direction
    bwd = refract([np.sin(th), -np.cos(th)], N_PLANE, 1.0, 1.5).direction
    assert np.allclose(bwd, [fwd[0], -fwd[1]], atol=TOL)


def test_reversibility():
    """Principe de retour inverse : renverser le rayon réfracté redonne l'incident."""
    d = direction(np.deg2rad(35))
    t = refract(d, N_PLANE, 1.0, 1.5).direction
    back = refract(-t, N_PLANE, 1.5, 1.0).direction
    assert np.allclose(back, -d, atol=1e-12)


def test_same_index_no_deviation():
    d = direction(np.deg2rad(50))
    assert np.allclose(refract(d, [0.3, -0.9], 1.33, 1.33).direction, d, atol=TOL)


def test_tilted_interface():
    """Interface inclinée de 20° : Snell vérifié avec les angles mesurés à la normale."""
    alpha = np.deg2rad(20)
    N = np.array([np.sin(alpha), -np.cos(alpha)])
    d = direction(np.deg2rad(5))
    n1, n2 = 1.0, 1.7
    res = refract(d, N, n1, n2)
    cross2d = lambda a, b: a[0] * b[1] - a[1] * b[0]   # |a x b| = sin(angle) pour a, b unitaires
    sin_i = abs(cross2d(N, d))
    sin_t = abs(cross2d(N, res.direction))
    assert abs(n1 * sin_i - n2 * sin_t) < 1e-12
    assert np.isclose(np.sqrt(1 - sin_i**2), res.cos_incidence)


if __name__ == "__main__":
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        fn()
        print(f"OK  {name}")
    print(f"\n{len(tests)} tests réussis.")
