"""Tests géométriques (intersection, normale) et tests du tracé complet.

Exécution :  python tests/test_intersection.py   (ou  pytest tests/)
"""

import os
import sys
import warnings

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from optical_sim import SphericalSurface, OpticalSystem, Ray, PointSource  # noqa: E402
from optical_sim.ray import MISSED, TIR, ALIVE  # noqa: E402

TOL = 1e-10


# ========================================================================== #
# Géométrie de la surface
# ========================================================================== #
def test_center_and_sign_convention():
    assert np.allclose(SphericalSurface(10, +5, 1, 1.5).center, [0, 15])
    assert np.allclose(SphericalSurface(10, -5, 1, 1.5).center, [0, 5])


def test_sag_is_on_sphere_and_vertex():
    for R in (+7.0, -7.0):
        s = SphericalSurface(3.0, R, 1, 1.5)
        xs = np.linspace(-6.9, 6.9, 51)
        zs = s.sag(xs)
        assert np.isclose(s.sag(0.0), 3.0)
        for x, z in zip(xs, zs):
            assert abs(s.implicit((x, z))) < 1e-9


def test_normal_points_toward_n1_side():
    for R in (+5.0, -5.0):
        s = SphericalSurface(0.0, R, 1, 1.5)
        assert np.allclose(s.normal((0.0, 0.0)), [0, -1])
        x = 3.0
        N = s.normal((x, float(s.sag(x))))
        assert N[1] < 0                       # composante z vers -z (côté n1)
        assert np.isclose(np.linalg.norm(N), 1)


# ========================================================================== #
# Test 5 : intersection rayon / sphère, cas analytiques
# ========================================================================== #
def test_on_axis_ray_hits_vertex():
    for R in (+20.0, -20.0, np.inf):
        s = SphericalSurface(50.0, R, 1, 1.5)
        t = s.intersect([0.0, 0.0], [0.0, 1.0])
        assert abs(t - 50.0) < TOL


def test_parallel_off_axis_ray_hits_at_sag():
    """Rayon // axe à la hauteur h : z_hit = z_v + R - sign(R) sqrt(R^2 - h^2)."""
    z0, z_v, h = -10.0, 5.0, 3.0
    for R in (+8.0, -8.0):
        s = SphericalSurface(z_v, R, 1, 1.5)
        t = s.intersect([h, z0], [0.0, 1.0])
        z_expected = z_v + R - np.sign(R) * np.sqrt(R**2 - h**2)
        assert abs((z0 + t) - z_expected) < TOL


def test_ray_from_center_of_curvature():
    """Depuis le centre C, toute direction atteint la sphère à t = |R|."""
    R = 12.0
    s = SphericalSurface(0.0, -R, 1, 1.5)            # centre en z = -12, calotte en z ~ 0
    C = s.center
    for th in np.deg2rad(np.linspace(-60, 60, 13)):
        d = np.array([np.sin(th), np.cos(th)])
        t = s.intersect(C, d)
        assert abs(t - R) < TOL
        P = C + t * d
        assert np.allclose(np.abs(np.dot(s.normal(P), d)), 1.0)   # normale // rayon


def test_miss_and_behind_cases():
    s = SphericalSurface(0.0, 5.0, 1, 1.5)
    assert s.intersect([6.0, -10.0], [0.0, 1.0]) is None     # passe à côté (h > |R|)
    assert s.intersect([0.0, 10.0], [0.0, 1.0]) is None      # surface derrière le rayon
    p = SphericalSurface(0.0, np.inf, 1, 1.5)
    assert p.intersect([0.0, -1.0], [1.0, 0.0]) is None      # parallèle au plan
    assert p.intersect([0.0, 1.0], [0.0, 1.0]) is None       # plan derrière


def test_far_side_of_circle_is_rejected():
    """Rayon parti de l'intérieur du cercle, vers +z, en s'éloignant du sommet :
    la seule racine positive est sur la face arrière -> pas d'intersection."""
    s = SphericalSurface(0.0, 5.0, 1, 1.5)                   # cercle entre z = 0 et z = 10
    assert s.intersect([0.0, 2.0], [0.0, 1.0]) is None


def test_aperture_blocks_ray():
    s = SphericalSurface(0.0, 20.0, 1, 1.5, semi_aperture=2.0)
    assert s.intersect([1.0, -5.0], [0.0, 1.0]) is not None
    assert s.intersect([3.0, -5.0], [0.0, 1.0]) is None


def test_backward_ray_intersection():
    s = SphericalSurface(0.0, 10.0, 1, 1.5)
    t = s.intersect([2.0, 5.0], [0.0, -1.0])                 # vient de +z vers -z
    assert abs((5.0 - t) - (10 - np.sqrt(100 - 4))) < TOL


# ========================================================================== #
# Test 4 : surface plane, tracé complet
# ========================================================================== #
def test_plane_interface_snell():
    n1, n2 = 1.0, 1.5
    system = OpticalSystem([SphericalSurface(10.0, np.inf, n1, n2)])
    src = PointSource(0, 0, theta_max=np.deg2rad(60), n_rays=41, n=n1)
    for ray in system.trace_all(src.generate_rays()):
        assert ray.status == ALIVE and ray.n == n2
        d0 = ray.history[0].direction
        d1 = ray.direction
        hit = ray.history[1].position
        assert abs(hit[1] - 10.0) < TOL
        assert abs(hit[0] - 10.0 * d0[0] / d0[1]) < TOL      # x = z tan(theta)
        assert abs(n1 * d0[0] - n2 * d1[0]) < 1e-12          # n sin(theta) conservé
        assert abs(ray.geometric_length - 10.0 / d0[1]) < TOL


def test_plane_interface_tir_in_system():
    n1, n2 = 1.5, 1.0
    theta_c = np.arcsin(n2 / n1)
    system = OpticalSystem([SphericalSurface(5.0, np.inf, n1, n2)])
    src = PointSource(0, 0, theta_max=np.deg2rad(70), n_rays=141, n=n1)
    for ray in system.trace_all(src.generate_rays(), z_final=20):
        th = abs(np.arcsin(ray.history[0].direction[0]))
        if th > theta_c:
            assert ray.status == TIR and abs(ray.z - 5.0) < TOL
        else:
            assert ray.status == ALIVE and abs(ray.z - 20.0) < TOL


# ========================================================================== #
# Surface sphérique, tracé complet
# ========================================================================== #
def test_source_at_center_of_curvature_undeviated():
    """Source au centre de courbure : incidence normale partout -> aucune déviation."""
    system = OpticalSystem([SphericalSurface(0.0, -10.0, 1.0, 1.5)])
    src = PointSource(0, -10.0, theta_max=np.deg2rad(50), n_rays=21)
    for ray in system.trace_all(src.generate_rays()):
        assert ray.status == ALIVE
        assert np.allclose(ray.direction, ray.history[0].direction, atol=1e-12)


def test_paraxial_limit_matches_dioptre_formula():
    """Petits angles : le tracé exact doit retrouver la relation de conjugaison
    du dioptre sphérique  n1/s + n2/s' = (n2 - n1)/R  (s, s' > 0 réels).
    Source à s = 100 avant le sommet, R = 20, n 1 -> 1.5  =>  s' = 100."""
    n1, n2, R, s = 1.0, 1.5, 20.0, 100.0
    s_img = n2 / ((n2 - n1) / R - n1 / s)
    system = OpticalSystem([SphericalSurface(0.0, R, n1, n2)])
    ray = system.trace(Ray([0.0, -s], [np.sin(1e-5), np.cos(1e-5)], n=n1))
    x, z = ray.position
    dx, dz = ray.direction
    z_cross = z - x * dz / dx                                # croisement avec l'axe
    assert abs(z_cross - s_img) / s_img < 1e-6


def test_spherical_aberration_sign():
    """Dioptre convexe : les rayons marginaux croisent l'axe AVANT le foyer
    paraxial (aberration sphérique longitudinale négative)."""
    system = OpticalSystem([SphericalSurface(0.0, 20.0, 1.0, 1.5)])
    crossings = []
    for th in np.deg2rad([0.01, 2, 4, 6]):
        ray = system.trace(Ray([0.0, -100.0], [np.sin(th), np.cos(th)]))
        x, z = ray.position
        dx, dz = ray.direction
        crossings.append(z - x * dz / dx)
    assert np.all(np.diff(crossings) < 0)


def test_backward_trace_uses_n2_to_n1():
    """Rayon venant de +z (milieu n2) : il doit ressortir dans n1."""
    surf = SphericalSurface(0.0, np.inf, 1.0, 1.5)
    system = OpticalSystem([surf])
    th = np.deg2rad(20)
    ray = system.trace(Ray([0.0, 10.0], [np.sin(th), -np.cos(th)], n=1.5))
    assert ray.n == 1.0
    assert abs(1.5 * np.sin(th) - 1.0 * ray.direction[0]) < 1e-12


def test_index_mismatch_warns():
    system = OpticalSystem([SphericalSurface(5.0, np.inf, 1.0, 1.5)])
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        system.trace(Ray([0, 0], [0, 1], n=1.33))
        assert len(w) == 1


def test_missed_ray_stops():
    system = OpticalSystem([SphericalSurface(5.0, 20.0, 1.0, 1.5, semi_aperture=1.0)])
    ray = system.trace(Ray([0, 0], [np.sin(0.5), np.cos(0.5)]), z_final=30)
    assert ray.status == MISSED and len(ray.history) == 1


if __name__ == "__main__":
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        fn()
        print(f"OK  {name}")
    print(f"\n{len(tests)} tests réussis.")
