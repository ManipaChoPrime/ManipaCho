"""Cas réel : doublet achromatique Thorlabs AC254-060-B.

Ce script ne contient AUCUNE logique spécifique : il instancie la classe
générique `Lens` avec les données constructeur. Les classes du package ne
connaissent pas cette lentille.

>>> REMPLIR LE BLOC `DATA` CI-DESSOUS avec les valeurs de la fiche constructeur
    et les indices des deux verres À LA LONGUEUR D'ONDE ÉTUDIÉE. <<<

Convention d'orientation : la lumière arrive par la surface 1 (R1), comme
dans la fiche Thorlabs (c'est l'orientation recommandée pour un faisceau
collimaté arrivant sur la face la plus convexe). Rayons : convention
"centre de courbure" (R > 0 : centre vers +z), qui est aussi celle des
fiches Thorlabs/Zemax. Unités : mm.

La focale nominale du constructeur est donnée à SA longueur d'onde de
référence. À une autre longueur d'onde, la focale calculée avec les bons
indices peut différer légèrement : la comparaison (test G) se fait avec une
tolérance à choisir en conséquence.

Exécution :  python examples/ac254_060_b.py
"""

import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from optical_sim import (Lens, OpticalSystem, PointSource, CollimatedSource,  # noqa: E402
                         focus_analysis)

# ============================================================================
# DONNÉES CONSTRUCTEUR — À REMPLIR
# ============================================================================
DATA = dict(
    # Géométrie (mm). Lumière entrant par R1.
    R1=None,                # rayon de la surface 1
    R2=None,                # rayon de la surface 2 (interface collée)
    R3=None,                # rayon de la surface 3
    tc1=None,               # épaisseur au centre du 1er verre
    tc2=None,               # épaisseur au centre du 2e verre
    diameter=25.4,          # Ø1" (AC254 = Ø25.4 mm)
    clear_aperture=None,    # diamètre utile ; None -> diamètre total

    # Verres et indices à la longueur d'onde étudiée
    glass1="",              # nom du 1er verre (information seulement)
    glass2="",              # nom du 2e verre
    wavelength_nm=None,     # longueur d'onde à laquelle les indices sont donnés
    n1=None,                # indice du verre 1 à wavelength_nm
    n2=None,                # indice du verre 2 à wavelength_nm

    # Spécifications constructeur (pour le test G)
    efl_nominal=60.0,       # focale effective nominale (référence "-060")
    bfl_nominal=None,       # distance frontale arrière nominale (fiche), mm
    spec_wavelength_nm=None,  # longueur d'onde de référence de la fiche
    efl_rel_tolerance=0.01,   # tolérance relative sur l'EFL (à adapter si λ ≠ λ_fiche)
    bfl_abs_tolerance=0.5,    # tolérance absolue sur la BFL, mm
)

REQUIRED = ("R1", "R2", "R3", "tc1", "tc2", "n1", "n2", "wavelength_nm")


def missing_fields(data=DATA) -> list:
    return [k for k in REQUIRED if data.get(k) is None]


def build_ac254_060_b(data=DATA, z_front: float = 0.0) -> Lens:
    """Instancie le doublet à partir de `data` (classe générique Lens)."""
    miss = missing_fields(data)
    if miss:
        raise ValueError("Données AC254-060-B incomplètes, champs manquants : " + ", ".join(miss))
    aperture = data["clear_aperture"] or data["diameter"]
    return Lens(radii=[data["R1"], data["R2"], data["R3"]],
                thicknesses=[data["tc1"], data["tc2"]],
                n_glasses=[data["n1"], data["n2"]],
                n_before=1.0, aperture=aperture, z_front=z_front,
                name="AC254-060-B")


def main():
    miss = missing_fields()
    if miss:
        print("Données manquantes dans DATA :", ", ".join(miss))
        print("Remplis le bloc DATA en tête de ce fichier avec la fiche constructeur "
              "et les indices à ta longueur d'onde, puis relance.")
        return

    import matplotlib.pyplot as plt
    from optical_sim import plot_rays, plot_focus, plot_opl

    ac254_060_b = build_ac254_060_b()
    system = OpticalSystem()
    system.add(ac254_060_b)

    par = system.paraxial()
    lam = DATA["wavelength_nm"]
    print(f"AC254-060-B à λ = {lam} nm  (n1 = {DATA['n1']}, n2 = {DATA['n2']})")
    print(f"  EFL paraxiale = {par['EFL']:.4f} mm   (nominale {DATA['efl_nominal']} mm)")
    print(f"  BFD paraxiale = {par['BFD']:.4f} mm   (nominale {DATA['bfl_nominal']} mm)")
    print("  épaisseurs au bord :", [f"{t:.3f}" for t in ac254_060_b.edge_thicknesses()])

    fig = plt.figure(figsize=(14, 10))
    gs = fig.add_gridspec(3, 3, height_ratios=[1.1, 1.1, 1])
    ca = DATA["clear_aperture"] or DATA["diameter"]

    # Faisceau collimaté (conjugaison infinie, celle des specs constructeur)
    src_c = CollimatedSource(z=-10.0, half_width=0.45 * ca, n_rays=41)
    rays_c = system.trace_bundle(src_c, z_final=par["z_back_focus"] + 10)
    fa_c = focus_analysis(rays_c, system=system, source=src_c)
    print("\n[collimaté, Ø = %.1f mm]\n" % (0.9 * ca) + fa_c.summary())
    plot_rays(rays_c, system, ax=fig.add_subplot(gs[0, :]),
              title=f"AC254-060-B, collimaté Ø{0.9 * ca:.1f} mm, λ = {lam} nm : LSA = {fa_c.lsa:.4f} mm")
    plot_focus(fa_c, ax=fig.add_subplot(gs[2, 0]), versus="x_pupil", title="Collimaté : z_f(x_pupil)")
    data_c = system.intercept_at_plane(rays_c, fa_c.z_paraxial)
    plot_opl(data_c, ax=fig.add_subplot(gs[2, 2]), versus="x_pupil", wavelength=lam * 1e-6,
             title="Collimaté : OPL au plan focal paraxial [λ]")

    # Source ponctuelle à distance finie (au-delà de la focale -> image réelle)
    src_p = PointSource(x=0.0, z=-150.0, theta_max=np.deg2rad(4), n_rays=81)
    rays_p = system.trace(src_p.generate_rays())
    fa_p = focus_analysis(rays_p, system=system, source=src_p)
    for r in rays_p:
        if r.alive:
            r.propagate_to_z(fa_p.z_paraxial + 15)
    print("\n[source ponctuelle z = -150 mm]\n" + fa_p.summary())
    plot_rays(rays_p, system, ax=fig.add_subplot(gs[1, :]), source=src_p, equal_aspect=False,
              legend_loc="lower left", title="Source ponctuelle en z = −150 mm (échelles différentes)")
    plot_focus(fa_p, ax=fig.add_subplot(gs[2, 1]), versus="theta", title="Source ponctuelle : z_f(θ)")

    plt.tight_layout()
    out = os.path.join(HERE, "ac254_060_b.png")
    plt.savefig(out, dpi=120)
    print(f"\nFigure sauvegardée : {out}")
    plt.show()


if __name__ == "__main__":
    main()
