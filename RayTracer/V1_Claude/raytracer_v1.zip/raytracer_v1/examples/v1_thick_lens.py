"""Exemple V1 : lentille épaisse biconvexe générique.

Montre les trois sorties de la V1 :
  1. trajectoires exactes,
  2. z_f(theta) et z_f(x_pupil) : aberration sphérique longitudinale,
  3. OPL(x) sur un plan commun (le plan focal paraxial).

Unités : mm. Indice d'exemple n = 1.5168 (≈ N-BK7 à 587.6 nm).
Exécution :  python examples/v1_thick_lens.py
"""

import os
import sys

import numpy as np
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from optical_sim import (ThickLens, OpticalSystem, PointSource, CollimatedSource,  # noqa: E402
                         focus_analysis, plot_rays, plot_focus, plot_opl)

lens = ThickLens(R1=50.0, R2=-50.0, thickness=8.0, n_glass=1.5168, aperture=30.0,
                 z_front=0.0, name="biconvexe")
system = OpticalSystem()
system.add(lens)

par = lens.paraxial_formula()
print(f"EFL = {par['EFL']:.4f}  BFD = {par['BFD']:.4f}  foyer image z = {par['z_back_focus']:.4f}")
print("Épaisseurs au bord :", [f"{t:.3f}" for t in lens.edge_thicknesses()])

fig = plt.figure(figsize=(14, 11))
gs = fig.add_gridspec(3, 3, height_ratios=[1.1, 1.1, 1])

# ----------------------------------------------------------------------------
# A. Faisceau collimaté (objet à l'infini) -> foyer image
# ----------------------------------------------------------------------------
src_c = CollimatedSource(z=-15.0, half_width=13.0, n_rays=27)
z_par = par["z_back_focus"]
rays_c = system.trace_bundle(src_c, z_final=z_par + 8)
fa_c = focus_analysis(rays_c, system=system, source=src_c)
print("\n[collimaté]\n" + fa_c.summary())

plot_rays(rays_c, system, ax=fig.add_subplot(gs[0, :]),
          title=f"Faisceau collimaté, Ø26 mm : LSA = {fa_c.lsa:.3f} mm")
plot_focus(fa_c, ax=fig.add_subplot(gs[2, 0]), versus="x_pupil",
           title="Collimaté : z_f(x_pupil)")

data_c = system.intercept_at_plane(rays_c, z_par)
plot_opl(data_c, ax=fig.add_subplot(gs[2, 2]), versus="x_pupil",
         title=f"Collimaté : OPL au plan focal paraxial\n(z = {z_par:.2f}), en fonction de x_pupil")

# ----------------------------------------------------------------------------
# B. Source ponctuelle à distance finie
# ----------------------------------------------------------------------------
src_p = PointSource(x=0.0, z=-150.0, theta_max=np.deg2rad(5), n_rays=41)
rays_p = system.trace(src_p.generate_rays())
fa_p = focus_analysis(rays_p, system=system, source=src_p)
z_img = fa_p.z_paraxial
for r in rays_p:                                   # prolongement pour l'affichage
    if r.alive:
        r.propagate_to_z(z_img + 15)
print("\n[source ponctuelle z = -150]\n" + fa_p.summary())
plot_rays(rays_p, system, ax=fig.add_subplot(gs[1, :]), source=src_p, equal_aspect=False,
          legend_loc="lower left", title=f"Source ponctuelle en z = −150 : LSA = {fa_p.lsa:.3f} mm "
                                         "(échelles x et z différentes)")
plot_focus(fa_p, ax=fig.add_subplot(gs[2, 1]), versus="theta",
           title="Source ponctuelle : z_f(θ)")

plt.tight_layout()
out = os.path.join(HERE, "v1_thick_lens.png")
plt.savefig(out, dpi=120)
print(f"\nFigure sauvegardée : {out}")
plt.show()
