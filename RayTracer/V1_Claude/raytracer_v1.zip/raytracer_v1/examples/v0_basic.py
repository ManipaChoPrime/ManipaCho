"""Exemples V0 : interface plane air->verre, réflexion totale, dioptre sphérique.

Exécution depuis n'importe où :  python examples/v0_basic.py
Les figures sont aussi sauvegardées en PNG à côté de ce script.
"""

import os
import sys

import numpy as np
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from optical_sim import PointSource, SphericalSurface, OpticalSystem, plot_system  # noqa: E402

fig, axes = plt.subplots(3, 1, figsize=(10, 14))

# --------------------------------------------------------------------------- #
# 1. Interface plane air -> verre
# --------------------------------------------------------------------------- #
source = PointSource(x=0, z=0, theta_max=np.deg2rad(40), n_rays=21, n=1.0)
system = OpticalSystem([SphericalSurface(z_vertex=10, R=np.inf, n1=1.0, n2=1.5, name="air | verre")])
rays = system.trace_all(source.generate_rays(), z_final=25)
plot_system(system, rays, ax=axes[0], source=source, plane_half_height=16,
            title="1. Interface plane air → verre (n = 1 → 1.5) : les rayons se rapprochent de la normale")

# --------------------------------------------------------------------------- #
# 2. Interface plane verre -> air : réflexion totale interne
# --------------------------------------------------------------------------- #
source2 = PointSource(x=0, z=0, theta_max=np.deg2rad(60), n_rays=31, n=1.5)
system2 = OpticalSystem([SphericalSurface(z_vertex=8, R=np.inf, n1=1.5, n2=1.0, name="verre | air")])
rays2 = system2.trace_all(source2.generate_rays(), z_final=14)
n_tir = sum(r.status == "tir" for r in rays2)
plot_system(system2, rays2, ax=axes[1], source=source2, x_lim=(-18, 18), z_lim=(-1, 14),
            plane_half_height=17,
            title=f"2. Verre → air : angle critique {np.degrees(np.arcsin(1/1.5)):.1f}°, "
                  f"{n_tir} rayons en réflexion totale (×)")

# --------------------------------------------------------------------------- #
# 3. Dioptre sphérique convexe air -> verre
# --------------------------------------------------------------------------- #
n1, n2, R, s = 1.0, 1.5, 10.0, 50.0
source3 = PointSource(x=0, z=0, theta_max=np.deg2rad(9), n_rays=41, n=n1)
system3 = OpticalSystem([SphericalSurface(z_vertex=s, R=R, n1=n1, n2=n2, semi_aperture=9.5)])
rays3 = system3.trace_all(source3.generate_rays(), z_final=115)
ax = plot_system(system3, rays3, ax=axes[2], source=source3,
                 title="3. Dioptre sphérique R = +10, n = 1 → 1.5 : aberration sphérique visible")

# Image paraxiale attendue : n1/s + n2/s' = (n2 - n1)/R
s_img = n2 / ((n2 - n1) / R - n1 / s)
ax.plot(s + s_img, 0, "*", color="green", ms=12, mec="k", zorder=6)
ax.annotate(f"image paraxiale\nz = {s + s_img:.0f}", (s + s_img, 0),
            textcoords="offset points", xytext=(5, -28), fontsize=8, color="green")

plt.tight_layout()
out = os.path.join(HERE, "v0_basic.png")
plt.savefig(out, dpi=130)
print(f"Figure sauvegardée : {out}")
plt.show()
