"""Surface sphérique (ou plane) réfractante.

GÉOMÉTRIE ET CONVENTION DE SIGNE
--------------------------------
Sommet V = (0, z_vertex), rayon de courbure R (signé) :
    centre de courbure  C = (0, z_vertex + R)
    rayon géométrique   |R|
    R > 0 : centre vers +z   ;   R < 0 : centre vers -z   ;   R = inf : plan.

Équation de la surface (cercle complet) :  x^2 + (z - z_c)^2 = R^2.
La partie physique est la calotte contenant le sommet, décrite par la
flèche (sag) :
    z(x) = z_vertex + R (1 - sqrt(1 - x^2 / R^2))
(valable pour les deux signes de R ; z(0) = z_vertex). Cette forme est
équivalente à  z = z_vertex + x^2 / (R (1 + sqrt(1 - x^2/R^2))), plus
stable numériquement quand R est grand.

Ouverture : demi-diamètre `semi_aperture` (|x| <= semi_aperture). Par
défaut |R| pour une sphère (calotte hémisphérique maximale) et +inf pour
un plan. Un rayon qui frappe hors ouverture est considéré comme bloqué.

NORMALE GÉOMÉTRIQUE
-------------------
On utilise  N_geo(P) = (P - C) / R  (division par R SIGNÉ).
Au sommet, P - C = (0, -R), donc N_geo = (0, -1) quel que soit le signe
de R. Sur toute la calotte, N_geo pointe vers le milieu n1 (côté -z) :
  - R > 0 : (P-C)/R pointe hors de la sphère, du côté du sommet (-z) ;
  - R < 0 : (P-C)/R = (C-P)/|R| pointe vers le centre, situé côté -z.
Pour un plan, N_geo = (0, -1).
Conséquence : un rayon vient du milieu n1 si  d . N_geo < 0, du milieu
n2 sinon. C'est ce critère (et non le signe de dz) qui détermine
l'indice d'entrée et l'indice de sortie.
"""

from __future__ import annotations

from typing import Optional

import numpy as np

from .refraction import refract, RefractionResult

# Tolérance pour ignorer l'intersection "au point de départ" (évite qu'un
# rayon qui vient de traverser une surface la retrouve à t = 0).
T_EPS = 1e-9


class SphericalSurface:
    def __init__(self, z_vertex: float, R: float, n1: float, n2: float,
                 semi_aperture: Optional[float] = None, name: str = ""):
        if R == 0:
            raise ValueError("R = 0 n'a pas de sens ; utiliser R = np.inf pour un plan.")
        self.z_vertex = float(z_vertex)
        self.R = float(R)
        self.n1 = float(n1)   # milieu côté -z
        self.n2 = float(n2)   # milieu côté +z
        if semi_aperture is None:
            semi_aperture = np.inf if self.is_plane else abs(self.R)
        if not self.is_plane and semi_aperture > abs(self.R):
            raise ValueError("L'ouverture ne peut pas dépasser |R| pour une calotte sphérique.")
        self.semi_aperture = float(semi_aperture)
        self.name = name

    # ------------------------------------------------------------------ #
    # Géométrie
    # ------------------------------------------------------------------ #
    @property
    def is_plane(self) -> bool:
        return np.isinf(self.R)

    @property
    def center(self) -> np.ndarray:
        """Centre de courbure (x, z) = (0, z_vertex + R). Non défini pour un plan."""
        if self.is_plane:
            raise ValueError("Une surface plane n'a pas de centre de courbure.")
        return np.array([0.0, self.z_vertex + self.R])

    def sag(self, x) -> np.ndarray:
        """z(x) de la calotte (forme numériquement stable)."""
        x = np.asarray(x, dtype=float)
        if self.is_plane:
            return np.full_like(x, self.z_vertex)
        c = 1.0 / self.R                         # courbure signée
        return self.z_vertex + c * x**2 / (1.0 + np.sqrt(1.0 - (c * x) ** 2))

    def implicit(self, point) -> float:
        """F(x, z) = x^2 + (z - z_c)^2 - R^2 (nul sur la sphère).
        Pour un plan : F = z - z_vertex."""
        x, z = point
        if self.is_plane:
            return z - self.z_vertex
        return x**2 + (z - self.center[1]) ** 2 - self.R**2

    def normal(self, point) -> np.ndarray:
        """Normale unitaire N_geo = (P - C)/R, orientée vers le milieu n1."""
        if self.is_plane:
            return np.array([0.0, -1.0])
        P = np.asarray(point, dtype=float)
        N = (P - self.center) / self.R
        return N / np.linalg.norm(N)

    def _on_cap(self, point, check_aperture: bool = True) -> bool:
        """Vrai si le point est sur la calotte côté sommet et dans l'ouverture.

        Côté sommet  <=>  (z - z_c) a le signe opposé à R  (car z_v - z_c = -R).
        """
        x, z = point
        if check_aperture and abs(x) > self.semi_aperture * (1 + 1e-12):
            return False
        if self.is_plane:
            return True
        return (z - self.center[1]) * self.R <= 0.0

    # ------------------------------------------------------------------ #
    # Intersection rayon / surface
    # ------------------------------------------------------------------ #
    def intersect(self, position, direction, check_aperture: bool = True) -> Optional[float]:
        """Distance t > 0 jusqu'à l'intersection physique, ou None.

        Sphère : on résout |r0 + t d - C|^2 = R^2. Avec oc = r0 - C et |d| = 1 :
            t^2 + 2 b t + c = 0,   b = d . oc,   c = |oc|^2 - R^2
            delta = b^2 - c ;  delta < 0  => pas d'intersection
            t = -b -/+ sqrt(delta)
        Parmi les racines t > T_EPS, on garde la plus petite qui tombe sur la
        calotte utile (côté sommet, dans l'ouverture). L'autre racine
        correspond à la face opposée du cercle, non physique.

        Plan : t = (z_vertex - z0) / dz.

        check_aperture=False : ignore l'ouverture (mais garde la calotte côté
        sommet) ; sert à savoir OÙ un rayon arrêté frappe la monture.
        """
        r0 = np.asarray(position, dtype=float)
        d = np.asarray(direction, dtype=float)
        d = d / np.linalg.norm(d)

        if self.is_plane:
            if abs(d[1]) < 1e-15:
                return None
            t = (self.z_vertex - r0[1]) / d[1]
            if t <= T_EPS:
                return None
            return t if self._on_cap(r0 + t * d, check_aperture) else None

        oc = r0 - self.center
        b = float(np.dot(d, oc))
        c = float(np.dot(oc, oc)) - self.R**2
        delta = b * b - c
        if delta < 0.0:
            return None
        sq = np.sqrt(delta)
        # Forme stable des racines (évite la soustraction de deux nombres proches)
        q = -b - sq if b >= 0 else -b + sq
        roots = [q]
        if q != 0.0:
            roots.append(c / q)
        else:
            roots.append(0.0)
        candidates = sorted(t for t in roots if t > T_EPS)
        for t in candidates:
            if self._on_cap(r0 + t * d, check_aperture):
                return float(t)
        return None

    # ------------------------------------------------------------------ #
    # Réfraction
    # ------------------------------------------------------------------ #
    def media(self, direction, point):
        """(n_incident, n_transmis) selon le côté d'où vient le rayon."""
        if np.dot(direction, self.normal(point)) < 0.0:
            return self.n1, self.n2   # vient du côté n1 (normale pointe vers lui)
        return self.n2, self.n1

    def refract(self, direction, point) -> tuple[RefractionResult, float, float]:
        """Réfracte un rayon de direction `direction` au point `point` de la surface.

        Retourne (résultat, n_incident, n_transmis).
        """
        n_in, n_out = self.media(direction, point)
        result = refract(direction, self.normal(point), n_in, n_out)
        return result, n_in, n_out

    def __repr__(self) -> str:
        return (f"SphericalSurface(z_vertex={self.z_vertex}, R={self.R}, "
                f"n1={self.n1}, n2={self.n2}, semi_aperture={self.semi_aperture})")
