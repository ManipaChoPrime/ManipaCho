"""Front d'onde GÉOMÉTRIQUE à partir de l'OPL des rayons (V2.1).

Ce module calcule l'aberration de front d'onde (OPD) d'un faisceau issu d'un
point objet sur l'axe d'un système de révolution, à partir de l'OPL exact des
rayons. Ce n'est PAS une propagation du champ : pas de diffraction (en
particulier pas de diffraction par les ouvertures qui tronquent le faisceau),
pas de Fresnel, pas de polarisation, et seulement des rayons méridiens.

SURFACE DE RÉFÉRENCE
--------------------
* reference="plane"  : plan z = z_ref (faisceau collimaté). L'OPD mesuré est
  l'écart du front d'onde à un plan : il contient le défocus résiduel (le
  front d'onde d'un faisceau légèrement divergent est une calotte sphérique).
* reference="sphere" : sphère de centre C = (0, z_center) passant par l'axe
  en z_ref (faisceau convergent ou divergent ; C = point image de référence,
  réel ou virtuel). Rayon de référence R_ref = z_ref - z_center (signé).
Pour chaque rayon transmis, on prolonge la droite de sortie (depuis la
dernière surface traversée) jusqu'à la surface de référence, à l'intersection
située du côté du sommet de référence. Le paramètre t peut être négatif
(référence avant la dernière surface, image virtuelle) : la contribution
n t est alors négative, ce qui est la définition standard (prolongement
virtuel du rayon dans le dernier milieu).

    OPL_i = OPL(source -> dernière surface) + n_dernier * t_i

CONVENTION DE RÉFÉRENCE ET DE SIGNE
-----------------------------------
    OPD_i = OPL_i - OPL_ref,   OPL_ref = OPL du rayon AXIAL (rayon chef d'un
    objet sur l'axe), extrapolé en r = 0 par un ajustement en r² sur les
    rayons les plus proches de l'axe s'il n'y a pas de rayon exactement axial.
    phase_i = 2π OPD_i / lambda0   (lambda0 dans le VIDE : l'OPL contient déjà n)
OPD > 0 : le rayon a parcouru un chemin optique plus long que le rayon chef
jusqu'à la référence, c'est-à-dire que le front d'onde est EN RETARD sur la
surface de référence à cette hauteur.

PONDÉRATIONS ET MÉTRIQUES
-------------------------
Les rayons sont des échantillons de la pupille (section du faisceau sur la
référence). Avec r = hauteur sur la référence, chaque rayon porte :
  P_i   : puissance (ray.power)
  dA_i  : aire de sa demi-couronne sur la référence (bornes aux milieux
          entre rayons voisins du même côté)
  I_i   = P_i / dA_i  (intensité) ;  amplitude A_i = sqrt(I_i)
* OPD RMS "puissance" : sqrt(<(OPD - <OPD>_P)²>_P)  (piston retiré, poids P) —
  erreur de front d'onde pondérée par la puissance.
* OPD RMS "pupille uniforme" : même chose avec poids dA (aire), ce qu'on
  appelle d'habitude RMS sur la pupille. Ne dépend pas de l'éclairement.
* OPD PV : max - min sur les rayons transmis (non pondéré, sensible au bord).
* Défocus retiré : ajustement OPD = c0 + c2 r² (poids P) et RMS du résidu ;
  équivaut à changer le rayon de la sphère de référence (ou à refocaliser).
* Strehl :
  - somme directe  S = |Σ A_i dA_i e^{i φ_i}|² / (Σ A_i dA_i)²
    = rapport de l'intensité au centre de la figure de focalisation (lentille
    idéale, Fraunhofer) à celle du MÊME faisceau sans aberration (même
    profil d'amplitude, même troncature). Poids = AMPLITUDE × aire
    (= sqrt(P dA)), pas intensité.
  - Maréchal  S ≈ exp(-σ_φ²), σ_φ = écart-type de φ pondéré par A dA
    (développement de la somme directe pour les petites aberrations).
  Validité signalée : échantillonnage de phase (|Δφ| entre rayons voisins
  < π/2), pas de caustique (r monotone en angle source), et pour Maréchal
  σ_OPD < λ/14 (S ≳ 0,8).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .ray import ALIVE
from .opl import last_surface_state
from .beam import source_ray, source_theta


@dataclass
class Wavefront:
    reference: str
    z_ref: float
    z_center: Optional[float]
    wavelength: float
    x: np.ndarray            # hauteur (signée) d'intersection avec la référence
    opl: np.ndarray
    opd: np.ndarray          # OPL - OPL_ref
    phase: np.ndarray        # 2π OPD / λ0
    power: np.ndarray
    area: np.ndarray         # aire de demi-couronne sur la référence
    theta_source: np.ndarray
    opl_ref: float
    rays: list = field(repr=False, default_factory=list)

    # ---------------------------------------------------------------- #
    @property
    def amplitude_area(self) -> np.ndarray:
        """A_i dA_i = sqrt(I_i) dA_i = sqrt(P_i dA_i)."""
        return np.sqrt(self.power * self.area)

    def _wmean(self, v, w):
        return float(np.sum(w * v) / np.sum(w))

    def rms(self, weights: str = "power", opd=None) -> float:
        opd = self.opd if opd is None else opd
        w = {"power": self.power, "area": self.area, "amplitude": self.amplitude_area}[weights]
        m = self._wmean(opd, w)
        return float(np.sqrt(self._wmean((opd - m) ** 2, w)))

    @property
    def pv(self) -> float:
        return float(self.opd.max() - self.opd.min())

    def defocus_fit(self):
        """OPD ≈ c0 + c2 r² (poids puissance). Retourne (c0, c2, résidu)."""
        r2 = self.x**2
        W = np.sqrt(self.power)
        A = np.vstack([np.ones_like(r2), r2]).T
        coef, *_ = np.linalg.lstsq(A * W[:, None], self.opd * W, rcond=None)
        return float(coef[0]), float(coef[1]), self.opd - A @ coef

    def rms_defocus_removed(self, weights: str = "power") -> float:
        return self.rms(weights, self.defocus_fit()[2])

    def strehl_direct(self, opd=None) -> float:
        opd = self.opd if opd is None else opd
        a = self.amplitude_area
        phi = 2 * np.pi * opd / self.wavelength
        return float(np.abs(np.sum(a * np.exp(1j * phi))) ** 2 / np.sum(a) ** 2)

    def strehl_marechal(self, opd=None) -> float:
        opd = self.opd if opd is None else opd
        sigma = 2 * np.pi * self.rms("amplitude", opd) / self.wavelength
        return float(np.exp(-sigma**2))

    def validity(self, opd=None) -> dict:
        """Contrôles des hypothèses des estimations de Strehl."""
        opd = self.opd if opd is None else opd
        notes = {}
        ok = True
        for side in (self.x > 0, self.x < 0):
            if side.sum() < 3:
                continue
            o = np.argsort(np.abs(self.theta_source[side]))
            r = np.abs(self.x[side])[o]
            if np.any(np.diff(r) <= 0):
                notes["caustique"] = "r non monotone en angle source : amplitude géométrique invalide"
                ok = False
            ph = 2 * np.pi * opd[side][o] / self.wavelength
            dphi = np.max(np.abs(np.diff(ph))) if len(ph) > 1 else 0.0
            notes["max |Δφ| voisins (rad)"] = max(notes.get("max |Δφ| voisins (rad)", 0.0), float(dphi))
            if dphi > np.pi / 2:
                notes["échantillonnage"] = "phase sous-échantillonnée (|Δφ| > π/2)"
                ok = False
        rms_amp = self.rms("amplitude", opd)
        notes["σ_OPD / λ (poids amplitude)"] = rms_amp / self.wavelength
        notes["direct_ok"] = ok
        notes["marechal_ok"] = ok and rms_amp < self.wavelength / 14
        return notes

    def summary(self, label: str = "") -> str:
        c0, c2, _ = self.defocus_fit()
        v = self.validity()
        lam = self.wavelength
        s = [f"Front d'onde {label} — référence {self.reference}"
             + (f" (centre z = {self.z_center:.4f}, R = {self.z_ref - self.z_center:.4f})"
                if self.reference == "sphere" else f" (z = {self.z_ref:.4f})"),
             f"  OPD RMS (puissance)        = {self.rms('power') / lam:.4f} λ  ({self.rms('power') * 1e6:.2f} nm)",
             f"  OPD RMS (pupille uniforme) = {self.rms('area') / lam:.4f} λ",
             f"  OPD PV                     = {self.pv / lam:.4f} λ",
             f"  défocus ajusté c2 = {c2:.3e} mm⁻¹ ; RMS hors défocus (puissance) = "
             f"{self.rms_defocus_removed('power') / lam:.4f} λ",
             f"  Strehl : somme directe = {self.strehl_direct():.4f}"
             f"{'' if v['direct_ok'] else ' [NON VALIDE]'} ; Maréchal = {self.strehl_marechal():.4f}"
             f"{'' if v['marechal_ok'] else ' [hors domaine]'} ; "
             f"hors défocus : direct = {self.strehl_direct(self.defocus_fit()[2]):.4f}"]
        return "\n".join(s)


def _half_ring_areas(x):
    """Aire de demi-couronne de chaque rayon, côté par côté (x > 0, x < 0) ;
    un rayon exactement en x = 0 reçoit le disque central de rayon r1/2."""
    area = np.zeros_like(x)
    zero = x == 0
    for side in (x > 0, x < 0):
        idx = np.where(side)[0]
        if len(idx) == 0:
            continue
        r = np.abs(x[idx])
        o = np.argsort(r)
        rs = r[o]
        mids = 0.5 * (rs[1:] + rs[:-1])
        lo = np.concatenate([[rs[0] / 2 if zero.any() else 0.0], mids])
        hi = np.concatenate([mids, [rs[-1] + (rs[-1] - lo[-1])]])
        area[idx[o]] = np.pi * (hi**2 - lo**2) / 2.0
    if zero.any():
        r_pos = np.abs(x[~zero])
        r1 = r_pos.min() if len(r_pos) else 0.0
        area[zero] = np.pi * (r1 / 2) ** 2 / zero.sum()
    return area


def wavefront(rays, wavelength: float, reference: str = "plane", z_ref: float = None,
              z_center: float = None) -> Wavefront:
    """OPD géométrique des rayons transmis par rapport à la surface de référence."""
    if reference not in ("plane", "sphere"):
        raise ValueError("reference ∈ {'plane', 'sphere'}")
    if reference == "sphere" and (z_center is None or z_center == z_ref):
        raise ValueError("Référence sphérique : z_center requis et ≠ z_ref.")
    xs, opl, P, ths, kept = [], [], [], [], []
    for r in rays:
        if r.status != ALIVE:
            continue                                   # rayons perdus : jamais réintroduits
        pos, d, n, opl_s = last_surface_state(r)
        if reference == "plane":
            if abs(d[1]) < 1e-15:
                continue
            t = (z_ref - pos[1]) / d[1]
        else:
            C = np.array([0.0, z_center])
            Rr = z_ref - z_center
            oc = pos - C
            b = float(np.dot(d, oc))
            c = float(np.dot(oc, oc)) - Rr**2
            disc = b * b - c
            if disc < 0:
                continue
            roots = (-b - np.sqrt(disc), -b + np.sqrt(disc))
            # intersection du côté du sommet de référence : signe(z - z_c) = signe(R)
            cand = [t for t in roots if np.sign((pos + t * d)[1] - z_center) == np.sign(Rr)]
            if not cand:
                continue
            t = min(cand, key=abs)
        xs.append((pos + t * d)[0])
        opl.append(opl_s + n * t)
        P.append(source_ray(r).power)
        ths.append(source_theta(r))
        kept.append(r)
    xs, opl, P, ths = map(np.asarray, (xs, opl, P, ths))
    if len(xs) < 3:
        raise ValueError("Pas assez de rayons transmis pour définir un front d'onde.")
    # OPL de référence : rayon axial (theta_source = 0) ou extrapolation en r = 0
    axial = np.where(ths == 0.0)[0]
    if len(axial):
        opl_ref = float(opl[axial[0]])
    else:
        near = np.argsort(np.abs(xs))[:6]
        c = np.polyfit(xs[near] ** 2, opl[near], 1)
        opl_ref = float(c[-1])
    opd = opl - opl_ref
    return Wavefront(reference=reference, z_ref=float(z_ref),
                     z_center=None if z_center is None else float(z_center),
                     wavelength=float(wavelength), x=xs, opl=opl, opd=opd,
                     phase=2 * np.pi * opd / wavelength, power=P, area=_half_ring_areas(xs),
                     theta_source=ths, opl_ref=opl_ref, rays=kept)
