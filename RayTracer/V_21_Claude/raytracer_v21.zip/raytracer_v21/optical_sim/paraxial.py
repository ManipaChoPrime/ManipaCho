"""Optique paraxiale par matrices de transfert (référence analytique).

Ce module ne sert qu'à VALIDER le tracé exact : il donne ce que le tracé
exact doit retrouver dans la limite des petits angles. Il ne dit rien des
rayons marginaux.

CONVENTION
----------
Vecteur paraxial (y, nu) avec y = hauteur (x) et nu = n * u, où u = dx/dz est
la pente (angle paraxial, positif vers +x). Propagation vers +z.

    Réfraction (surface d'indices n1 -> n2, rayon R) :
        y' = y,   nu' = nu - P y,   P = (n2 - n1) / R     (P = 0 pour un plan)
        matrice [[1, 0], [-P, 1]]
    Translation d'une distance d dans un milieu n :
        y' = y + (d / n) nu,  nu' = nu
        matrice [[1, d/n], [0, 1]]

Matrice du système de la 1re à la dernière surface : M = [[A, B], [C, D]],
det M = 1 (vecteurs "réduits"). Puissance P = -C.
    EFL = n_out / P                (focale image ; = n_in/P côté objet)
    BFD = A n_out / P              (dernier sommet -> foyer image)
    FFD = D n_in / P               (foyer objet -> premier sommet)
Signe : P > 0 convergent ; BFD > 0 foyer réel après le dernier sommet.
"""

from __future__ import annotations

import numpy as np


def refraction_matrix(surface) -> np.ndarray:
    P = 0.0 if surface.is_plane else (surface.n2 - surface.n1) / surface.R
    return np.array([[1.0, 0.0], [-P, 1.0]])


def translation_matrix(d: float, n: float) -> np.ndarray:
    return np.array([[1.0, d / n], [0.0, 1.0]])


def system_matrix(surfaces) -> np.ndarray:
    """Matrice du sommet de la 1re surface au sommet de la dernière."""
    surfaces = list(surfaces)
    M = np.eye(2)
    for i, s in enumerate(surfaces):
        if i > 0:
            prev = surfaces[i - 1]
            M = translation_matrix(s.z_vertex - prev.z_vertex, prev.n2) @ M
        M = refraction_matrix(s) @ M
    return M


def cardinal(surfaces) -> dict:
    surfaces = list(surfaces)
    (A, B), (C, D) = system_matrix(surfaces)
    n_in, n_out = surfaces[0].n1, surfaces[-1].n2
    P = -C
    if abs(P) < 1e-15:
        return dict(P=0.0, EFL=np.inf, BFD=np.inf, FFD=np.inf, matrix=np.array([[A, B], [C, D]]))
    efl, bfd, ffd = n_out / P, A * n_out / P, D * n_in / P
    z_bf = surfaces[-1].z_vertex + bfd
    z_ff = surfaces[0].z_vertex - ffd
    return dict(
        P=P, EFL=efl, BFD=bfd, FFD=ffd,
        z_back_focus=z_bf,
        z_front_focus=z_ff,
        # Plans principaux : H' (image) à EFL avant le foyer image, H (objet)
        # à n_in/P après le foyer objet. Valable aussi pour un milieu n != 1.
        z_H_image=z_bf - efl,
        z_H_object=z_ff + n_in / P,
        matrix=np.array([[A, B], [C, D]]),
    )


def afocal_gap(element1, element2, n_gap: float = 1.0) -> float:
    """Distance sommet-sommet (dernier sommet de element1 -> premier sommet de
    element2) qui rend l'ensemble afocal (C = 0).

    Avec M1 = [[A1, B1], [C1, D1]] et M2 = [[A2, B2], [C2, D2]] les matrices
    sommet-à-sommet des deux éléments, et T(g) = [[1, g/n], [0, 1]] :
        M = M2 T(g) M1   =>   C(g) = C2 A1 + D2 C1 + (g / n) C2 C1
    C est affine en g, d'où
        g = -n (C2 A1 + D2 C1) / (C2 C1).
    Le grandissement transverse du système afocal est alors A (= 1/D) :
    un rayon d'entrée // axe à la hauteur h ressort // axe à la hauteur A h.
    """
    (A1, _), (C1, D1) = system_matrix(element1.surfaces)
    (A2, _), (C2, D2) = system_matrix(element2.surfaces)
    if abs(C1 * C2) < 1e-15:
        raise ValueError("Un des éléments est afocal : séparation afocale indéterminée.")
    return -n_gap * (C2 * A1 + D2 * C1) / (C2 * C1)


def image_position(surfaces, z_object: float) -> float:
    """Position z de l'image paraxiale d'un point objet sur l'axe en z_object.

    On part du point objet avec y = 0, u = 1 (pente arbitraire, le résultat
    paraxial ne dépend pas de u), on translate jusqu'au premier sommet,
    on applique M, puis l'image est là où y redevient nul :
        s' = -y_out n_out / nu_out   (depuis le dernier sommet).
    Retourne +/-inf si l'image est à l'infini. Une image virtuelle donne
    z_image < z du dernier sommet.
    """
    surfaces = list(surfaces)
    n_in, n_out = surfaces[0].n1, surfaces[-1].n2
    s = surfaces[0].z_vertex - z_object
    v = np.array([s * 1.0, n_in * 1.0])        # y = s*u, nu = n_in*u avec u = 1
    y, nu = system_matrix(surfaces) @ v
    if abs(nu) < 1e-15:
        return np.inf
    return surfaces[-1].z_vertex - y * n_out / nu
