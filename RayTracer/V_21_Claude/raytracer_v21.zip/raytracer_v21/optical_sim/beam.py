"""Analyse géométrique d'un faisceau : position x(z), diamètres, clipping, divergence.

Tout ici reste de l'OPTIQUE GÉOMÉTRIQUE pondérée : pas de diffraction, pas
de phase. Les diamètres "gaussiens" sont des images géométriques du cône à
1/e² de la source ; ils coïncident avec le diamètre d'un vrai faisceau
gaussien tant que l'on est loin de tout point de focalisation, que les
distances restent petites devant la longueur de Rayleigh du faisceau
considéré, et que les aberrations sont faibles.

PONDÉRATION (V2.1)
------------------
Toutes les moyennes sont pondérées par la PUISSANCE portée par chaque rayon
(`ray.power`, fixée par la source, voir ray.py et source.py). Pour une source
sur l'axe d'un système de révolution, un rayon méridien à la hauteur x
représente une couronne de rayon r = |x| : les moyennes de puissance sur les
rayons sont donc des moyennes sur toute la section 2D du faisceau.

TROIS FAMILLES DE DIAMÈTRES — NON ÉQUIVALENTES
---------------------------------------------
A. Rayons marqueurs / extrêmes :
   * D_1e2(z) = |x(+theta0, z)| + |x(-theta0, z)| : écart entre les deux rayons
     lancés exactement à ±theta0 (interpolés en angle initial) = image
     géométrique du cône 1/e² de la source. Égal au diamètre 1/e² tant que
     theta -> x est linéaire et que le faisceau n'a pas été tronqué ; après
     troncature ou forte aberration, ce n'est plus qu'un marqueur.
   * r_max : rayon maximal des rayons présents (enveloppe, dépend de
     l'éventail tracé et des ouvertures).
B. Moments (ISO 11146) : D4σ_x = 4 sqrt(<x²>) avec, pour un faisceau de
   révolution centré, <x²> = <r²>/2 (moyenne de puissance sur la section).
   Pour une gaussienne exp(-2r²/w²) : <r²> = w²/2, D4σ = 2w. Sensible aux
   ailes : diminue après troncature.
C. Ajustement gaussien : intensité locale I = P / dA estimée à partir des
   couronnes de rayons, ajustée par I0 exp(-2r²/w²). Mesure la forme du cœur ;
   le résidu de l'ajustement dit si le profil est encore gaussien.
(V1.5 utilisait pour D4σ des poids "coupe" I(theta) qui ne sont pas des
puissances : remplacé en V2.1 par la définition ISO ci-dessus.)

CLIPPING GAUSSIEN — RÉFÉRENCE ANALYTIQUE
----------------------------------------
Faisceau gaussien circulaire de rayon 1/e² w, CENTRÉ sur une ouverture
circulaire de rayon a, profil non aberré :
        T = 1 - exp(-2 a² / w²)
Le calcul par sommes de puissances des rayons transmis est l'estimation
géométrique générale ; il ne coïncide avec la formule que sous ces hypothèses
(faisceau centré, non tronqué en amont, profil gaussien non aberré).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .ray import Ray, ALIVE


def source_ray(ray):
    """Rayon d'origine (suit les liens `parent` créés par restart_rays)."""
    while getattr(ray, "parent", None) is not None:
        ray = ray.parent
    return ray


def source_theta(ray) -> float:
    """Angle initial du rayon À LA SOURCE (suit les liens `parent` créés par
    restart_rays, pour qu'un rayon redémarré garde le poids de son origine)."""
    return source_ray(ray).theta_initial


def ray_powers(rays) -> np.ndarray:
    """Puissance portée par chaque rayon (constante le long du rayon)."""
    return np.array([source_ray(r).power for r in rays], dtype=float)


def weighted_transmission(rays, source=None) -> float:
    """Fraction de puissance transmise = somme des puissances des rayons
    ressortis du système / somme des puissances de tous les rayons tracés.
    (`source` n'est plus utilisé : conservé pour compatibilité.)"""
    P = ray_powers(rays)
    ok = np.array([r.status == ALIVE for r in rays])
    return float(P[ok].sum() / P.sum())


# ============================================================================
# Position d'un rayon dans un plan z
# ============================================================================
def x_at_z(ray, z: float, extend: bool = True, extend_blocked: bool = False) -> Optional[float]:
    """Hauteur x du rayon dans le plan z, ou None s'il n'y passe pas.

    On cherche le segment de l'historique qui contient z (interpolation
    linéaire, exacte puisque les segments sont rectilignes). Au-delà du
    dernier point, un rayon VIVANT est prolongé en ligne droite (extend=True) ;
    un rayon arrêté (MISSED/TIR) n'existe pas au-delà de son dernier point,
    sauf si extend_blocked=True (prolongement géométrique de son dernier
    segment, utile pour mesurer le faisceau incident sur l'ouverture qui l'a arrêté).
    Suppose que z varie de façon monotone le long du rayon (cas séquentiel
    standard, rayons allant vers +z).
    """
    h = ray.history
    for k in range(1, len(h)):
        z0, z1 = h[k - 1].position[1], h[k].position[1]
        if min(z0, z1) <= z <= max(z0, z1) and z1 != z0:
            s = (z - z0) / (z1 - z0)
            return float(h[k - 1].position[0] + s * (h[k].position[0] - h[k - 1].position[0]))
    last = h[-1]
    if extend and (ray.status == ALIVE or extend_blocked) and z >= last.position[1]:
        dx, dz = ray.direction
        if dz <= 1e-15:
            return None
        return float(last.position[0] + (z - last.position[1]) * dx / dz)
    if len(h) == 1 and z == h[0].position[1]:
        return float(h[0].position[0])
    return None


def direction_at_z(ray, z: float) -> Optional[np.ndarray]:
    """Direction (dx, dz) du segment du rayon qui traverse le plan z (None sinon)."""
    h = ray.history
    for k in range(1, len(h)):
        z0, z1 = h[k - 1].position[1], h[k].position[1]
        if min(z0, z1) <= z <= max(z0, z1) and z1 != z0:
            return h[k - 1].direction.copy()
    if ray.status == ALIVE and z >= h[-1].position[1]:
        return ray.direction.copy()
    return None


def gaussian_transmission(a: float, w: float) -> float:
    """T = 1 - exp(-2 a²/w²) : faisceau gaussien centré, ouverture circulaire."""
    return float(1.0 - np.exp(-2.0 * a**2 / w**2))


# ============================================================================
# Diamètres en fonction de z
# ============================================================================
@dataclass
class BeamProfile:
    z: np.ndarray
    d_1e2: np.ndarray        # diamètre des rayons ±theta0 (NaN si indéfini)
    d4sigma: np.ndarray      # D4σ ISO : 4 sqrt(<r²>/2), puissance, rayons présents
    d_env: np.ndarray        # enveloppe géométrique des rayons présents
    n_present: np.ndarray    # nombre de rayons présents en z


def _theta0_ray_heights(rays, theta0, z, first_surface=None):
    """Hauteurs interpolées des rayons ±theta0 dans le plan z (NaN si impossible).

    first_surface : si donné, faisceau INCIDENT sur l'élément commençant à
    cette surface : les rayons qui l'ont atteint sont prolongés jusqu'à z même
    s'ils y ont été arrêtés ; ceux arrêtés avant sont exclus."""
    out = []
    for sign in (+1, -1):
        th, xs = [], []
        for r in rays:
            t = source_theta(r) * sign
            if t < 0:
                continue
            if first_surface is None:
                x = x_at_z(r, z)
            elif r.blocked_at is not None and r.blocked_at < first_surface:
                x = None
            else:
                x = x_at_z(r, z, extend_blocked=True)
            th.append(t)
            xs.append(np.nan if x is None else x)
        th, xs = np.asarray(th), np.asarray(xs)
        order = np.argsort(th)
        th, xs = th[order], xs[order]
        # rayons encadrant theta0, tous deux présents
        i = np.searchsorted(th, theta0)
        if i == 0 or i >= len(th) or np.isnan(xs[i - 1]) or np.isnan(xs[i]):
            out.append(np.nan)
        else:
            s = (theta0 - th[i - 1]) / (th[i] - th[i - 1])
            out.append(xs[i - 1] + s * (xs[i] - xs[i - 1]))
    return out


def beam_profile(rays, source, zs) -> BeamProfile:
    """Diamètres du faisceau dans chaque plan de `zs` (voir définitions en tête)."""
    zs = np.atleast_1d(np.asarray(zs, dtype=float))
    P_all = ray_powers(rays)
    d1, d4, de, npres = [], [], [], []
    for z in zs:
        xs = np.array([np.nan if (x := x_at_z(r, z)) is None else x for r in rays])
        ok = ~np.isnan(xs)
        npres.append(int(ok.sum()))
        if ok.sum() < 2:
            d4.append(np.nan); de.append(np.nan); d1.append(np.nan)
            continue
        w = P_all[ok]
        d4.append(4.0 * np.sqrt(0.5 * np.sum(w * xs[ok] ** 2) / np.sum(w)))
        de.append(2.0 * np.max(np.abs(xs[ok])))
        xp, xn = _theta0_ray_heights(rays, source.theta0, z)
        d1.append(abs(xp - xn) if not (np.isnan(xp) or np.isnan(xn)) else np.nan)
    return BeamProfile(zs, np.array(d1), np.array(d4), np.array(de), np.array(npres))


# ============================================================================
# Clipping par élément
# ============================================================================
@dataclass
class ClipEntry:
    name: str
    semi_aperture: float
    z_entry: float
    w_entry: float           # rayon 1/e² (rayons ±theta0) au 1er sommet de l'élément
    w_worst: float           # rayon 1/e² à la surface la plus défavorable (a/w minimal)
    n_blocked: int
    p_incident: float        # fraction de la puissance source arrivant sur l'élément
    p_blocked: float         # fraction de la puissance source arrêtée par l'élément
    t_rays: float            # transmission mesurée (rayons pondérés) = 1 - blocked/incident
    t_analytic: float        # 1 - exp(-2 a²/w²) à la surface la plus défavorable (réf., cas centré)


@dataclass
class ClipReport:
    entries: list
    transmitted: float       # fraction de la puissance source transmise par tout le système
    lost_outside_fan: float  # puissance hors du cône tracé (exp(-2 k²)) : non comptée

    def table(self) -> str:
        lines = [f"{'élément':<22}{'a (mm)':>8}{'w entrée':>10}{'w max':>8}{'T rayons':>11}{'T analyt.':>11}{'rayons coupés':>15}"]
        for e in self.entries:
            lines.append(f"{e.name:<22}{e.semi_aperture:>8.3f}{e.w_entry:>10.3f}{e.w_worst:>8.3f}"
                         f"{e.t_rays:>11.5f}{e.t_analytic:>11.5f}{e.n_blocked:>15d}")
        lines.append(f"transmission totale (rayons pondérés) : {self.transmitted:.5f}"
                     f"   [hors cône tracé : {self.lost_outside_fan:.1e}]")
        return "\n".join(lines)


def clipping_report(system, rays, source) -> ClipReport:
    """Bilan de puissance par élément (poids "radial", source sur l'axe).

    Pour chaque élément : puissance incidente (rayons qui l'atteignent),
    puissance arrêtée (rayons dont blocked_at est une de ses surfaces), et
    transmission T_rays = 1 - P_arrêtée / P_incidente, comparée à la formule
    analytique 1 - exp(-2 a²/w²) évaluée À CHAQUE SURFACE de l'élément (w =
    rayon des marqueurs ±theta0 SUR la surface, a = sa demi-ouverture), en gardant la
    plus défavorable : dans une lentille épaisse divergente, le faisceau
    s'élargit d'une surface à l'autre et c'est souvent la dernière qui coupe.
    La comparaison n'a de sens que si le faisceau est centré, gaussien, peu
    aberré, et pas déjà tronqué en amont (sinon la formule surestime les pertes).
    """
    w_rad = ray_powers(rays)
    total = w_rad.sum()
    blocked_at = np.array([-1 if r.blocked_at is None else r.blocked_at for r in rays])
    entries = []
    for el in system.elements:
        idx = system.element_surface_indices(el)
        first = idx[0]
        # un rayon atteint l'élément s'il n'a pas été arrêté avant sa 1re surface
        reached = (blocked_at < 0) | (blocked_at >= first)
        blocked = np.isin(blocked_at, idx)
        p_inc = w_rad[reached].sum() / total
        p_blk = w_rad[blocked].sum() / total
        z_e = system.surfaces[first].z_vertex
        ws, ts = [], []
        for i in idx:
            surf = system.surfaces[i]
            w_i = 0.5 * marker_diameter_at_surface(rays, source.theta0, i)
            ws.append(w_i)
            ts.append(gaussian_transmission(surf.semi_aperture, w_i) if np.isfinite(w_i) else np.nan)
        k_worst = int(np.nanargmin(ts)) if np.any(np.isfinite(ts)) else 0
        entries.append(ClipEntry(
            name=el.name or type(el).__name__, semi_aperture=el.semi_aperture, z_entry=z_e,
            w_entry=ws[0], w_worst=ws[k_worst],
            n_blocked=int(blocked.sum()), p_incident=p_inc, p_blocked=p_blk,
            t_rays=1.0 - p_blk / p_inc if p_inc > 0 else np.nan,
            t_analytic=ts[k_worst]))
    transmitted = w_rad[blocked_at < 0].sum() / total
    lost = (1 - source._fan_fraction()) if hasattr(source, "_fan_fraction") else np.nan
    return ClipReport(entries, transmitted, float(lost))


# ============================================================================
# Divergence de sortie
# ============================================================================
@dataclass
class Divergence:
    """Divergence géométrique au plan z_ref (puissance-pondérée).

    theta_r = theta * signe(x) : angle RADIAL (> 0 : le rayon s'éloigne de l'axe).
    theta_rms = sqrt(<theta_r²>)             (radial, sur toute la section)
    sigma_x   = sqrt(<theta_x²>) = theta_rms/√2 (2nd moment ISO par axe,
                faisceau de révolution centré)
    mean_radial = <theta_r> : divergence (>0) / convergence (<0) globale
    Diffraction NON incluse.
    """
    x: np.ndarray            # hauteur au plan de référence
    theta: np.ndarray        # angle de sortie (rad)
    weight: np.ndarray       # puissance des rayons
    theta_rms: float
    theta_1e2: float         # demi-différence des angles des rayons ±theta0 (NaN si absent)
    sigma_x: float = np.nan
    mean_radial: float = np.nan


def output_divergence(rays, z_ref: float, source=None) -> Divergence:
    """Angles des rayons transmis AU PLAN z_ref (direction du segment qui le
    traverse), en fonction de leur hauteur en z_ref. Seuls les rayons qui
    sortent du système (statut ALIVE) sont comptés."""
    xs, th, ti, w = [], [], [], []
    for r in rays:
        if r.status != ALIVE:
            continue
        x = x_at_z(r, z_ref)
        if x is None:
            continue
        d = direction_at_z(r, z_ref)
        xs.append(x)
        th.append(float(np.arctan2(d[0], d[1])))
        ti.append(source_theta(r))
        w.append(source_ray(r).power)
    xs, th, ti, w = map(np.asarray, (xs, th, ti, w))
    t1 = np.nan
    if source is not None and hasattr(source, "theta0") and len(ti) > 1:
        order = np.argsort(ti)
        t1 = 0.5 * (np.interp(source.theta0, ti[order], th[order])
                    - np.interp(-source.theta0, ti[order], th[order]))
    if not len(th) or w.sum() <= 0:
        return Divergence(xs, th, w, np.nan, float(t1))
    th_r = th * np.where(xs >= 0, 1.0, -1.0)
    rms = float(np.sqrt(np.sum(w * th_r**2) / np.sum(w)))
    mean_r = float(np.sum(w * th_r) / np.sum(w))
    return Divergence(xs, th, w, rms, float(t1), rms / np.sqrt(2.0), mean_r)


# ============================================================================
# Redémarrage : sortie d'un sous-système -> entrée du suivant
# ============================================================================
def restart_rays(rays) -> list:
    """Nouveaux objets Ray partant de la position / direction / indice actuels
    des rayons VIVANTS (pour tracer un sous-système séparément).
    L'attribut `parent` garde le lien vers le rayon d'origine."""
    out = []
    for r in rays:
        if r.status != ALIVE:
            continue
        nr = Ray(r.position, r.direction, n=r.n)
        nr.power = r.power
        nr.parent = r
        out.append(nr)
    return out


# ============================================================================
# V2.1 — positions sur les surfaces, bilan de puissance surface par surface
# ============================================================================
def position_at_surface(ray, i: int):
    """Point d'impact du rayon sur la surface i : position de l'événement
    (rayon transmis par i) ou point d'impact sur la monture (rayon arrêté par
    i). None si le rayon n'a pas atteint i (arrêté avant) ou ne coupe pas la
    sphère (arrêté en i sans point d'impact défini)."""
    for ev in ray.history:
        if ev.surface == i:
            return ev.position
    if ray.blocked_at == i:
        return ray.blocked_point
    return None


def marker_diameter_at_surface(rays, theta0: float, i: int) -> float:
    """Diamètre entre les rayons marqueurs ±theta0 sur la surface i (NaN si l'un
    d'eux n'atteint pas la surface)."""
    out = []
    for sign in (+1, -1):
        th, xs = [], []
        for r in rays:
            t = source_theta(r) * sign
            if t < 0:
                continue
            p = position_at_surface(r, i)
            th.append(t)
            xs.append(np.nan if p is None else p[0])
        th, xs = np.asarray(th), np.asarray(xs)
        o = np.argsort(th)
        th, xs = th[o], xs[o]
        k = np.searchsorted(th, theta0)
        if k == 0 or k >= len(th) or np.isnan(xs[k - 1]) or np.isnan(xs[k]):
            return np.nan
        s_ = (theta0 - th[k - 1]) / (th[k] - th[k - 1])
        out.append(xs[k - 1] + s_ * (xs[k] - xs[k - 1]))
    return float(abs(out[0] - out[1]))


@dataclass
class SurfacePower:
    index: int
    element: str
    semi_aperture: float
    p_incident: float
    p_transmitted: float
    p_lost: float
    t_fraction: float
    r_max_incident: float     # rayon maximal des rayons incidents (impact sur la surface)
    r_max_transmitted: float
    r_rms: float              # sqrt(<r²>) pondéré par la puissance, faisceau incident
    d4sigma: float            # 2 sqrt(2) r_rms (ISO)
    d_1e2: float              # marqueurs ±theta0 sur la surface (NaN si indéfini)
    upstream_loss: float      # puissance déjà perdue avant cette surface (fraction de P_tracée)
    analytic_valid: bool
    t_analytic: float         # 1 - exp(-2 a²/w²), w = d_1e2/2, seulement si analytic_valid
    note: str


def surface_power_report(system, rays, source=None, trunc_tol: float = 1e-6,
                         gauss_tol: float = 0.02) -> list:
    """Bilan de puissance pour chaque surface d'ouverture finie.

    Puissances obtenues UNIQUEMENT par sommes de `ray.power` :
        incident(i)  = rayons non arrêtés avant i
        perdu(i)     = rayons dont blocked_at == i
        transmis(i)  = incident - perdu
    La formule analytique n'est évaluée que si ses hypothèses tiennent :
    (1) aucune troncature en amont (perte amont < trunc_tol),
    (2) faisceau centré,
    (3) profil encore gaussien au sens des moments : |D4σ / D_1e2 - 1| < gauss_tol.
    Sinon t_analytic = NaN et `note` explique pourquoi.
    """
    P = ray_powers(rays)
    P_tot = P.sum()
    blocked = np.array([np.inf if r.blocked_at is None else r.blocked_at for r in rays])
    theta0 = getattr(source, "theta0", None)
    out = []
    for i, surf in enumerate(system.surfaces):
        if not np.isfinite(surf.semi_aperture):
            continue
        inc = blocked >= i
        lost = blocked == i
        pos = [position_at_surface(r, i) if inc[k] else None for k, r in enumerate(rays)]
        r_abs = np.array([np.nan if p is None else abs(p[0]) for p in pos])
        x_sgn = np.array([np.nan if p is None else p[0] for p in pos])
        ok = inc & ~np.isnan(r_abs)
        p_inc, p_lost = P[inc].sum(), P[lost].sum()
        r_rms = float(np.sqrt(np.sum(P[ok] * r_abs[ok] ** 2) / np.sum(P[ok]))) if P[ok].sum() > 0 else np.nan
        centroid = float(np.sum(P[ok] * x_sgn[ok]) / np.sum(P[ok])) if P[ok].sum() > 0 else np.nan
        d4 = 2.0 * np.sqrt(2.0) * r_rms
        d1 = marker_diameter_at_surface(rays, theta0, i) if theta0 else np.nan
        upstream = float(P[blocked < i].sum() / P_tot)
        trans_ok = inc & ~lost & ~np.isnan(r_abs)
        reasons = []
        if upstream > trunc_tol:
            reasons.append(f"troncature amont ({upstream:.1e})")
        if not np.isfinite(d1):
            reasons.append("marqueurs ±θ0 absents")
        elif abs(d4 / d1 - 1) > gauss_tol:
            reasons.append(f"profil non gaussien (D4σ/D1e2 = {d4 / d1:.3f})")
        if np.isfinite(centroid) and np.isfinite(d1) and abs(centroid) > 1e-3 * d1:
            reasons.append("faisceau décentré")
        valid = not reasons
        out.append(SurfacePower(
            index=i, element=getattr(system.element_of(i), "name", "") or "",
            semi_aperture=surf.semi_aperture, p_incident=float(p_inc),
            p_transmitted=float(p_inc - p_lost), p_lost=float(p_lost),
            t_fraction=float((p_inc - p_lost) / p_inc) if p_inc > 0 else np.nan,
            r_max_incident=float(np.nanmax(r_abs[ok])) if ok.any() else np.nan,
            r_max_transmitted=float(np.nanmax(r_abs[trans_ok])) if trans_ok.any() else np.nan,
            r_rms=r_rms, d4sigma=float(d4), d_1e2=float(d1), upstream_loss=upstream,
            analytic_valid=valid,
            t_analytic=gaussian_transmission(surf.semi_aperture, d1 / 2) if valid else np.nan,
            note="hypothèses vérifiées" if valid else "; ".join(reasons)))
    return out


def surface_power_table(entries, p_unit: float = 1.0) -> str:
    h = (f"{'surf':>4} {'élément':<16}{'a':>7}{'P inc.':>10}{'P trans.':>10}{'P perdue':>10}"
         f"{'T':>9}{'r_max':>8}{'r_rms':>8}{'D4σ':>8}{'D1/e²':>8}{'T analyt.':>10}  note")
    lines = [h]
    for e in entries:
        ta = f"{e.t_analytic:10.5f}" if e.analytic_valid else f"{'—':>10}"
        lines.append(f"{e.index:>4} {e.element[:16]:<16}{e.semi_aperture:>7.3f}"
                     f"{e.p_incident / p_unit:>10.6f}{e.p_transmitted / p_unit:>10.6f}"
                     f"{e.p_lost / p_unit:>10.2e}{e.t_fraction:>9.5f}{e.r_max_incident:>8.3f}"
                     f"{e.r_rms:>8.3f}{e.d4sigma:>8.3f}{e.d_1e2:>8.3f}{ta}  {e.note}")
    return "\n".join(lines)


# ============================================================================
# V2.1 — propriétés du faisceau dans un plan : trois méthodes distinctes
# ============================================================================
@dataclass
class BeamStats:
    z: float
    n_rays: int
    power: float              # puissance présente dans le plan
    # A. marqueurs / extrêmes
    d_1e2_markers: float
    r_max_pos: float
    r_max_neg: float
    # B. moments (puissance)
    centroid: float           # <x> (coupe méridienne, signé)
    d4sigma: float            # 4 sqrt(<r²>/2)
    skewness: float           # <x³>/<x²>^{3/2} (méridien) : 0 si symétrique
    # C. ajustement gaussien de l'intensité locale
    d_fit: float              # 2 w_fit
    fit_residual: float       # écart relatif rms (pondéré puissance) au modèle gaussien
    # divergence (puissance)
    theta_rms: float
    sigma_theta_x: float
    mean_radial_angle: float


def _side_intensity(x, P):
    """Intensité locale (puissance / aire) des rayons d'un même côté (x >= 0),
    chaque rayon portant la moitié de sa couronne : I = 2 P / (π (r_hi² - r_lo²))."""
    o = np.argsort(x)
    r, p = x[o], P[o]
    if len(r) < 3:
        return r, np.full_like(r, np.nan), p
    mids = 0.5 * (r[1:] + r[:-1])
    lo = np.concatenate([[0.0], mids])
    hi = np.concatenate([mids, [r[-1] + (r[-1] - mids[-1])]])
    area = np.pi * (hi**2 - lo**2) / 2.0           # demi-couronne
    return r, p / area, p


def beam_stats(rays, z: float, source=None) -> BeamStats:
    pres = [r for r in rays if r.status == ALIVE and x_at_z(r, z) is not None]
    x = np.array([x_at_z(r, z) for r in pres])
    P = ray_powers(pres)
    dirs = [direction_at_z(r, z) for r in pres]
    th = np.array([np.arctan2(d[0], d[1]) for d in dirs])
    Ptot = P.sum()
    cen = float(np.sum(P * x) / Ptot)
    m2 = float(np.sum(P * (x - cen) ** 2) / Ptot)
    skew = float(np.sum(P * (x - cen) ** 3) / Ptot / m2**1.5) if m2 > 0 else np.nan
    d4 = 4.0 * np.sqrt(0.5 * np.sum(P * x**2) / Ptot)
    d1 = np.nan
    if source is not None and hasattr(source, "theta0"):
        xp, xn = _theta0_ray_heights(rays, source.theta0, z)
        d1 = abs(xp - xn) if np.isfinite(xp) and np.isfinite(xn) else np.nan
    # C. ajustement gaussien (côtés x>0 et x<0 séparément puis ensemble)
    rr, II, pp = [], [], []
    for side in (x > 0, x < 0):
        r_s, I_s, p_s = _side_intensity(np.abs(x[side]), P[side])
        rr.append(r_s); II.append(I_s); pp.append(p_s)
    rr, II, pp = map(np.concatenate, (rr, II, pp))
    good = np.isfinite(II) & (II > 1e-3 * np.nanmax(II))
    if good.sum() >= 5:
        A = np.vstack([np.ones(good.sum()), rr[good] ** 2]).T
        wts = np.sqrt(pp[good])
        coef, *_ = np.linalg.lstsq(A * wts[:, None], np.log(II[good]) * wts, rcond=None)
        w_fit = np.sqrt(-2.0 / coef[1]) if coef[1] < 0 else np.nan
        model = np.exp(coef[0] + coef[1] * rr[good] ** 2)
        resid = float(np.sqrt(np.sum(pp[good] * ((II[good] - model) / model) ** 2) / pp[good].sum()))
    else:
        w_fit, resid = np.nan, np.nan
    th_r = th * np.where(x >= 0, 1.0, -1.0)
    trms = float(np.sqrt(np.sum(P * th_r**2) / Ptot))
    return BeamStats(z=float(z), n_rays=len(pres), power=float(Ptot), d_1e2_markers=float(d1),
                     r_max_pos=float(x.max()), r_max_neg=float(-x.min()), centroid=cen,
                     d4sigma=float(d4), skewness=skew, d_fit=float(2 * w_fit), fit_residual=resid,
                     theta_rms=trms, sigma_theta_x=trms / np.sqrt(2),
                     mean_radial_angle=float(np.sum(P * th_r) / Ptot))
