"""V2.1 : audit de puissance, clipping, faisceau de sortie, front d'onde géométrique.

    python examples/v21_analysis.py

Chaîne réelle à 1030 nm (orientations : collimateur retourné, ACN127 sens du
dessin, AC254-060 retournée). Produit 3 figures et v21_report.txt.
"""

import os
import sys
import warnings

import numpy as np
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import chain  # noqa: E402
from optical_sim import (surface_power_report, surface_power_table, weighted_transmission,  # noqa: E402
                         beam_stats, wavefront, ray_powers, GaussianFiberSource)

warnings.simplefilter("ignore")
chain.FORCE_STANDIN = False
chain.CONFIG.update(flip_collimator=True, flip_l1=False, flip_l2=True)
LAM = chain.CONFIG["wavelength"]
OUT = []


def say(s=""):
    print(s)
    OUT.append(s)


say("=" * 100)
say("V2.1 — chaîne réelle à 1030 nm : puissance, clipping, faisceau, front d'onde géométrique")
say("=" * 100)

# ----------------------------------------------------------------------------
# 1. Audit de la source
# ----------------------------------------------------------------------------
src = chain.make_source(n_rays=2401)
say("\n1. SOURCE FIBRÉE (GaussianFiberSource)")
say(f"   w0 = {src.w0 * 1e3:.3f} µm, θ0 = λ/(π w0) = {src.theta0 * 1e3:.3f} mrad, "
    f"éventail ±{src.theta_factor:g} θ0, z_R(fibre) = {src.rayleigh_range * 1e3:.1f} µm")
say("   poids = PUISSANCE du tube de rayons (ray.power), intégrale exacte de dP/dθ ∝ "
    "exp(-2θ²/θ0²)·sin θ sur la couronne du rayon")
for samp in ("angle", "power"):
    s_ = chain.make_source(n_rays=2401)
    s_.sampling = samp
    P = ray_powers(s_.generate_rays())
    say(f"   échantillonnage '{samp}': ΣP = {P.sum():.10f} (fraction du mode dans l'éventail "
        f"{s_._fan_fraction():.10f}), P min/max = {P[P > 0].min():.2e} / {P.max():.2e}")
ratio_sin = np.exp(-2 * np.sin(src.theta0) ** 2 / src.theta0**2) / np.exp(-2)
say(f"   modèle paraxial exp(-2θ²/θ0²) vs spectre angulaire exp(-2 sin²θ/θ0²) à θ = θ0 : "
    f"rapport {ratio_sin:.5f} (écart {100 * (ratio_sin - 1):+.2f} %)")

# ----------------------------------------------------------------------------
# 2. Positions de fibre optimales (deux critères)
# ----------------------------------------------------------------------------
say("\n2. POSITION DE LA FIBRE (defocus par rapport au foyer objet paraxial du collimateur)")
d_div, v_div = chain.best_defocus(target="chain")
d_opd, v_opd = chain.best_defocus(target="chain_opd")
say(f"   min θ_rms (puissance)   : defocus = {d_div:+.4f} mm, θ_rms = {v_div * 1e6:.2f} µrad")
say(f"   min OPD RMS (puissance) : defocus = {d_opd:+.4f} mm, OPD RMS = {v_opd / LAM:.4f} λ")

# ----------------------------------------------------------------------------
# 3. Bilan de puissance surface par surface + convergence
# ----------------------------------------------------------------------------
c = chain.build_chain(d_div)
rays = c["full"].trace(src.generate_rays())
rep = surface_power_report(c["full"], rays, src)
say(f"\n3. BILAN DE PUISSANCE PAR SURFACE (defocus {d_div:+.4f} mm, {src.n_rays} rayons, "
    f"P0 = 1 ; puissances = sommes de ray.power)")
for line in surface_power_table(rep).splitlines():
    say("   " + line)
acn = [e for e in rep if e.element.startswith("ACN")]
p_lost_acn = sum(e.p_lost for e in acn)
say(f"   ACN127 : perte = {100 * p_lost_acn / acn[0].p_incident:.3f} % de la puissance incidente "
    f"(S{acn[0].index}: {100 * acn[0].p_lost:.3f} %, S{acn[1].index}: {100 * acn[1].p_lost:.3f} %, "
    f"S{acn[2].index}: {100 * acn[2].p_lost:.3f} %) ; transmission totale = {weighted_transmission(rays):.5f}")

say("\n   Convergence (transmission totale, perte ACN127) :")
say(f"   {'N':>6}{'T (angle)':>12}{'perte ACN':>11}{'T (puiss.)':>12}{'perte ACN':>11}")
conv = []
for n in (301, 601, 1201, 2401, 4801, 9601):
    row = [n]
    for samp in ("angle", "power"):
        s_ = chain.make_source(n_rays=n)
        s_.sampling = samp
        r_ = c["full"].trace(s_.generate_rays())
        rp = surface_power_report(c["full"], r_, s_)
        row += [weighted_transmission(r_), sum(e.p_lost for e in rp if e.element.startswith("ACN"))]
    conv.append(row)
    say(f"   {n:>6}{row[1]:>12.5f}{100 * row[2]:>10.3f}%{row[3]:>12.5f}{100 * row[4]:>10.3f}%")
conv = np.array(conv)

# ----------------------------------------------------------------------------
# 4. Faisceau de sortie
# ----------------------------------------------------------------------------
say("\n4. FAISCEAU EN SORTIE (après le dernier sommet de L2) — trois méthodes distinctes")
say("   A = rayons marqueurs ±θ0 / extrêmes ; B = moments (ISO, puissance) ; C = ajustement gaussien")
say(f"   {'Δz':>7}{'A: D1/e²':>10}{'A: 2r_max':>10}{'B: D4σ':>9}{'B: <x>':>10}{'B: skew':>9}"
    f"{'C: D fit':>10}{'C: résidu':>10}{'σθx':>9}{'<θ_r>':>9}")
z0 = c["l2"].z_back
planes = [1.0, 100.0, 500.0, 1000.0, 2000.0, 5000.0]
stats = []
for dz in planes:
    b = beam_stats(rays, z0 + dz, src)
    stats.append(b)
    say(f"   {dz:>7.0f}{b.d_1e2_markers:>10.3f}{b.r_max_pos + b.r_max_neg:>10.3f}{b.d4sigma:>9.3f}"
        f"{b.centroid:>10.1e}{b.skewness:>9.1e}{b.d_fit:>10.3f}{100 * b.fit_residual:>9.2f}%"
        f"{b.sigma_theta_x * 1e6:>8.1f}µ{b.mean_radial_angle * 1e6:>8.1f}µ")
w_fit = stats[0].d_fit / 2
s_diff = LAM / (2 * np.pi * w_fit)
say(f"   σθx = divergence géométrique (2nd moment ISO par axe) ; <θ_r> = angle radial moyen (>0 divergent).")
say(f"   Comparaison : divergence de DIFFRACTION d'une gaussienne de w = {w_fit:.3f} mm : "
    f"σθx = λ/(2π w) = {s_diff * 1e6:.1f} µrad ; z_R = π w²/λ = {np.pi * w_fit**2 / LAM / 1e3:.0f} m")
say("   Asymétrie : système centré de révolution, éventail symétrique -> <x> et skewness nuls à l'arrondi"
    " près ; une asymétrie réelle (décentrement, tilt) n'est pas modélisée.")

# ----------------------------------------------------------------------------
# 5. Front d'onde
# ----------------------------------------------------------------------------
say("\n5. FRONT D'ONDE GÉOMÉTRIQUE (référence plane, sortie collimatée)")
wf_div = wavefront(rays, LAM, "plane", z_ref=z0 + 1.0)
say(wf_div.summary(f"[fibre à min θ_rms, {d_div:+.4f} mm]"))
c_opd = chain.build_chain(d_opd)
rays_opd = c_opd["full"].trace(src.generate_rays())
wf_opd = wavefront(rays_opd, LAM, "plane", z_ref=c_opd["l2"].z_back + 1.0)
say(wf_opd.summary(f"[fibre à min OPD RMS, {d_opd:+.4f} mm]"))
v = wf_opd.validity()
say(f"   validité : max|Δφ| voisins = {v['max |Δφ| voisins (rad)']:.3f} rad, "
    f"σ_OPD = {v['σ_OPD / λ (poids amplitude)']:.4f} λ (Maréchal exige < 0,071 λ)")

say("\n   Dépendance au plan de référence (fibre à min OPD) :")
for dz in (1.0, 100.0, 1000.0):
    w_ = wavefront(rays_opd, LAM, "plane", z_ref=c_opd["l2"].z_back + dz)
    say(f"   z_ref = +{dz:>6.0f} mm : OPD RMS = {w_.rms('power') / LAM:.4f} λ, "
        f"hors défocus = {w_.rms_defocus_removed('power') / LAM:.4f} λ, Strehl direct = {w_.strehl_direct():.4f}")

say("\n   Contribution du collimateur seul (référence plane 1 mm après lui) :")
coll_rays = c_opd["collimator"].trace(src.generate_rays())
wf_c = wavefront(coll_rays, LAM, "plane", z_ref=c_opd["coll"].z_back + 1.0)
say(f"   OPD RMS = {wf_c.rms('power') / LAM:.4f} λ, hors défocus = {wf_c.rms_defocus_removed('power') / LAM:.4f} λ,"
    f" Strehl direct = {wf_c.strehl_direct():.4f} (faisceau non tronqué : T = {weighted_transmission(coll_rays):.6f})")

# ----------------------------------------------------------------------------
# Figures
# ----------------------------------------------------------------------------
fig1, (a, b) = plt.subplots(1, 2, figsize=(14, 4.8))
idx = [e.index for e in rep]
a.bar(idx, [100 * e.p_lost for e in rep], color=["tab:red" if e.p_lost > 1e-4 else "0.6" for e in rep])
for e in rep:
    a.annotate(f"{100 * e.t_fraction:.2f} %", (e.index, 100 * e.p_lost), ha="center",
               textcoords="offset points", xytext=(0, 3), fontsize=7)
a.set_xticks(idx)
a.set_xticklabels([f"S{e.index}\n{e.element[:7]}" for e in rep], fontsize=7)
a.set_ylabel("puissance perdue [% de P0]")
a.set_title("Pertes par surface (étiquette : transmission de la surface)")
a.grid(alpha=0.3, axis="y")
b.semilogx(conv[:, 0], 100 * (1 - conv[:, 1]), "o-", label="échantillonnage uniforme en angle")
b.semilogx(conv[:, 0], 100 * (1 - conv[:, 3]), "s-", label="échantillonnage à puissance égale")
b.set_xlabel("nombre de rayons")
b.set_ylabel("perte totale [%]")
b.set_title("Convergence du clipping (chaîne réelle)")
b.legend(fontsize=8)
b.grid(alpha=0.3, which="both")
fig1.tight_layout()
fig1.savefig(os.path.join(HERE, "v21_fig1_power.png"), dpi=120)

fig2, ax = plt.subplots(figsize=(10, 4.8))
zz = np.linspace(1.0, 5000.0, 60)
bs = [beam_stats(rays, z0 + dz, src) for dz in zz]
ax.plot(zz, [x.d_1e2_markers for x in bs], "-", color="tab:red", label="A : marqueurs ±θ0 (D 1/e² géométrique)")
ax.plot(zz, [x.r_max_pos + x.r_max_neg for x in bs], ":", color="0.4", label="A : enveloppe 2 r_max")
ax.plot(zz, [x.d4sigma for x in bs], "--", color="tab:blue", label="B : D4σ ISO (puissance)")
ax.plot(zz, [x.d_fit for x in bs], "-.", color="tab:green", label="C : ajustement gaussien 2w")
ax.set_xlabel("distance après L2 [mm]")
ax.set_ylabel("diamètre [mm]")
ax.set_title(f"Faisceau de sortie (fibre {d_div:+.3f} mm) — trois définitions non équivalentes ; diffraction non incluse")
ax.legend(fontsize=8)
ax.grid(alpha=0.3)
fig2.tight_layout()
fig2.savefig(os.path.join(HERE, "v21_fig2_output_beam.png"), dpi=120)

fig3, axs = plt.subplots(1, 3, figsize=(15, 4.6))
for wf_, lab, col in ((wf_div, f"min θ_rms ({d_div:+.3f} mm)", "tab:purple"),
                      (wf_opd, f"min OPD ({d_opd:+.3f} mm)", "tab:orange")):
    o = np.argsort(wf_.x)
    axs[0].plot(wf_.x[o], wf_.opd[o] / LAM, "-", color=col, label=lab)
    axs[1].plot(wf_.x[o], wf_.defocus_fit()[2][o] / LAM, "-", color=col, label=lab)
axs[0].set_title("OPD / plan (défocus inclus)")
axs[1].set_title("OPD hors défocus (c0 + c2 r² retiré)")
for a_ in axs[:2]:
    a_.set_xlabel("hauteur sur la référence [mm]")
    a_.set_ylabel("OPD [λ]")
    a_.grid(alpha=0.3)
    a_.legend(fontsize=8)
o = np.argsort(wf_opd.x)
I = wf_opd.power / wf_opd.area
axs[2].plot(wf_opd.x[o], I[o] / I.max(), color="tab:red", label="intensité (P/dA)")
axs[2].plot(wf_opd.x[o], np.sqrt(I[o] / I.max()), color="tab:blue", label="amplitude √I (poids du Strehl)")
axs[2].set_xlabel("hauteur sur la référence [mm]")
axs[2].set_title("Éclairement de la pupille (bord dur : troncature ACN127)")
axs[2].legend(fontsize=8)
axs[2].grid(alpha=0.3)
fig3.tight_layout()
fig3.savefig(os.path.join(HERE, "v21_fig3_wavefront.png"), dpi=120)

with open(os.path.join(HERE, "v21_report.txt"), "w") as fh:
    fh.write("\n".join(OUT) + "\n")
print("figures et rapport écrits dans", HERE)
