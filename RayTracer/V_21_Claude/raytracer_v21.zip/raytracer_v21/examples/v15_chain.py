"""V1.5 : validation géométrique de la chaîne fibre -> collimateur -> beam expander.

    python examples/v15_chain.py

Produit 4 figures (PNG à côté de ce script) et un rapport texte v15_report.txt.
Si examples/lens_data.py n'est pas rempli, la chaîne est simulée avec des
lentilles de SUBSTITUTION (voir chain.py) et toutes les sorties le signalent.
"""

import os
import sys
import warnings

import numpy as np
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import chain  # noqa: E402  (ajoute aussi le package au chemin)
import lens_data  # noqa: E402
from optical_sim import (CollimatedSource, paraxial, beam_profile, clipping_report,  # noqa: E402
                         gaussian_transmission, output_divergence, restart_rays,
                         plot_rays, plot_beam_profile, plot_divergence)

warnings.simplefilter("ignore")          # avertissements résumés dans le rapport
CFG = chain.CONFIG
STANDIN = chain.using_standins()
TAG = "  [LENTILLES DE SUBSTITUTION — PAS les Thorlabs]" if STANDIN else ""
REPORT = []


def say(line=""):
    print(line)
    REPORT.append(line)


def savefig(fig, name):
    if STANDIN:
        fig.text(0.5, 0.995, "LENTILLES DE SUBSTITUTION (singulets fictifs, focales nominales) — "
                 "remplir examples/lens_data.py pour la vraie chaîne",
                 ha="center", va="top", color="crimson", fontsize=10, fontweight="bold")
    out = os.path.join(HERE, name)
    fig.savefig(out, dpi=120)
    say(f"figure : {out}")


src = chain.make_source()
say("=" * 78)
say(f"V1.5 — chaîne fibre → collimateur → beam expander à {CFG['wavelength'] * 1e6:.0f} nm{TAG}")
say("=" * 78)
if STANDIN:
    say("Données constructeur manquantes : " + "; ".join(
        f"{k} ({', '.join(v)})" for k, v in lens_data.all_missing().items()))
say(f"Source : MFD = {CFG['mfd'] * 1e3:.2f} µm, w0 = {src.w0 * 1e3:.2f} µm, "
    f"theta0 = λ/(π w0) = {src.theta0 * 1e3:.2f} mrad ({np.degrees(src.theta0):.2f}°), "
    f"z_R(fibre) = {src.rayleigh_range * 1e3:.1f} µm")
say(f"        {src.n_rays} rayons dans ±{src.theta_factor:g} θ0, poids gaussiens"
    f" (NA nominale non utilisée : {CFG['na_nominal']})")

# ============================================================================
# 1. COLLIMATEUR
# ============================================================================
say("\n--- 1. Collimateur " + CFG["collimator"] + " ---")
_, coll0 = chain.build_collimator(0.0)
cc = paraxial.cardinal(coll0.surfaces)
say(f"EFL = {cc['EFL']:.4f} mm, FFD (fibre → 1er sommet au foyer) = {cc['FFD']:.4f} mm, "
    f"ouverture claire Ø{2 * coll0.semi_aperture:.2f} mm")
say(f"Diamètre collimaté paraxial attendu : 2 f θ0 = 4 λ f / (π MFD) = {2 * cc['EFL'] * src.theta0:.3f} mm"
    f"  (cible {CFG['target_d_collimated']} mm → f requise {CFG['target_d_collimated'] / (2 * src.theta0):.2f} mm)")

d_best, rms_best = chain.best_defocus()
say(f"Meilleure collimation (θ_rms min.) : defocus = {d_best:+.4f} mm, θ_rms = {rms_best * 1e3:.4f} mrad")

defocus_list = sorted(set(np.round([d_best - 0.2, d_best - 0.1, d_best, d_best + 0.1, d_best + 0.2, 0.0], 4)))
planes = [1.0, 100.0, 500.0, 1000.0]          # mm après le dernier sommet du collimateur
say(f"\n{'defocus':>9}{'θ_rms':>9}{'θ(θ0) exact':>13}{'θ(θ0) parax':>13}"
    + "".join(f"{'D@+' + str(int(p)):>10}" for p in planes) + f"{'T':>9}")
say(f"{'[mm]':>9}{'[mrad]':>9}{'[mrad]':>13}{'[mrad]':>13}" + "".join(f"{'[mm]':>10}" for _ in planes) + f"{'':>9}")
coll_scan = {}
for d in defocus_list:
    div, rays, sysc, lens = chain.collimator_divergence(d, src)
    s = lens.z_front - 0.0                      # distance fibre -> 1er sommet
    M = paraxial.system_matrix(lens.surfaces)
    u_par = M[1, 0] * (s * src.theta0) + M[1, 1] * src.theta0
    prof = beam_profile(rays, src, [lens.z_back + p for p in planes])
    rep = clipping_report(sysc, rays, src)
    coll_scan[d] = (div, prof, rep, rays, sysc, lens)
    say(f"{d:>+9.3f}{div.theta_rms * 1e3:>9.4f}{div.theta_1e2 * 1e3:>13.4f}{u_par * 1e3:>13.4f}"
        + "".join(f"{x:>10.3f}" for x in prof.d_1e2) + f"{rep.transmitted:>9.5f}")
say("θ(θ0) = angle de sortie du rayon lancé à θ0 ; D = diamètre 1/e² (rayons ±θ0) ; "
    "T = transmission (poids radiaux).")

# ============================================================================
# 2. BEAM EXPANDER
# ============================================================================
say(f"\n--- 2. Beam expander de Galilée {CFG['l1']} → {CFG['l2']} ---")
exp_sys, l1, l2, gap = chain.build_expander(0.0)
ef = chain.expander_figures(exp_sys, l1, l2, gap)
say(f"f1 = {ef['f1']:.4f} mm, f2 = {ef['f2']:.4f} mm  (orientation : L1 flip={CFG['flip_l1']}, L2 flip={CFG['flip_l2']})")
say(f"Séparation afocale SOMMET-SOMMET (L1 dernier sommet → L2 1er sommet) = {gap:.4f} mm")
say(f"Séparation des plans principaux H'1 → H2 = {ef['principal_plane_separation']:.4f} mm "
    f"(= f1 + f2 = {ef['f1'] + ef['f2']:.4f})")
say(f"Matrice : A = {ef['A']:.6f}, C = {ef['C']:.2e} mm⁻¹, D = {ef['D']:.6f}  "
    f"→ grandissement transverse G = A = {ef['G_paraxial']:.6f}, angulaire = D = {ef['D']:.6f}")

hs = np.linspace(-l1.semi_aperture * 0.999, l1.semi_aperture * 0.999, 201)
src_col = CollimatedSource(z=-20.0, half_width=hs[-1], n_rays=len(hs))
rays_exp = exp_sys.trace(src_col.generate_rays())
alive = [r for r in rays_exp if r.alive]
x_in = np.array([r.history[0].position[0] for r in alive])
th_out = np.array([r.theta for r in alive])
x_out = np.array([r.x for r in alive])
small = np.argsort(np.abs(x_in))[2]
say(f"Tracé exact, rayons // axe : G exact (h = {abs(x_in[small]):.3f} mm) = {x_out[small] / x_in[small]:.6f}")
for h in (1.0, 2.125, 4.25, 6.0):
    i = np.argmin(np.abs(x_in - h))
    say(f"   h_in = {x_in[i]:6.3f} mm → h_out = {x_out[i]:7.3f} mm, angle de sortie = {th_out[i] * 1e6:9.2f} µrad")
w_in = CFG["target_d_collimated"] / 2
say(f"Faisceau entrant Ø{2 * w_in} mm (1/e²) → sortant Ø{2 * w_in * ef['G_paraxial']:.3f} mm (paraxial)")
for el, w in ((l1, w_in), (l2, w_in * ef["G_paraxial"])):
    say(f"   {el.name:<34} ouverture claire Ø{2 * el.semi_aperture:6.2f} mm, w = {w:5.3f} mm, "
        f"a/w = {el.semi_aperture / w:4.2f}, T gaussien centré = {gaussian_transmission(el.semi_aperture, w):.5f}")

# ============================================================================
# 3. CHAÎNE COMPLÈTE
# ============================================================================
say("\n--- 3. Chaîne complète (fibre en z = 0, collimateur → L1 : "
    f"{CFG['gap_coll_l1']} mm) ---")
chain_runs = {}
for d in (d_best - 0.2, d_best, d_best + 0.2):
    c = chain.build_chain(d)
    rays = c["full"].trace(src.generate_rays())
    z_before = c["l1"].z_front - 1.0
    z_after = c["l2"].z_back + 1.0
    prof = beam_profile(rays, src, [z_before, z_after, z_after + 1000.0])
    rep = clipping_report(c["full"], rays, src)
    div_c = output_divergence(rays, c["coll"].z_back + 1.0, src)
    div_f = output_divergence(rays, z_after, src)
    chain_runs[d] = (c, rays, prof, rep, div_f)
    say(f"\ndefocus {d:+.3f} mm : D avant L1 = {prof.d_1e2[0]:.3f} mm, D après L2 = {prof.d_1e2[1]:.3f} mm, "
        f"D à +1 m = {prof.d_1e2[2]:.3f} mm")
    say(f"   θ_rms après collimateur = {div_c.theta_rms * 1e3:.4f} mrad, après expander = "
        f"{div_f.theta_rms * 1e3:.4f} mrad (rapport {div_c.theta_rms / div_f.theta_rms:.3f} ; "
        f"= G = {ef['G_paraxial']:.3f} seulement si l'expander est sans aberration)")
    for line in rep.table().splitlines():
        say("   " + line)

d_chain, rms_chain = chain.best_defocus(target="chain")
say(f"\nMeilleure position de fibre pour la CHAÎNE (θ_rms final min.) : defocus = {d_chain:+.4f} mm, "
    f"θ_rms = {rms_chain * 1e3:.4f} mrad (vs {d_best:+.4f} mm pour le collimateur seul)")

# Cohérence tracé séparé / complet (meilleure position)
c, rays_full, *_ = chain_runs[d_best]
coll_rays = c["collimator"].trace(src.generate_rays())
exp_rays = c["expander"].trace(restart_rays(coll_rays))
by_parent = {id(r.parent): r for r in exp_rays}
dmax = 0.0
for rf, rc in zip(rays_full, coll_rays):
    if rc.alive and by_parent[id(rc)].alive and rf.alive:
        dmax = max(dmax, np.max(np.abs(rf.direction - by_parent[id(rc)].direction)))
say(f"\nCohérence sous-systèmes séparés / chaîne complète : écart max des directions = {dmax:.1e}")

# ============================================================================
# FIGURES
# ============================================================================
c, rays_full, prof_best, rep_best, div_best = chain_runs[d_best]
step = max(1, len(rays_full) // 60)
sub = lambda rays: [r for i, r in enumerate(rays) if i % step == 0]

# --- Figure 1 : schéma de la chaîne + diamètre(z)
fig1, (a1, a2) = plt.subplots(2, 1, figsize=(14, 8.5), height_ratios=[1.3, 1])
zf = c["l2"].z_back + 60
rays_plot = chain.build_chain(d_best)["full"].trace(sub(src.generate_rays()), z_final=zf)
plot_rays(rays_plot, c["full"], ax=a1, source=src, equal_aspect=False, legend_loc="lower right",
          title=f"1. Chaîne complète (defocus fibre {d_best:+.3f} mm){TAG}")
zs = np.linspace(0.5, zf, 600)
prof_z = beam_profile(rays_full, src, zs)
plot_beam_profile(prof_z, ax=a2, system=c["full"],
                  title="5. Diamètre du faisceau en fonction de z (traits noirs : ouvertures claires)")
a2.axhline(CFG["target_d_collimated"], color="tab:green", ls="--", lw=0.8)
a2.axhline(2 * CFG["target_d_collimated"], color="tab:green", ls="--", lw=0.8)
a2.annotate("8,5 mm", (zs[0], CFG["target_d_collimated"]), fontsize=7, color="tab:green")
a2.annotate("17 mm", (zs[0], 2 * CFG["target_d_collimated"]), fontsize=7, color="tab:green")
fig1.tight_layout(rect=(0, 0, 1, 0.97))
savefig(fig1, "v15_fig1_chain_and_diameter.png")

# --- Figure 2 : collimateur
fig2 = plt.figure(figsize=(14, 9))
gs2 = fig2.add_gridspec(2, 2, height_ratios=[1.2, 1])
_, rays_c, _, _ = chain.collimator_divergence(d_best, chain.make_source(n_rays=61))
sysc, lensc = chain.build_collimator(d_best)
rays_c = sysc.trace(chain.make_source(n_rays=61).generate_rays(), z_final=lensc.z_back + 40)
plot_rays(rays_c, sysc, ax=fig2.add_subplot(gs2[0, :]), source=src, equal_aspect=True,
          legend_loc="lower right", title=f"2. Collimateur {CFG['collimator']} (defocus {d_best:+.3f} mm){TAG}")
ax = fig2.add_subplot(gs2[1, 0])
dd = np.linspace(d_best - 0.3, d_best + 0.3, 25)
rms_d, t1_d, par_d = [], [], []
src_s = chain.make_source(n_rays=401)
for d in dd:
    div, _, _, lens = chain.collimator_divergence(d, src_s)
    M = paraxial.system_matrix(lens.surfaces)
    rms_d.append(div.theta_rms * 1e3)
    t1_d.append(div.theta_1e2 * 1e3)
    par_d.append((M[1, 0] * lens.z_front * src.theta0 + M[1, 1] * src.theta0) * 1e3)
ax.plot(dd, rms_d, "o-", ms=3, label="θ_rms (exact, pondéré)")
ax.plot(dd, t1_d, "s-", ms=3, label="angle du rayon θ0 (exact)")
ax.plot(dd, par_d, "--", label="angle du rayon θ0 (paraxial)")
ax.axvline(d_best, color="0.5", ls=":")
ax.axhline(0, color="k", lw=0.5)
ax.set_xlabel("defocus fibre [mm]  (>0 : fibre plus loin que le foyer)")
ax.set_ylabel("angle de sortie [mrad]")
ax.set_title("Divergence en sortie du collimateur")
ax.legend(fontsize=8)
ax.grid(alpha=0.3)
ax = fig2.add_subplot(gs2[1, 1])
for d in defocus_list:
    div, prof, rep, rays, sysc_, lens = coll_scan[d]
    ax.plot(planes, prof.d_1e2, "o-", ms=3, label=f"{d:+.3f} mm")
ax.axhline(CFG["target_d_collimated"], color="tab:green", ls="--", lw=0.8, label="cible 8,5 mm")
ax.set_xscale("log")
ax.set_xlabel("distance après le collimateur [mm]")
ax.set_ylabel("diamètre 1/e² [mm]")
ax.set_title("Diamètre selon la position de la fibre")
ax.legend(fontsize=7, title="defocus", title_fontsize=7)
ax.grid(alpha=0.3)
fig2.tight_layout(rect=(0, 0, 1, 0.97))
savefig(fig2, "v15_fig2_collimator.png")

# --- Figure 3 : beam expander
fig3 = plt.figure(figsize=(14, 9))
gs3 = fig3.add_gridspec(2, 2, height_ratios=[1.2, 1])
src_plot = CollimatedSource(z=-15.0, half_width=w_in, n_rays=17)
rays_e = exp_sys.trace(src_plot.generate_rays(), z_final=l2.z_back + 40)
plot_rays(rays_e, exp_sys, ax=fig3.add_subplot(gs3[0, :]), equal_aspect=True, legend_loc="lower right",
          title=f"3. Beam expander, faisceau collimaté Ø{2 * w_in} mm : séparation sommets {gap:.3f} mm, G = {ef['G_paraxial']:.4f}{TAG}")
ax = fig3.add_subplot(gs3[1, 0])
order = np.argsort(x_in)
ax.plot(x_in[order], th_out[order] * 1e6, "-", color="tab:purple")
ax.axvspan(-w_in, w_in, color="tab:green", alpha=0.08, label="faisceau 8,5 mm (1/e²)")
ax.set_xlabel("hauteur d'entrée (rayons // axe) [mm]")
ax.set_ylabel("angle de sortie [µrad]")
ax.set_title("6a. Expander seul : angle de sortie vs hauteur (paraxial : 0)")
ax.legend(fontsize=8)
ax.grid(alpha=0.3)
plot_divergence(div_best, ax=fig3.add_subplot(gs3[1, 1]), angle_unit="mrad",
                title=f"6b. Chaîne complète : angle de sortie vs hauteur après L2 "
                      f"(θ_rms = {div_best.theta_rms * 1e3:.3f} mrad)")
fig3.tight_layout(rect=(0, 0, 1, 0.97))
savefig(fig3, "v15_fig3_expander.png")

# --- Figure 4 : chaîne complète pour plusieurs positions de fibre
fig4, axes = plt.subplots(3, 1, figsize=(14, 11))
for ax, d in zip(axes, sorted(chain_runs)):
    c_d, rays_d, prof_d, rep_d, div_d = chain_runs[d]
    rp = chain.build_chain(d)["full"].trace(sub(src.generate_rays()), z_final=c_d["l2"].z_back + 150)
    plot_rays(rp, c_d["full"], ax=ax, source=src, equal_aspect=False, show_legend=(d == min(chain_runs)),
              legend_loc="lower right", label_surfaces=False,
              title=f"4. defocus {d:+.3f} mm : D après L2 = {prof_d.d_1e2[1]:.2f} mm, "
                    f"θ_rms = {div_d.theta_rms * 1e3:.3f} mrad, T = {rep_d.transmitted:.4f}")
fig4.tight_layout(rect=(0, 0, 1, 0.97))
savefig(fig4, "v15_fig4_full_chain_defocus.png")

with open(os.path.join(HERE, "v15_report.txt"), "w") as fh:
    fh.write("\n".join(REPORT) + "\n")
print(f"rapport : {os.path.join(HERE, 'v15_report.txt')}")
