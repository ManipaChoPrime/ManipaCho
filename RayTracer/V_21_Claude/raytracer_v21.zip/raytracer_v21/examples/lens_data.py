"""Prescriptions constructeur des doublets Thorlabs du montage (données centralisées).

Origine des valeurs
-------------------
* Rayons, épaisseurs, verres, diamètres, EFL/BFL nominales, ouvertures claires :
  tableaux et dessins techniques Thorlabs, transmis par l'utilisateur.
  Recoupement indépendant (base 3doptix, qui reprend le catalogue Thorlabs) :
  AC254-040-B-ML et ACN127-030-B identiques (rayons, épaisseurs, verres,
  épaisseur au bord) ; AC254-060-B non recoupé (page inaccessible).
* Indices à 1030 nm, ~20 °C : équations de dispersion SCHOTT, valeurs fournies
  par l'utilisateur (table GLASS_INDEX_1030). Les indices sont affectés à
  chaque lentille PAR NOM DE VERRE, pour éviter toute permutation.

Convention (identique au moteur) : la lumière arrive par R1 dans l'ordre de
la fiche :  air -> R1 -> verre 1 (tc1) -> R2 (interface collée) -> verre 2 (tc2)
-> R3 -> air. Rayons en convention "centre de courbure" (R > 0 : centre vers +z),
qui est celle des fiches Thorlabs/Zemax. Le retournement passe uniquement par
le paramètre `flip` de Lens. Unités : mm.

Ouvertures : `clear_aperture` est la BORNE INFÉRIEURE garantie par la fiche
("supérieure à ...") : c'est la valeur conservatrice utilisée pour le clipping.
Le diamètre mécanique `diameter` n'est jamais utilisé comme ouverture quand
clear_aperture est renseignée.
"""

import warnings

from optical_sim import Lens


# Indices de réfraction à 1030 nm (SCHOTT, ~20 °C) — fournis par l'utilisateur.
GLASS_INDEX_1030 = {
    "N-LAK22": 1.637961,
    "N-BAF10": 1.654584,
    "N-SF6HT": 1.774338,
}
INDEX_WAVELENGTH_NM = 1030.0

SOURCES_COMMON = [
    "Thorlabs, tableau de prescription et dessin technique de la référence (fournis par l'utilisateur)",
    "SCHOTT, équations de dispersion (indices calculés à 1030 nm par l'utilisateur)",
]


def _lens(ref, R1, R2, R3, tc1, tc2, glass1, glass2, diameter, clear_aperture,
          efl_nominal, bfl_nominal, edge_thickness_ref=None, extra_sources=()):
    return dict(
        reference=ref,
        R1=R1, R2=R2, R3=R3,                     # mm, ordre de la fiche, lumière entrant par R1
        tc1=tc1, tc2=tc2,                        # mm, épaisseurs au centre des verres 1 et 2
        glass1=glass1, glass2=glass2,
        n1=GLASS_INDEX_1030[glass1],             # indice du verre 1 à wavelength_nm
        n2=GLASS_INDEX_1030[glass2],             # indice du verre 2 à wavelength_nm
        wavelength_nm=INDEX_WAVELENGTH_NM,
        diameter=diameter,                       # mm, diamètre mécanique
        clear_aperture=clear_aperture,           # mm, borne inférieure de l'ouverture claire
        clear_aperture_is_lower_bound=True,
        efl_nominal=efl_nominal,                 # mm (contrôle, non imposé au modèle)
        bfl_nominal=bfl_nominal,                 # mm (contrôle, non imposé au modèle)
        spec_wavelength_nm=None,                 # longueur d'onde des valeurs nominales : non fournie
        edge_thickness_ref=edge_thickness_ref,   # mm, épaisseur totale au bord (dessin), contrôle
        efl_rel_tolerance=0.02,                  # tolérance : valeurs nominales à une autre λ
        bfl_abs_tolerance=1.0,                   # mm
        sources=list(SOURCES_COMMON) + list(extra_sources),
    )


LENSES = {
    "AC254-040-B-ML": _lens(
        "AC254-040-B-ML", R1=26.12, R2=-21.28, R3=-137.09, tc1=10.0, tc2=2.5,
        glass1="N-BAF10", glass2="N-SF6HT", diameter=25.4, clear_aperture=22.86,
        efl_nominal=40.0, bfl_nominal=32.8, edge_thickness_ref=8.6,
        extra_sources=["3doptix, catalogue Thorlabs AC254-040-B-ML (recoupement)"]),
    "ACN127-030-B": _lens(
        "ACN127-030-B", R1=-19.25, R2=18.41, R3=106.41, tc1=1.5, tc2=2.5,
        glass1="N-LAK22", glass2="N-SF6HT", diameter=12.7, clear_aperture=11.43,
        efl_nominal=-30.0, bfl_nominal=-32.0, edge_thickness_ref=5.3,
        extra_sources=["3doptix, catalogue Thorlabs ACN127-030-B (recoupement)"]),
    "AC254-060-B": _lens(
        "AC254-060-B", R1=39.48, R2=-33.00, R3=-165.20, tc1=6.0, tc2=1.7,
        glass1="N-LAK22", glass2="N-SF6HT", diameter=25.4, clear_aperture=22.86,
        efl_nominal=60.0, bfl_nominal=55.8),
}

REQUIRED = ("R1", "R2", "R3", "tc1", "tc2", "n1", "n2", "wavelength_nm")


def missing_fields(data) -> list:
    if isinstance(data, str):
        data = LENSES[data]
    return [k for k in REQUIRED if data.get(k) is None]


def all_missing() -> dict:
    return {k: missing_fields(v) for k, v in LENSES.items() if missing_fields(v)}


def build_lens(data, flip: bool = False, z_front: float = 0.0, name: str = None,
               expected_wavelength_nm: float = None) -> Lens:
    """Instancie la classe générique Lens à partir d'une entrée de LENSES."""
    key = data if isinstance(data, str) else data.get("reference")
    if isinstance(data, str):
        data = LENSES[key]
    miss = missing_fields(data)
    if miss:
        raise ValueError(f"Données {key or ''} incomplètes, champs manquants : {', '.join(miss)}")
    if expected_wavelength_nm is not None and data["wavelength_nm"] != expected_wavelength_nm:
        warnings.warn(f"{key} : indices donnés à {data['wavelength_nm']} nm, "
                      f"simulation à {expected_wavelength_nm} nm.")
    if data.get("clear_aperture") is None:
        warnings.warn(f"{key} : ouverture claire non renseignée, diamètre mécanique utilisé.")
        aperture = data["diameter"]
    else:
        aperture = data["clear_aperture"]
    return Lens(radii=[data["R1"], data["R2"], data["R3"]],
                thicknesses=[data["tc1"], data["tc2"]],
                n_glasses=[data["n1"], data["n2"]],
                n_before=1.0, aperture=aperture, z_front=z_front,
                name=name or key or "", flip=flip)
