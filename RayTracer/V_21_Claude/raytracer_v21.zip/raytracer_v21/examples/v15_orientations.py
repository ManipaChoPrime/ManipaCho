"""Étude des orientations des trois doublets (paramètre `flip` uniquement).

    python examples/v15_orientations.py

Pour chaque lentille et chaque orientation :
  * EFL, BFD, FFD paraxiales à 1030 nm, comparées aux valeurs nominales ;
  * LSA pour un faisceau collimaté ENTRANT (côté -z), à la hauteur utile ;
  * dispersion angulaire et clipping DANS LE RÔLE de la lentille :
      - collimateur : source fibrée gaussienne, fibre à la position de
        meilleure collimation, θ_rms en sortie et transmission ;
      - L1, L2 : faisceau collimaté gaussien Ø8,5 mm (1/e²) dans le beam
        expander, θ_rms en sortie et transmission, pour les 4 combinaisons.
Puis les 8 combinaisons de la chaîne complète (fibre à la meilleure position
pour CHAQUE combinaison).

flip=False : orientation du dessin constructeur (la lumière rencontre R1 en
premier). Rappel : utiliser une lentille dans l'orientation X avec la lumière
allant de la fibre vers le faisceau collimaté revient, par retour inverse de
la lumière, à l'utiliser dans l'orientation opposée pour focaliser un
faisceau collimaté. La LSA "collimaté entrant" de l'orientation opposée est
donc celle qui renseigne sur le collimateur.
"""

import itertools
import os
import sys
import warnings

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import chain  # noqa: E402
import lens_data  # noqa: E402
from optical_sim import (OpticalSystem, CollimatedSource, paraxial, focus_analysis,  # noqa: E402
                         output_divergence, weighted_transmission, beam_profile)

warnings.simplefilter("ignore")
chain.FORCE_STANDIN = False
OUT = []


def say(s=""):
    print(s)
    OUT.append(s)


def lsa_collimated(lens, h):
    system = OpticalSystem([lens])
    src = CollimatedSource(z=lens.z_front - 10.0, half_width=h, n_rays=81)
    rays = system.trace(src.generate_rays())
    return focus_analysis(rays, system=system, source=src).lsa


def set_flips(fc, f1, f2):
    chain.CONFIG.update(flip_collimator=fc, flip_l1=f1, flip_l2=f2)


ROLE_H = {"AC254-040-B-ML": 4.25, "ACN127-030-B": 4.25, "AC254-060-B": 8.5}

say("=" * 92)
say("Orientations des doublets à 1030 nm (flip=False : orientation du dessin, R1 en premier)")
say("=" * 92)
say(f"{'lentille':<16}{'flip':>6}{'EFL':>10}{'nom.':>7}{'écart':>8}{'BFD':>10}{'nom.':>7}{'écart':>8}"
    f"{'FFD':>10}{'LSA coll. (h)':>18}")
for key, d in lens_data.LENSES.items():
    for flip in (False, True):
        lens = lens_data.build_lens(key, flip=flip)
        c = paraxial.cardinal(lens.surfaces)
        h = ROLE_H[key]
        lsa = lsa_collimated(lens, h)
        say(f"{key:<16}{str(flip):>6}{c['EFL']:>10.4f}{d['efl_nominal']:>7.1f}"
            f"{100 * (c['EFL'] / d['efl_nominal'] - 1):>+7.2f}%{c['BFD']:>10.4f}{d['bfl_nominal']:>7.1f}"
            f"{c['BFD'] - d['bfl_nominal']:>+8.3f}{c['FFD']:>10.4f}{lsa:>+12.4f} ({h:g})")
say("BFD nominale (fiche) comparée à la BFD de l'orientation du dessin (flip=False).")

# --- Collimateur seul -------------------------------------------------------
say("\n--- Collimateur AC254-040-B-ML dans son rôle (fibre gaussienne, meilleure collimation) ---")
src = chain.make_source(n_rays=801)
say(f"{'flip':>6}{'defocus opt.':>14}{'θ_rms':>10}{'D 1/e² @+100':>15}{'T':>10}")
coll_res = {}
for fc in (False, True):
    set_flips(fc, False, True)
    d_best, rms = chain.best_defocus()
    div, rays, sysc, lens = chain.collimator_divergence(d_best, src)
    p = beam_profile(rays, src, [lens.z_back + 100.0])
    T = weighted_transmission(rays, src)
    coll_res[fc] = (d_best, div.theta_rms)
    say(f"{str(fc):>6}{d_best:>+13.4f} {div.theta_rms * 1e3:>8.4f}m{p.d_1e2[0]:>15.3f}{T:>10.5f}")
say("θ_rms en mrad (poids gaussiens) ; defocus en mm par rapport au foyer objet paraxial.")

# --- Beam expander seul -------------------------------------------------------
say("\n--- Beam expander dans son rôle (faisceau collimaté gaussien Ø8,5 mm à 1/e²) ---")
say(f"{'flip L1':>8}{'flip L2':>8}{'gap sommets':>13}{'G':>9}{'θ_rms':>12}{'θ(h=w)':>12}{'D sortie':>10}{'T':>10}")
exp_res = {}
for f1, f2 in itertools.product((False, True), repeat=2):
    set_flips(True, f1, f2)
    exp_sys, l1, l2, gap = chain.build_expander(0.0)
    G = paraxial.system_matrix(exp_sys.surfaces)[0, 0]
    srcc = CollimatedSource(z=-10.0, half_width=l1.semi_aperture * 1.2, n_rays=801, w=4.25)
    rays = exp_sys.trace(srcc.generate_rays())
    div = output_divergence(rays, l2.z_back + 1.0, srcc)
    T = weighted_transmission(rays, srcc)
    x_in = np.array([r.history[0].position[0] for r in rays if r.alive])
    th = np.array([r.theta for r in rays if r.alive])
    xo = np.array([r.x for r in rays if r.alive])
    o = np.argsort(x_in)
    th_w = np.interp(4.25, x_in[o], th[o])
    D_out = np.interp(4.25, x_in[o], xo[o]) - np.interp(-4.25, x_in[o], xo[o])
    exp_res[(f1, f2)] = div.theta_rms
    say(f"{str(f1):>8}{str(f2):>8}{gap:>13.4f}{G:>9.5f}{div.theta_rms * 1e6:>10.2f}µ{th_w * 1e6:>10.2f}µ"
        f"{D_out:>10.3f}{T:>10.5f}")
say("θ en µrad ; gap = séparation sommet-sommet afocale ; D sortie = image du diamètre 1/e² d'entrée.")

# --- Chaîne complète : 8 combinaisons --------------------------------------
say("\n--- Chaîne complète : 8 combinaisons (fibre optimisée pour chacune) ---")
say(f"{'coll':>6}{'L1':>6}{'L2':>6}{'defocus':>10}{'θ_rms final':>13}{'D avant L1':>12}{'D après L2':>12}{'T totale':>10}")
src = chain.make_source(n_rays=801)
results = []
for fc, f1, f2 in itertools.product((False, True), repeat=3):
    set_flips(fc, f1, f2)
    d_best, rms = chain.best_defocus(target="chain")
    div, rays, c = chain.chain_divergence(d_best, src)
    p = beam_profile(rays, src, [c["l1"].z_front - 1.0, c["l2"].z_back + 1.0])
    T = weighted_transmission(rays, src)
    results.append((div.theta_rms, fc, f1, f2, d_best, p.d_1e2[0], p.d_1e2[1], T))
    say(f"{str(fc):>6}{str(f1):>6}{str(f2):>6}{d_best:>+10.4f}{div.theta_rms * 1e3:>11.4f}m"
        f"{p.d_1e2[0]:>12.3f}{p.d_1e2[1]:>12.3f}{T:>10.5f}")
best = min(results)
say(f"\nMeilleure combinaison (θ_rms final minimal) : collimateur flip={best[1]}, L1 flip={best[2]}, "
    f"L2 flip={best[3]} — θ_rms = {best[0] * 1e3:.4f} mrad, T = {best[7]:.5f}")

with open(os.path.join(HERE, "v15_orientations_report.txt"), "w") as fh:
    fh.write("\n".join(OUT) + "\n")
