"""V2.1 : les 8 orientations comparées en divergence ET en front d'onde.

    python examples/v21_orientations.py

Pour chaque combinaison (collimateur, L1, L2) :
  * fibre placée au minimum de θ_rms (puissance)  -> σθx, diamètres, T, OPD, Strehl
  * fibre placée au minimum d'OPD RMS (puissance) -> OPD, Strehl
Question : la configuration optimale en divergence l'est-elle aussi en front d'onde ?
"""

import itertools
import os
import sys
import warnings

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import chain  # noqa: E402
from optical_sim import weighted_transmission, beam_stats, wavefront  # noqa: E402

warnings.simplefilter("ignore")
chain.FORCE_STANDIN = False
LAM = chain.CONFIG["wavelength"]
OUT = []


def say(s=""):
    print(s, flush=True)
    OUT.append(s)


src_opt = chain.make_source(n_rays=401)
src = chain.make_source(n_rays=2401)
rows = []
say(f"{'coll':>5}{'L1':>5}{'L2':>5} |{'d_div':>8}{'σθx':>8}{'D1/e²':>8}{'D4σ':>8}{'Dfit':>8}{'T':>8}"
    f"{'OPD':>8}{'OPD-déf':>8}{'Strehl':>8} |{'d_opd':>8}{'OPD':>8}{'Strehl':>8}{'S-déf':>8}")
say(f"{'':15} |{'mm':>8}{'µrad':>8}{'mm':>8}{'mm':>8}{'mm':>8}{'':>8}{'λ':>8}{'λ':>8}{'':>8} |{'mm':>8}{'λ':>8}{'':>8}{'':>8}")
for fc, f1, f2 in itertools.product((False, True), repeat=3):
    chain.CONFIG.update(flip_collimator=fc, flip_l1=f1, flip_l2=f2)
    d_div, _ = chain.best_defocus(source=src_opt, target="chain")
    d_opd, _ = chain.best_defocus(source=src_opt, target="chain_opd")
    c = chain.build_chain(d_div)
    rays = c["full"].trace(src.generate_rays())
    z_out = c["l2"].z_back + 1.0
    b = beam_stats(rays, z_out, src)
    wf = wavefront(rays, LAM, "plane", z_ref=z_out)
    c2 = chain.build_chain(d_opd)
    rays2 = c2["full"].trace(src.generate_rays())
    wf2 = wavefront(rays2, LAM, "plane", z_ref=c2["l2"].z_back + 1.0)
    v2 = wf2.validity()
    row = dict(cfg=(fc, f1, f2), d_div=d_div, sig=b.sigma_theta_x, d1=b.d_1e2_markers, d4=b.d4sigma,
               dfit=b.d_fit, T=weighted_transmission(rays), opd=wf.rms("power"),
               opd_nd=wf.rms_defocus_removed("power"), S=wf.strehl_direct(),
               d_opd=d_opd, opd2=wf2.rms("power"), S2=wf2.strehl_direct(),
               S2nd=wf2.strehl_direct(wf2.defocus_fit()[2]), valid=v2["direct_ok"])
    rows.append(row)
    say(f"{str(fc)[0]:>5}{str(f1)[0]:>5}{str(f2)[0]:>5} |{d_div:>+8.3f}{b.sigma_theta_x * 1e6:>8.1f}"
        f"{b.d_1e2_markers:>8.3f}{b.d4sigma:>8.3f}{b.d_fit:>8.3f}{row['T']:>8.4f}{row['opd'] / LAM:>8.3f}"
        f"{row['opd_nd'] / LAM:>8.3f}{row['S']:>8.3f} |{d_opd:>+8.3f}{row['opd2'] / LAM:>8.3f}"
        f"{row['S2']:>8.3f}{row['S2nd']:>8.3f}{'' if row['valid'] else '  (Strehl non valide)'}")

say("\nT = True (retournée), F = False (sens du dessin). OPD : RMS pondéré puissance, référence plane"
    " 1 mm après L2 ; OPD-déf : défocus retiré ; Strehl : somme directe (poids amplitude) ;"
    " S-déf : Strehl hors défocus.")
best_div = min(rows, key=lambda r: r["sig"])
best_opd = min(rows, key=lambda r: r["opd2"])
best_S = max(rows, key=lambda r: r["S2"])
fmt = lambda r: "(" + ", ".join("retournée" if x else "dessin" for x in r["cfg"]) + ")"
say(f"\nMeilleure divergence        : {fmt(best_div)}  σθx = {best_div['sig'] * 1e6:.1f} µrad")
say(f"Meilleur OPD RMS            : {fmt(best_opd)}  OPD = {best_opd['opd2'] / LAM:.4f} λ")
say(f"Meilleur Strehl             : {fmt(best_S)}  S = {best_S['S2']:.4f}")
say("Classement par σθx : " + " > ".join(fmt(r) for r in sorted(rows, key=lambda r: r["sig"])[:3]))
say("Classement par OPD : " + " > ".join(fmt(r) for r in sorted(rows, key=lambda r: r["opd2"])[:3]))
say("Classement par S   : " + " > ".join(fmt(r) for r in sorted(rows, key=lambda r: -r["S2"])[:3]))

with open(os.path.join(HERE, "v21_orientations_report.txt"), "w") as fh:
    fh.write("\n".join(OUT) + "\n")
