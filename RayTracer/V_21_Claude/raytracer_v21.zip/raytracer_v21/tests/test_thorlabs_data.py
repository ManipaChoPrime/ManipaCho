"""Cohérence des prescriptions Thorlabs intégrées (examples/lens_data.py).

Vérifie que la construction de Lens respecte exactement la séquence de la fiche
    air -> R1 -> verre 1 (tc1) -> R2 (collée) -> verre 2 (tc2) -> R3 -> air,
l'affectation des indices par matériau, la convention de signe (via l'épaisseur
au bord du dessin), et la comparaison paraxiale aux valeurs nominales.

Exécution :  python tests/test_thorlabs_data.py   (ou  pytest tests/)
"""

import os
import sys
import warnings

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "examples"))
from optical_sim import Lens, OpticalSystem, CollimatedSource, paraxial, output_divergence  # noqa: E402
import lens_data  # noqa: E402
import chain  # noqa: E402

KEYS = list(lens_data.LENSES)


def test_all_prescriptions_complete():
    assert lens_data.all_missing() == {}
    for k, d in lens_data.LENSES.items():
        assert d["reference"] == k
        assert d["wavelength_nm"] == 1030.0
        assert d["sources"]


def test_indices_assigned_by_material_at_1030nm():
    table = {"N-LAK22": 1.637961, "N-BAF10": 1.654584, "N-SF6HT": 1.774338}
    expected_glasses = {"AC254-040-B-ML": ("N-BAF10", "N-SF6HT"),
                        "ACN127-030-B": ("N-LAK22", "N-SF6HT"),
                        "AC254-060-B": ("N-LAK22", "N-SF6HT")}
    for k, (g1, g2) in expected_glasses.items():
        d = lens_data.LENSES[k]
        assert (d["glass1"], d["glass2"]) == (g1, g2)
        assert d["n1"] == table[g1] and d["n2"] == table[g2]


def test_surface_sequence_matches_drawing():
    """Orientation du dessin (flip=False) : R1, R2, R3 dans l'ordre ; tc1 entre
    R1 et R2 dans le verre 1 ; tc2 entre R2 et R3 dans le verre 2 ; R2 sépare
    les deux verres (interface collée) ; air de part et d'autre."""
    for k in KEYS:
        d = lens_data.LENSES[k]
        lens = lens_data.build_lens(k, z_front=7.0)
        s1, s2, s3 = lens.surfaces
        assert (s1.R, s2.R, s3.R) == (d["R1"], d["R2"], d["R3"])
        assert np.isclose(s2.z_vertex - s1.z_vertex, d["tc1"])
        assert np.isclose(s3.z_vertex - s2.z_vertex, d["tc2"])
        assert (s1.n1, s1.n2) == (1.0, d["n1"])
        assert (s2.n1, s2.n2) == (d["n1"], d["n2"])          # interface collée verre 1 | verre 2
        assert (s3.n1, s3.n2) == (d["n2"], 1.0)
        assert all(np.isclose(s.semi_aperture, d["clear_aperture"] / 2) for s in lens.surfaces)
        assert d["clear_aperture"] < d["diameter"]            # ouverture claire ≠ diamètre mécanique


def test_flipped_sequence():
    for k in KEYS:
        d = lens_data.LENSES[k]
        s1, s2, s3 = lens_data.build_lens(k, flip=True).surfaces
        assert (s1.R, s2.R, s3.R) == (-d["R3"], -d["R2"], -d["R1"])
        assert np.isclose(s2.z_vertex - s1.z_vertex, d["tc2"])
        assert (s1.n2, s2.n2, s3.n2) == (d["n2"], d["n1"], 1.0)


def test_edge_thickness_matches_drawing():
    """Épaisseur totale au bord, au diamètre MÉCANIQUE, recalculée depuis les
    flèches des trois surfaces : doit retrouver la cote du dessin. C'est un
    contrôle direct des signes de R1, R2, R3 dans la convention du moteur."""
    for k in KEYS:
        d = lens_data.LENSES[k]
        if d["edge_thickness_ref"] is None:
            continue
        lens = Lens([d["R1"], d["R2"], d["R3"]], [d["tc1"], d["tc2"]], [d["n1"], d["n2"]],
                    aperture=d["diameter"])
        assert abs(sum(lens.edge_thicknesses()) - d["edge_thickness_ref"]) < 0.06, k
        assert all(t > 0 for t in lens.edge_thicknesses())


def test_paraxial_vs_nominal_specs():
    """EFL et BFL (orientation du dessin) à 1030 nm vs valeurs nominales.
    Les nominales sont des contrôles (autre longueur d'onde de référence),
    pas des paramètres imposés : écarts attendus faibles (< 0,5 % sur l'EFL)."""
    for k in KEYS:
        d = lens_data.LENSES[k]
        c = paraxial.cardinal(lens_data.build_lens(k).surfaces)
        assert abs(c["EFL"] / d["efl_nominal"] - 1) < 0.005, (k, c["EFL"])
        assert abs(c["BFD"] - d["bfl_nominal"]) < 0.2, (k, c["BFD"])
        # la BFL nominale correspond bien à l'orientation du dessin, pas à l'orientation retournée
        cf = paraxial.cardinal(lens_data.build_lens(k, flip=True).surfaces)
        assert abs(cf["BFD"] - d["bfl_nominal"]) > 1.0


def test_expander_best_orientation_L1_drawing_L2_flipped():
    """Beam expander, faisceau collimaté gaussien Ø8,5 mm : parmi les 4
    orientations, L1 dans le sens du dessin et L2 retournée minimise θ_rms."""
    chain.FORCE_STANDIN = False
    rms = {}
    for f1 in (False, True):
        for f2 in (False, True):
            chain.CONFIG.update(flip_l1=f1, flip_l2=f2)
            exp_sys, l1, l2, gap = chain.build_expander(0.0)
            src = CollimatedSource(z=-10.0, half_width=l1.semi_aperture * 1.2, n_rays=301, w=4.25)
            rays = exp_sys.trace(src.generate_rays())
            rms[(f1, f2)] = output_divergence(rays, l2.z_back + 1.0, src).theta_rms
    chain.CONFIG.update(flip_l1=False, flip_l2=True)
    assert min(rms, key=rms.get) == (False, True), rms


def test_collimator_flipped_collimates_better():
    chain.FORCE_STANDIN = False
    out = {}
    for fc in (False, True):
        chain.CONFIG["flip_collimator"] = fc
        out[fc] = chain.best_defocus(source=chain.make_source(n_rays=301))[1]
    chain.CONFIG["flip_collimator"] = True
    assert out[True] < out[False] / 5, out


def setup_function(function):
    chain.FORCE_STANDIN = False
    chain.CONFIG.update(flip_collimator=True, flip_l1=False, flip_l2=True)


if __name__ == "__main__":
    warnings.simplefilter("ignore")
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        setup_function(fn)
        fn()
        print(f"OK  {name}")
    print(f"\n{len(tests)} tests réussis.")
