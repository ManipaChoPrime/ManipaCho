"""Tests V2.1 : puissance portée par les rayons, clipping, front d'onde géométrique.

Exécution :  python tests/test_power_wavefront.py   (ou  pytest tests/)
"""

import os
import sys
import warnings

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "examples"))
from optical_sim import (Lens, ThickLens, Aperture, OpticalSystem, Ray, SphericalSurface,  # noqa: E402
                         GaussianFiberSource, CollimatedSource, PointSource, x_at_z,
                         surface_power_report, weighted_transmission, ray_powers, beam_stats,
                         restart_rays, wavefront, gaussian_transmission)
from optical_sim.ray import ALIVE  # noqa: E402
import chain  # noqa: E402

LAM = 1.03e-3


def setup_function(function):
    chain.FORCE_STANDIN = False
    chain.CONFIG.update(flip_collimator=True, flip_l1=False, flip_l2=True)


def _real_chain(n_rays=801, sampling="angle", defocus=-0.18):
    c = chain.build_chain(defocus)
    src = chain.make_source(n_rays=n_rays)
    src.sampling = sampling
    return c, src, c["full"].trace(src.generate_rays())


# ========================================================================== #
# Puissance des rayons
# ========================================================================== #
def test_source_power_normalisation():
    for sampling in ("angle", "power"):
        for P0 in (1.0, 2.5e-3):
            src = GaussianFiberSource(n_rays=1201, total_power=P0, sampling=sampling)
            P = ray_powers(src.generate_rays())
            assert np.all(P >= 0)
            assert abs(P.sum() / P0 - src._fan_fraction()) < 1e-9
            # fraction dans le cône ≈ 1 - exp(-2k²) (paraxial ; sin θ ≈ θ)
            assert abs(src._fan_fraction() - (1 - np.exp(-2 * 3.0**2))) < 1e-6


def test_power_sampling_rays_are_equal_power():
    src = GaussianFiberSource(n_rays=401, sampling="power")
    P = ray_powers(src.generate_rays())
    nz = P[P > 0]
    assert np.ptp(nz) < 1e-15 and len(nz) == 400


def test_weights_constant_through_propagation_and_restart():
    c, src, rays = _real_chain(n_rays=301)
    P0 = ray_powers(src.generate_rays())
    assert np.allclose(ray_powers(rays), P0, rtol=0, atol=0)        # jamais modifiés
    coll_rays = c["collimator"].trace(src.generate_rays())
    re = restart_rays(coll_rays)
    assert all(r.power == r.parent.power for r in re)


def test_power_conservation_without_clipping():
    """Ouvertures très grandes : aucune perte, P_incident = P_transmis partout,
    puissance transmise = puissance tracée (à l'arrondi près)."""
    src = GaussianFiberSource(wavelength=1e-4, mfd=0.02, n_rays=801)          # theta0 ≈ 3 mrad
    system = OpticalSystem([ThickLens(80.0, -80.0, 8.0, 1.5, aperture=30.0, z_front=40.0),
                            Aperture(100.0, 50.0)])
    rays = system.trace(src.generate_rays())
    rep = surface_power_report(system, rays, src)
    assert all(e.p_lost == 0.0 for e in rep)
    assert all(abs(e.p_incident - e.p_transmitted) == 0.0 for e in rep)
    assert abs(weighted_transmission(rays) - 1.0) < 1e-15


# ========================================================================== #
# Clipping
# ========================================================================== #
def test_clipping_matches_analytic_in_ideal_case():
    # erreur de discrétisation d'un bord dur ∝ 1/N (couronne du rayon de bord
    # entièrement dedans ou dehors) : ~4e-4 à N = 8001 pour a/w = 0.75
    src = GaussianFiberSource(wavelength=1e-4, mfd=0.01, n_rays=8001)          # theta0 = 6.4 mrad
    z_ap = 100.0
    w = z_ap * np.tan(src.theta0)
    for ratio in (0.75, 1.0, 1.5, 2.0):
        system = OpticalSystem([Aperture(z_ap, 2 * ratio * w)])
        rays = system.trace(src.generate_rays())
        e = surface_power_report(system, rays, src)[0]
        assert e.analytic_valid, e.note
        assert abs(e.t_fraction - gaussian_transmission(ratio * w, w)) < 5e-4
        assert abs(e.t_analytic - gaussian_transmission(ratio * w, w)) < 1e-6


def test_analytic_refused_after_truncation():
    src = GaussianFiberSource(wavelength=1e-4, mfd=0.01, n_rays=2001)
    w1 = 100 * np.tan(src.theta0)
    system = OpticalSystem([Aperture(100.0, 2 * 1.0 * w1, name="d1"),
                            Aperture(150.0, 2 * 1.2 * 1.5 * w1, name="d2")])
    rep = surface_power_report(system, system.trace(src.generate_rays()), src)
    assert rep[0].analytic_valid and not rep[1].analytic_valid
    assert "troncature amont" in rep[1].note


def test_clipping_converges_with_ray_number_and_sampling():
    """Ouverture idéale (a = w) : l'erreur diminue avec N, et les deux
    échantillonnages (angle uniforme / puissance égale) convergent vers la même valeur."""
    T_ref = gaussian_transmission(1.0, 1.0)
    errs = {}
    for sampling in ("angle", "power"):
        errs[sampling] = []
        for n in (301, 1201, 4801):
            src = GaussianFiberSource(wavelength=1e-4, mfd=0.01, n_rays=n, sampling=sampling)
            system = OpticalSystem([Aperture(100.0, 2 * 100 * np.tan(src.theta0))])
            T = surface_power_report(system, system.trace(src.generate_rays()), src)[0].t_fraction
            errs[sampling].append(abs(T - T_ref))
        assert errs[sampling][2] < errs[sampling][1] < errs[sampling][0]
        assert errs[sampling][-1] < 5e-4
    # échantillonnage uniforme en angle : erreur ∝ 1/N (bord dur) -> facteur ≈ 4 pour N x 4
    r = np.array(errs["angle"][:-1]) / np.array(errs["angle"][1:])
    assert np.all(np.abs(r - 4) < 0.5), r


def test_real_chain_clipping_converges():
    """Chaîne réelle : la transmission converge (≈ 0,9451) ; trois bords durs ->
    oscillation résiduelle ~1e-4 ; l'échantillonnage en puissance égale est
    quantifié par pas de 1/(N/2)."""
    T = {}
    for sampling in ("angle", "power"):
        for n in (2401, 4801):
            c, src, rays = _real_chain(n_rays=n, sampling=sampling)
            T[(sampling, n)] = weighted_transmission(rays)
    assert abs(T[("angle", 4801)] - T[("angle", 2401)]) < 3e-4
    assert abs(T[("power", 4801)] - T[("power", 2401)]) < 3e-4
    assert abs(T[("angle", 4801)] - T[("power", 4801)]) < 3e-4


def test_blocked_rays_never_reappear():
    c, src, rays = _real_chain(n_rays=801)
    full = c["full"]
    blocked = [r for r in rays if r.status != ALIVE]
    assert blocked
    z_after = c["l2"].z_back + 10
    wf = wavefront(rays, LAM, "plane", z_ref=z_after)
    kept = {id(r) for r in wf.rays}
    for r in blocked:
        assert all(ev.surface is None or ev.surface < r.blocked_at for ev in r.history)
        assert x_at_z(r, z_after) is None
        assert id(r) not in kept
    bs = beam_stats(rays, z_after, src)
    assert bs.n_rays == sum(r.status == ALIVE for r in rays)
    assert abs(bs.power - ray_powers([r for r in rays if r.status == ALIVE]).sum()) < 1e-15


def test_beam_symmetry():
    c, src, rays = _real_chain(n_rays=801)
    bs = beam_stats(rays, c["l2"].z_back + 100, src)
    assert abs(bs.centroid) < 1e-12 and abs(bs.skewness) < 1e-9
    assert abs(bs.r_max_pos - bs.r_max_neg) < 1e-12


# ========================================================================== #
# Front d'onde
# ========================================================================== #
def test_opd_zero_for_ideal_plane_wave():
    system = OpticalSystem([Lens([np.inf, np.inf], [4.0], [1.6], aperture=50, z_front=0.0)])
    src = CollimatedSource(z=-5.0, half_width=8.0, n_rays=41, w=4.0)
    wf = wavefront(system.trace(src.generate_rays()), LAM, "plane", z_ref=20.0)
    assert wf.rms("power") < 1e-12 and wf.pv < 1e-12
    assert abs(wf.strehl_direct() - 1) < 1e-12


def test_opd_zero_for_ideal_spherical_wave():
    # 1. point source en espace libre, sphère centrée sur la source
    src = PointSource(0.0, 0.0, theta_max=np.deg2rad(30), n_rays=61)
    rays = OpticalSystem([Aperture(10.0, 1e3)]).trace(src.generate_rays())
    wf = wavefront(rays, LAM, "sphere", z_ref=50.0, z_center=0.0)
    assert wf.rms("area") < 1e-12 and wf.pv < 1e-12
    # 2. points aplanétiques : image virtuelle exacte, sphère centrée sur elle
    n, r = 1.5, 10.0
    surf = SphericalSurface(0.0, -r, n, 1.0)
    zc = surf.center[1]
    src = PointSource(0.0, zc - r / n, theta_max=np.deg2rad(40), n_rays=81, n=n)
    rays = OpticalSystem([surf]).trace(src.generate_rays())
    wf = wavefront(rays, LAM, "sphere", z_ref=5.0, z_center=zc - n * r)
    assert wf.pv < 1e-9 * LAM / LAM * 1e-3          # < 1 pm
    # la même onde comparée à une sphère mal centrée n'est plus nulle
    wf_bad = wavefront(rays, LAM, "sphere", z_ref=5.0, z_center=zc - n * r + 0.5)
    assert wf_bad.pv > 1e-3


def test_point_source_plane_reference_analytic():
    """Onde sphérique vue sur un plan : OPD(r) = sqrt(L² + r²) - L exactement."""
    src = PointSource(0.0, 0.0, theta_max=np.deg2rad(20), n_rays=41)
    rays = OpticalSystem([Aperture(5.0, 1e3)]).trace(src.generate_rays())
    L = 60.0
    wf = wavefront(rays, LAM, "plane", z_ref=L)
    assert np.allclose(wf.opd, np.sqrt(L**2 + wf.x**2) - L, atol=1e-12)


def test_opd_metrics_invariant_to_constant():
    c, src, rays = _real_chain(n_rays=401)
    wf = wavefront(rays, LAM, "plane", z_ref=c["l2"].z_back + 1)
    shifted = wf.opd + 0.123
    assert abs(wf.rms("power", shifted) - wf.rms("power")) < 1e-15
    assert abs(wf.rms("area", shifted) - wf.rms("area")) < 1e-15
    assert abs(wf.strehl_direct(shifted) - wf.strehl_direct()) < 1e-12
    assert abs(wf.rms_defocus_removed() - wf.rms("power", wf.defocus_fit()[2])) < 1e-15


def test_eikonal_ray_direction_is_opd_gradient():
    """Sur un plan, d(OPL)/dx = n sin(θ) (relation eikonale / Malus-Dupin) :
    cohérence entre OPL et directions des rayons."""
    c, src, rays = _real_chain(n_rays=1601)
    z = c["l2"].z_back + 1
    wf = wavefront(rays, LAM, "plane", z_ref=z)
    side = wf.x > 0
    o = np.argsort(wf.x[side])
    x = wf.x[side][o]
    opl = wf.opl[side][o]
    sin_t = np.array([r.direction[0] for r in np.array(wf.rays, dtype=object)[side][o]])
    grad = np.gradient(opl, x)
    err = np.abs(grad[2:-2] - sin_t[2:-2])
    assert err.max() < 2e-3 * np.abs(sin_t).max()


def test_reverse_propagation_retraces_path_and_opl():
    """Retour inverse de la lumière dans la chaîne réelle : un rayon relancé
    depuis son point d'arrivée, direction opposée, à travers les surfaces en
    ordre inverse, revient à la fibre avec le même chemin optique."""
    c, src, rays = _real_chain(n_rays=101)
    rev = OpticalSystem()
    rev.surfaces = c["full"].surfaces[::-1]
    for r in rays:
        if r.status != ALIVE:
            continue
        start = r.point_at(10.0)                      # 10 mm après la dernière surface
        back = rev.trace(Ray(start, -r.direction, n=r.n))
        assert back.status == ALIVE
        t = -back.z / back.direction[1]               # jusqu'au plan de la fibre z = 0
        end = back.position + t * back.direction
        assert abs(end[0]) < 1e-9
        assert abs((back.opl() + t) - (r.opl() + 10.0)) < 1e-9


def test_strehl_estimators_small_aberration():
    c, src, rays = _real_chain(n_rays=401)
    wf = wavefront(rays, LAM, "plane", z_ref=c["l2"].z_back + 1)
    small = wf.opd * (LAM / 60) / wf.rms("amplitude")      # même forme, σ = λ/60
    assert abs(wf.strehl_direct(small) - wf.strehl_marechal(small)) < 2e-3
    assert abs(wf.strehl_direct(np.zeros_like(wf.opd)) - 1) < 1e-12


if __name__ == "__main__":
    warnings.simplefilter("ignore")
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        setup_function(fn)
        fn()
        print(f"OK  {name}")
    print(f"\n{len(tests)} tests réussis.")
