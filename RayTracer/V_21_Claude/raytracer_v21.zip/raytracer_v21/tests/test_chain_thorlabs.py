"""Tests V1.5 sur la VRAIE chaîne Thorlabs (AC254-040-B-ML, ACN127-030-B, AC254-060-B).

Sautés (SKIP) tant que examples/lens_data.py n'est pas rempli pour les trois
lentilles. Critère de réussite de la V1.5 :
  * faisceau collimaté ≈ 8,5 mm (1/e²) avant le beam expander,
  * beam expander afocal (C ≈ 0) de grandissement ≈ 2,
  * faisceau collimaté ≈ 17 mm après.
Tolérances : 5 % sur les diamètres (la focale réelle du collimateur à 1030 nm
et le MFD réel fixent le diamètre : D = 4 λ f / (π MFD)) ; 2 % sur G (G = -f2/f1
avec les focales réelles à 1030 nm, pas les nominales).
"""

import os
import sys
import warnings

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "examples"))
from optical_sim import beam_profile, clipping_report, paraxial  # noqa: E402
import chain  # noqa: E402
import lens_data  # noqa: E402


class SkipTest(Exception):
    pass


def _require_data():
    chain.FORCE_STANDIN = False
    miss = {k: lens_data.missing_fields(chain.CONFIG[k]) for k in ("collimator", "l1", "l2")}
    miss = {chain.CONFIG[k]: v for k, v in miss.items() if v}
    if miss:
        msg = "données constructeur manquantes : " + "; ".join(f"{k} ({', '.join(v)})" for k, v in miss.items())
        try:
            import pytest
            pytest.skip(msg)
        except ImportError:
            raise SkipTest(msg)


def test_thorlabs_expander_afocal_and_magnification():
    _require_data()
    exp_sys, l1, l2, gap = chain.build_expander(0.0)
    f = chain.expander_figures(exp_sys, l1, l2, gap)
    assert abs(f["C"]) < 1e-12
    assert gap > 0, "séparation sommet-sommet négative : collision"
    assert abs(f["G_paraxial"] - 2.0) / 2.0 < 0.02, f["G_paraxial"]


def test_thorlabs_chain_diameters():
    _require_data()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d_best, _ = chain.best_defocus()
        c = chain.build_chain(d_best)
    src = chain.make_source()
    rays = c["full"].trace(src.generate_rays())
    p = beam_profile(rays, src, [c["l1"].z_front - 1.0, c["l2"].z_back + 1.0])
    assert abs(p.d_1e2[0] - 8.5) / 8.5 < 0.05, p.d_1e2[0]
    assert abs(p.d_1e2[1] - 17.0) / 17.0 < 0.05, p.d_1e2[1]


def test_thorlabs_clipping_not_worse_than_gaussian_reference():
    _require_data()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        c = chain.build_chain(chain.best_defocus()[0])
    src = chain.make_source()
    rep = clipping_report(c["full"], c["full"].trace(src.generate_rays()), src)
    for e in rep.entries:
        if np.isfinite(e.t_analytic):
            assert e.t_rays >= e.t_analytic - 0.01, (e.name, e.t_rays, e.t_analytic)


def setup_function(function):
    """pytest : (ré)impose le choix des lentilles avant chaque test (état partagé du module chain)."""
    chain.FORCE_STANDIN = False


if __name__ == "__main__":
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        try:
            fn()
            print(f"OK    {name}")
        except BaseException as e:                  # SkipTest ou pytest Skipped (BaseException)
            if type(e).__name__ not in ("SkipTest", "Skipped"):
                raise
            print(f"SKIP  {name} : {e}")
