"""Tests V1.5 : source gaussienne, retournement, beam expander afocal, clipping,
cohérence tracé séparé / tracé complet.

Ces tests utilisent des lentilles GÉNÉRIQUES (ThickLens, Lens) ou les
lentilles de substitution de examples/chain.py (focales nominales exactes,
n = 1.5) : ils ne dépendent d'aucune donnée constructeur. Les tests sur les
vraies lentilles Thorlabs sont dans test_chain_thorlabs.py.

Exécution :  python tests/test_chain.py   (ou  pytest tests/)
"""

import os
import sys
import warnings

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "examples"))
from optical_sim import (Lens, ThickLens, Aperture, OpticalSystem, Ray, SphericalSurface,  # noqa: E402
                         GaussianFiberSource, CollimatedSource, paraxial, axis_crossing,
                         beam_profile, clipping_report, gaussian_transmission,
                         output_divergence, restart_rays, x_at_z)
from optical_sim.ray import ALIVE, MISSED  # noqa: E402
import chain  # noqa: E402

chain.FORCE_STANDIN = True


# ========================================================================== #
# Source gaussienne
# ========================================================================== #
def test_gaussian_divergence_from_mfd():
    src = GaussianFiberSource(wavelength=1.030e-3, mfd=6.0e-3, na_nominal=0.5)
    assert np.isclose(src.w0, 3.0e-3)
    assert np.isclose(src.theta0, 1.030e-3 / (np.pi * 3.0e-3))      # = 0.10929 rad
    assert abs(src.theta0 - 0.109286) < 1e-6
    assert src.theta0 != np.arcsin(0.5)                               # la NA n'intervient pas
    assert np.isclose(src.theta_max, 3 * src.theta0)
    w = src.weight([0.0, src.theta0], "cut")
    assert np.isclose(w[1] / w[0], np.exp(-2))                        # 1/e² à theta0


def test_d4sigma_equals_d1e2_for_linear_mapping():
    """Propagation libre, petit theta0 (théta -> x quasi linéaire) :
    D4σ (moments pondérés) et D_1e2 (rayons ±theta0) valent 2 z theta0."""
    src = GaussianFiberSource(wavelength=1e-4, mfd=0.02, n_rays=2001)  # theta0 = 3.2 mrad
    system = OpticalSystem([Aperture(50.0, 1000.0)])
    rays = system.trace(src.generate_rays())
    p = beam_profile(rays, src, [100.0])
    assert abs(p.d_1e2[0] - 2 * 100 * np.tan(src.theta0)) < 1e-9
    assert abs(p.d4sigma[0] / p.d_1e2[0] - 1) < 1e-3


# ========================================================================== #
# Clipping gaussien : rayons pondérés vs formule analytique (cas centré)
# ========================================================================== #
def test_gaussian_clipping_matches_analytic():
    src = GaussianFiberSource(wavelength=1e-4, mfd=0.01, n_rays=4001)  # theta0 = 6.4 mrad
    z_ap = 100.0
    w = z_ap * np.tan(src.theta0)
    for ratio in (0.5, 1.0, 1.5, 2.0):
        a = ratio * w
        system = OpticalSystem([Aperture(z_ap, 2 * a, name="diaphragme")])
        rays = system.trace(src.generate_rays())
        rep = clipping_report(system, rays, src)
        T_ref = gaussian_transmission(a, w)
        assert abs(rep.transmitted - T_ref) < 2e-3, (ratio, rep.transmitted, T_ref)
        assert abs(rep.entries[0].t_analytic - T_ref) < 1e-6        # w mesuré = w attendu
    assert np.isclose(gaussian_transmission(1.0, 1.0), 1 - np.exp(-2))


def test_no_ray_crosses_forbidden_aperture():
    """Aucun rayon transmis ne passe hors ouverture ; tout rayon arrêté l'est
    bien parce que son intersection (ouverture ignorée) tombe hors ouverture."""
    c = chain.build_chain(0.0)
    full = c["full"]
    src = chain.make_source(n_rays=801, theta_factor=4.0)   # assez large pour forcer du clipping
    rays = full.trace(src.generate_rays())
    n_blocked = 0
    for r in rays:
        for ev in r.history:
            if ev.surface is not None:
                s = full.surfaces[ev.surface]
                assert abs(ev.position[0]) <= s.semi_aperture * (1 + 1e-12)
        if r.status == MISSED:
            n_blocked += 1
            s = full.surfaces[r.blocked_at]
            unbounded = SphericalSurface(s.z_vertex, s.R, s.n1, s.n2)   # ouverture max
            t = unbounded.intersect(r.position, r.direction)
            if t is not None:
                assert abs((r.position + t * r.direction)[0]) > s.semi_aperture
    assert n_blocked > 0


# ========================================================================== #
# Retournement d'une lentille
# ========================================================================== #
def test_flipped_lens():
    pres = dict(radii=[45.0, -30.0, -150.0], thicknesses=[6.0, 2.5], n_glasses=[1.62, 1.75])
    a = Lens(**pres, aperture=20.0)
    b = Lens(**pres, aperture=20.0, flip=True)
    assert [s.R for s in b.surfaces] == [150.0, 30.0, -45.0]
    assert [s.n2 for s in b.surfaces] == [1.75, 1.62, 1.0]
    ca, cb = paraxial.cardinal(a.surfaces), paraxial.cardinal(b.surfaces)
    assert abs(ca["EFL"] - cb["EFL"]) < 1e-10
    assert abs(ca["BFD"] - cb["FFD"]) < 1e-10 and abs(ca["FFD"] - cb["BFD"]) < 1e-10
    ray = OpticalSystem([b]).trace(Ray([1e-4, -50.0], [0.0, 1.0]))
    assert abs(axis_crossing(ray) - cb["z_back_focus"]) < 1e-6


# ========================================================================== #
# Beam expander afocal
# ========================================================================== #
def test_afocal_condition_and_magnification_2():
    exp_sys, l1, l2, gap = chain.build_expander(0.0)
    f = chain.expander_figures(exp_sys, l1, l2, gap)
    assert abs(f["C"]) < 1e-12                              # afocal
    assert abs(f["G_paraxial"] - 2.0) < 1e-9                # G = 2
    assert abs(f["G_from_efl"] - 2.0) < 1e-9                # G = -f2/f1
    assert abs(f["A"] * f["D"] - 1.0) < 1e-12               # det = 1 avec C = 0
    # séparation des plans principaux = f1 + f2 = 30 mm, distincte de la séparation des sommets
    assert abs(f["principal_plane_separation"] - 30.0) < 1e-9
    assert abs(gap - 30.0) > 0.5


def test_afocal_gap_thin_lens_limit():
    """Quand les épaisseurs -> 0, la séparation sommet-sommet afocale -> f1 + f2."""
    for t in (2.0, 0.2, 0.02):
        R1 = chain.symmetric_radius_for_efl(-30.0, 1.5, t)
        R2 = chain.symmetric_radius_for_efl(60.0, 1.5, t)
        gap = paraxial.afocal_gap(ThickLens(R1, -R1, t, 1.5), ThickLens(R2, -R2, t, 1.5))
        assert abs(gap - 30.0) < 1.5 * t


def test_afocal_exact_rays_stay_parallel():
    """Rayons // axe en entrée : angle de sortie -> 0 comme h³ (aberration),
    grandissement exact x_out/x_in -> A = 2."""
    exp_sys, l1, l2, gap = chain.build_expander(0.0)
    hs = np.array([2.0, 1.0, 0.5, 0.25, 0.125])
    ang, mag = [], []
    for h in hs:
        r = exp_sys.trace(Ray([h, -10.0], [0.0, 1.0]))
        assert r.status == ALIVE
        ang.append(r.theta)
        mag.append(r.x / h)                 # hauteur au dernier sommet
    ang, mag = np.array(ang), np.array(mag)
    assert np.all(np.abs(ang[:-1] / ang[1:] - 8.0) < 0.3)   # theta_out ∝ h³
    assert abs(ang[-1]) < 1e-5
    assert np.all(np.diff(np.abs(mag - 2.0)) < 0)
    assert abs(mag[-1] - 2.0) < 1e-4


def test_paraxial_direction_conservation():
    """Un rayon d'angle u en entrée de l'afocal ressort avec l'angle D u = u / 2."""
    exp_sys, *_ = chain.build_expander(0.0)
    for u in (1e-4, -2e-4):
        r = exp_sys.trace(Ray([0.0, -10.0], [np.sin(u), np.cos(u)]))
        assert abs(np.tan(r.theta) / np.tan(u) - 0.5) < 1e-6


# ========================================================================== #
# Collimateur
# ========================================================================== #
def test_collimator_at_front_focus():
    """Fibre au foyer objet : rayons de sortie // axe dans la limite paraxiale,
    hauteur de sortie y = f u."""
    sysc, lens = chain.build_collimator(0.0)
    f = paraxial.cardinal(lens.surfaces)["EFL"]
    ratios = []
    for u in (4e-3, 2e-3, 1e-3):
        r = sysc.trace(Ray([0.0, 0.0], [np.sin(u), np.cos(u)]))
        ratios.append(r.theta / u)
        # rayon de sortie // axe : sa hauteur après la lentille vaut f u (paraxial)
        assert abs(r.x / (f * np.tan(u)) - 1) < 1e-4
    ratios = np.abs(ratios)
    assert np.all(np.abs(ratios[:-1] / ratios[1:] - 4.0) < 0.1)        # theta_out/u ∝ u²
    assert ratios[-1] < 1e-4


def test_collimated_diameter_and_expansion():
    """Faisceau gaussien de la fibre : diamètre 1/e² ≈ 2 f theta0 après le
    collimateur, puis ≈ 2 fois plus après l'afocal (lentilles de substitution :
    tolérance large car aberrations de singulets)."""
    c = chain.build_chain(chain.best_defocus()[0])
    src = chain.make_source(n_rays=1201)
    rays = c["full"].trace(src.generate_rays())
    f_coll = paraxial.cardinal(c["coll"].surfaces)["EFL"]
    z1 = c["l1"].z_front - 1.0
    z2 = c["l2"].z_back + 1.0
    p = beam_profile(rays, src, [z1, z2])
    assert abs(p.d_1e2[0] / (2 * f_coll * src.theta0) - 1) < 0.03
    assert abs(p.d_1e2[1] / p.d_1e2[0] - 2.0) < 0.05


# ========================================================================== #
# Cohérence : sous-systèmes tracés séparément vs chaîne complète
# ========================================================================== #
def test_separate_subsystems_equal_full_chain():
    c = chain.build_chain(0.1)
    src = chain.make_source(n_rays=601, theta_factor=3.5)
    full_rays = c["full"].trace(src.generate_rays())
    coll_rays = c["collimator"].trace(src.generate_rays())
    exp_rays = c["expander"].trace(restart_rays(coll_rays))
    by_parent = {id(r.parent): r for r in exp_rays}
    n_compared = 0
    for rf, rc in zip(full_rays, coll_rays):
        if rc.status != ALIVE:                 # arrêté dans le collimateur : idem en chaîne
            assert rf.status != ALIVE and rf.blocked_at == rc.blocked_at
            continue
        re = by_parent[id(rc)]
        assert rf.status == re.status
        if rf.status != ALIVE:
            assert rf.blocked_at == re.blocked_at + len(c["collimator"].surfaces)
            continue
        assert np.allclose(rf.direction, re.direction, atol=1e-12)
        assert np.allclose(rf.position, re.position, atol=1e-9)
        assert abs(rf.opl() - (rc.opl() + re.opl())) < 1e-9
        n_compared += 1
    assert n_compared > 100


def setup_function(function):
    """pytest : (ré)impose le choix des lentilles avant chaque test (état partagé du module chain)."""
    chain.FORCE_STANDIN = True


if __name__ == "__main__":
    warnings.simplefilter("ignore")
    tests = [(k, v) for k, v in dict(globals()).items() if k.startswith("test_") and callable(v)]
    for name, fn in tests:
        fn()
        print(f"OK  {name}")
    print(f"\n{len(tests)} tests réussis.")
