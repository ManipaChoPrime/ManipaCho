"""Visualisation (Matplotlib) : trajectoires, foyer z_f, OPL sur un plan.

Code couleur des rayons : segment dans le premier milieu = "incident"
(bleu), segments suivants = "après réfraction" (rouge). Les milieux
d'indice supérieur au milieu extérieur sont grisés.
"""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from .ray import TIR, MISSED


def _glass_regions(ax, system, h_max):
    """Grise la région entre deux surfaces successives si le milieu y est plus dense."""
    surfs = system.surfaces
    if not surfs:
        return
    n_ext = min(surfs[0].n1, surfs[-1].n2)
    for s1, s2 in zip(surfs[:-1], surfs[1:]):
        n = s1.n2
        if n <= n_ext:
            continue
        h = min(s1.semi_aperture, s2.semi_aperture, h_max)
        xs = np.linspace(-h, h, 200)
        z_poly = np.concatenate([s1.sag(xs), s2.sag(xs[::-1])])
        x_poly = np.concatenate([xs, xs[::-1]])
        shade = 0.12 + 0.25 * min((n - n_ext) / 1.0, 1.0)
        ax.fill(z_poly, x_poly, color="tab:cyan", alpha=shade, lw=0)
        ax.annotate(f"n={n:g}", (0.5 * (s1.z_vertex + s2.z_vertex), 0), ha="center",
                    va="bottom", fontsize=7, color="teal")


def plot_system(system, rays, ax=None, source=None, show_intersections=True,
                plane_half_height=None, title=None, x_lim=None, z_lim=None,
                label_surfaces=True, equal_aspect=True, legend_loc="best",
                label_elements=True, show_legend=True, units="mm"):
    unit_label = f" [{units}]" if units else ""
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 5))

    for ray in rays:
        pts = ray.path()
        for k in range(len(pts) - 1):
            color = "tab:blue" if k == 0 else "tab:red"
            ax.plot(pts[k:k + 2, 1], pts[k:k + 2, 0], color=color, lw=0.7, alpha=0.8)
        if show_intersections and len(pts) > 1:
            surf_pts = np.array([ev.position for ev in ray.history if ev.surface is not None])
            if len(surf_pts):
                ax.plot(surf_pts[:, 1], surf_pts[:, 0], ".", color="k", ms=1.5)
        if ray.status == TIR:
            ax.plot(ray.z, ray.x, "x", color="tab:purple", ms=6, mew=1.5)
        if ray.status == MISSED and getattr(ray, "blocked_point", None) is not None:
            bp = ray.blocked_point
            ax.plot([ray.z, bp[1]], [ray.x, bp[0]], color="0.6", lw=0.6, ls=":")
            ax.plot(bp[1], bp[0], "x", color="0.3", ms=3, mew=0.8)

    all_x = np.concatenate([r.path()[:, 0] for r in rays]) if rays else np.array([1.0])
    default_h = 1.15 * np.max(np.abs(all_x)) if plane_half_height is None else plane_half_height
    if system is not None:
        _glass_regions(ax, system, default_h)
        for i, surf in enumerate(system.surfaces):
            h = min(surf.semi_aperture, default_h)
            xs = np.linspace(-h, h, 400)
            ax.plot(surf.sag(xs), xs, color="k", lw=1.5)
            if label_surfaces:                     # étiquettes alternées bas / haut
                lbl = "plan" if surf.is_plane else f"R={surf.R:g}"
                y = -h if i % 2 == 0 else h
                ax.annotate(lbl, (float(surf.sag(y)), y), textcoords="offset points",
                            xytext=(-8, -11 if i % 2 == 0 else 4), fontsize=7)

        if label_elements:
            for el in system.elements:
                if not el.name:
                    continue
                h = min(el.semi_aperture, default_h)
                ax.annotate(el.name, (0.5 * (el.z_front + el.z_back), h), ha="center",
                            textcoords="offset points", xytext=(0, 12), fontsize=8,
                            fontweight="bold", color="0.25")

    if source is not None and hasattr(source, "x"):
        ax.plot(source.z, source.x, "o", color="gold", mec="k", ms=9, zorder=5)

    ax.axhline(0, color="0.6", lw=0.6, ls="--")
    legend = [
        Line2D([], [], color="tab:blue", label="rayon incident"),
        Line2D([], [], color="tab:red", label="rayon réfracté"),
        Line2D([], [], color="k", lw=1.5, label="surface"),
    ]
    if source is not None and hasattr(source, "x"):
        legend.append(Line2D([], [], marker="o", ls="", color="gold", mec="k", label="source"))
    if any(r.status == TIR for r in rays):
        legend.append(Line2D([], [], marker="x", ls="", color="tab:purple", mew=1.5,
                             label="réflexion totale interne"))
    if any(r.status == MISSED for r in rays):
        legend.append(Line2D([], [], marker="x", ls=":", color="0.4", ms=4,
                             label="rayon coupé par une ouverture"))
    if show_legend:
        ax.legend(handles=legend, loc=legend_loc, fontsize=8)
    ax.set_xlabel(f"z (axe optique){unit_label}")
    ax.set_ylabel(f"x (transverse){unit_label}")
    if equal_aspect:
        ax.set_aspect("equal")
    if x_lim is not None:
        ax.set_ylim(*x_lim)
    if z_lim is not None:
        ax.set_xlim(*z_lim)
    if title:
        has_labels = system is not None and label_elements and any(e.name for e in system.elements)
        ax.set_title(title, pad=16 if has_labels else 6)
    return ax


def plot_rays(rays, system=None, **kw):
    """Trajectoires réelles des rayons (alias de plot_system, système optionnel)."""
    return plot_system(system, rays, **kw)


def plot_focus(focus, ax=None, versus="theta", title=None, **kw):
    """Trace z_f en fonction de theta (deg) ou de x_pupil, avec foyers et LSA.

    `focus` : FocusAnalysis, ou liste de rayons (analyse calculée ici, les
    mots-clés `system` et `source` sont alors transmis à focus_analysis).
    """
    from .analysis import FocusAnalysis, focus_analysis
    if not isinstance(focus, FocusAnalysis):
        focus = focus_analysis(focus, **kw)
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 4.5))

    if versus == "theta":
        xv, xlabel = np.degrees(focus.theta), "angle initial θ (deg)"
    elif versus == "x_pupil":
        xv, xlabel = focus.x_pupil, "hauteur sur la 1re surface x_pupil"
    elif versus == "x_start":
        xv, xlabel = focus.x_start, "hauteur initiale x"
    else:
        raise ValueError("versus ∈ {'theta', 'x_pupil', 'x_start'}")

    real = ~focus.virtual
    ax.plot(xv[real], focus.z_f[real], ".", color="tab:red", ms=4, label="z_f(rayon) — tracé exact")
    if np.any(focus.virtual):
        ax.plot(xv[~real], focus.z_f[~real], ".", color="0.5", ms=4, label="croisement virtuel")
    ax.axhline(focus.z_paraxial, color="tab:green", ls="--",
               label=f"foyer paraxial ({focus.paraxial_source}) {focus.z_paraxial:.5g}")
    ax.axhline(focus.z_marginal, color="tab:orange", ls=":",
               label=f"foyer marginal {focus.z_marginal:.5g}")
    ax.set_xlabel(xlabel)
    ax.set_ylabel("croisement avec l'axe z_f")
    ax.set_title(title or f"Aberration sphérique longitudinale : LSA = {focus.lsa:.4g}")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    return ax


def plot_opl(data, ax=None, versus="x", reference="axis", wavelength=None, title=None):
    """OPL(x) sur le plan commun, relatif à une référence.

    reference : "axis" (rayon de |x| minimal), "min", ou None (OPL absolu).
    wavelength : si donnée (même unité que les longueurs), axe en nombre d'ondes.
    Ce n'est PAS encore une OPD : le plan n'est pas une surface de référence.
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 4.5))
    if versus == "x":
        xv, xlabel = data.x, "x sur le plan"
    elif versus == "x_pupil":
        xv, xlabel = data.x_pupil, "hauteur sur la 1re surface x_pupil"
    elif versus == "theta":
        xv, xlabel = np.degrees(data.theta_initial), "angle initial θ (deg)"
    else:
        raise ValueError("versus ∈ {'x', 'x_pupil', 'theta'}")
    opl = data.opl.copy()
    if reference == "axis":
        ref = opl[np.argmin(np.abs(data.x_pupil if versus == "x_pupil" else data.x))]
        ylabel = "OPL − OPL(axe)"
    elif reference == "min":
        ref = opl.min()
        ylabel = "OPL − min(OPL)"
    else:
        ref, ylabel = 0.0, "OPL"
    y = opl - ref
    if wavelength is not None:
        y = y / wavelength
        ylabel += "  [λ]"
    order = np.argsort(xv)
    ax.plot(xv[order], y[order], "-", color="tab:purple", lw=1)
    ax.plot(xv, y, ".", color="tab:purple", ms=3)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title or f"OPL sur le plan z = {data.z_plane:.5g}")
    ax.grid(alpha=0.3)
    return ax


def plot_beam_profile(profile, ax=None, system=None, title=None, units="mm"):
    """Diamètres D_1e2, D4σ et enveloppe en fonction de z (BeamProfile)."""
    if ax is None:
        _, ax = plt.subplots(figsize=(9, 4))
    ax.plot(profile.z, profile.d_1e2, "-", color="tab:red", lw=1.8, label="D 1/e² (rayons ±θ0)")
    ax.plot(profile.z, profile.d4sigma, "--", color="tab:blue", lw=1.2, label="D4σ (rayons présents, pondérés)")
    ax.plot(profile.z, profile.d_env, ":", color="0.4", lw=1, label="enveloppe des rayons tracés")
    if system is not None:
        for el in system.elements:
            ax.axvspan(el.z_front, el.z_back, color="tab:cyan", alpha=0.25, lw=0)
            ax.plot([el.z_front, el.z_back], [2 * el.semi_aperture] * 2, color="k", lw=3)
            if el.name:
                ax.annotate(el.name, (0.5 * (el.z_front + el.z_back), 2 * el.semi_aperture),
                            textcoords="offset points", xytext=(0, 4), ha="center", fontsize=7)
    ax.set_xlabel(f"z [{units}]")
    ax.set_ylabel(f"diamètre [{units}]")
    ax.set_title(title or "Diamètre du faisceau (traits noirs : ouverture claire)")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    return ax


def plot_divergence(div, ax=None, title=None, angle_unit="µrad", units="mm"):
    """Angle de sortie en fonction de la hauteur du rayon (Divergence)."""
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 4))
    scale = {"rad": 1.0, "mrad": 1e3, "µrad": 1e6}[angle_unit]
    order = np.argsort(div.x)
    ax.plot(div.x[order], div.theta[order] * scale, ".-", color="tab:purple", ms=3, lw=0.8)
    ax.set_xlabel(f"hauteur du rayon [{units}]")
    ax.set_ylabel(f"angle de sortie [{angle_unit}]")
    ax.set_title(title or f"Divergence de sortie : θ_rms = {div.theta_rms * scale:.3g} {angle_unit}")
    ax.grid(alpha=0.3)
    return ax
