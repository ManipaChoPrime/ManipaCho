"""Données constructeur des lentilles Thorlabs utilisées dans les exemples.

>>> FICHIER À REMPLIR <<<   Aucune valeur de rayon, d'épaisseur ou d'indice
n'est fournie ici : elles doivent venir des fiches constructeur (rayons,
épaisseurs au centre, verres) et des indices des verres À LA LONGUEUR D'ONDE
ÉTUDIÉE (ici 1030 nm), par exemple calculés depuis les formules de Sellmeier
du fabricant de verre.

Seules les valeurs déduites de la référence elle-même sont pré-remplies :
    diamètre : AC254 -> Ø25.4 mm, ACN127 -> Ø12.7 mm
    focale nominale : -040 -> 40 mm, -030 -> -30 mm (ACN = négatif), -060 -> 60 mm

Schéma commun (doublets collés, 3 surfaces), convention de la fiche :
la lumière arrive par R1. Rayons en convention "centre de courbure"
(R > 0 : centre vers +z), comme les fiches Thorlabs/Zemax. Unités : mm.

Attention aux ouvertures claires :
  * clear_aperture est le diamètre UTILE (souvent < diamètre mécanique) ;
  * pour une lentille montée (suffixe -ML), la bague de retenue de la monture
    peut limiter l'ouverture : prendre l'ouverture claire de la version montée.
  Si clear_aperture est None, le diamètre mécanique est utilisé et le code
  le signale (hypothèse optimiste).
"""

import warnings

from optical_sim import Lens


def _blank(diameter, efl_nominal):
    return dict(
        R1=None, R2=None, R3=None,      # mm, lumière entrant par R1
        tc1=None, tc2=None,             # mm, épaisseurs au centre
        diameter=diameter,              # mm, diamètre mécanique (déduit de la référence)
        clear_aperture=None,            # mm, diamètre utile (fiche)
        glass1="", glass2="",           # noms des verres (information)
        wavelength_nm=None,             # longueur d'onde des indices ci-dessous
        n1=None, n2=None,               # indices des verres 1 et 2 à wavelength_nm
        efl_nominal=efl_nominal,        # mm, focale nominale (déduite de la référence)
        bfl_nominal=None,               # mm, BFL de la fiche
        spec_wavelength_nm=None,        # longueur d'onde de référence de la fiche
        efl_rel_tolerance=0.01,         # tolérance relative EFL (élargir si λ ≠ λ fiche)
        bfl_abs_tolerance=0.5,          # mm
    )


LENSES = {
    "AC254-040-B-ML": _blank(25.4, 40.0),
    "ACN127-030-B": _blank(12.7, -30.0),
    "AC254-060-B": _blank(25.4, 60.0),
}

REQUIRED = ("R1", "R2", "R3", "tc1", "tc2", "n1", "n2", "wavelength_nm")


def missing_fields(data) -> list:
    if isinstance(data, str):
        data = LENSES[data]
    return [k for k in REQUIRED if data.get(k) is None]


def all_missing() -> dict:
    return {k: missing_fields(v) for k, v in LENSES.items() if missing_fields(v)}


def build_lens(data, flip: bool = False, z_front: float = 0.0, name: str = None,
               expected_wavelength_nm: float = None) -> Lens:
    """Instancie la classe générique Lens à partir d'une entrée de LENSES."""
    key = data if isinstance(data, str) else None
    if key is not None:
        data = LENSES[key]
    miss = missing_fields(data)
    if miss:
        raise ValueError(f"Données {key or ''} incomplètes, champs manquants : {', '.join(miss)}")
    if expected_wavelength_nm is not None and data["wavelength_nm"] != expected_wavelength_nm:
        warnings.warn(f"{key} : indices donnés à {data['wavelength_nm']} nm, "
                      f"simulation à {expected_wavelength_nm} nm.")
    if data["clear_aperture"] is None:
        warnings.warn(f"{key} : ouverture claire non renseignée, diamètre mécanique utilisé.")
    aperture = data["clear_aperture"] or data["diameter"]
    return Lens(radii=[data["R1"], data["R2"], data["R3"]],
                thicknesses=[data["tc1"], data["tc2"]],
                n_glasses=[data["n1"], data["n2"]],
                n_before=1.0, aperture=aperture, z_front=z_front,
                name=name or key or "", flip=flip)
