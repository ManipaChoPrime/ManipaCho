"""Construction de la chaîne fibre -> collimateur -> beam expander de Galilée.

Ce module ne fait qu'ASSEMBLER des objets génériques (Lens, OpticalSystem,
GaussianFiberSource) avec des paramètres. Il ne contient aucune donnée
constructeur : celles-ci sont dans lens_data.py.

LENTILLES DE SUBSTITUTION
-------------------------
Tant que lens_data.py n'est pas rempli, `get_lenses()` renvoie des lentilles
de SUBSTITUTION : singulets équiconvexes / équiconcaves fictifs (n = 1.5),
dont les rayons sont calculés pour avoir EXACTEMENT les focales nominales
(+40, -30, +60 mm) avec les diamètres mécaniques des références. Elles
servent à faire tourner et valider la chaîne ; elles ne représentent PAS les
doublets Thorlabs (aberrations bien plus fortes, plans principaux différents).
Toute sortie produite avec elles est étiquetée "SUBSTITUTION".

GÉOMÉTRIE (unités : mm)
-----------------------
    fibre en z = 0
    collimateur : 1er sommet en z = FFD_coll + defocus
        defocus > 0 : fibre plus loin que le foyer objet -> faisceau convergent
        defocus < 0 : fibre plus près -> faisceau divergent
    L1 (divergente) : 1er sommet à gap_coll_l1 après le dernier sommet du collimateur
    L2 (convergente) : séparation sommet-sommet calculée pour que L1+L2 soit afocal
"""

from __future__ import annotations

import os
import sys
import warnings

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

from optical_sim import Lens, ThickLens, OpticalSystem, GaussianFiberSource, paraxial  # noqa: E402
import lens_data  # noqa: E402

# ---------------------------------------------------------------------------
# Paramètres de la chaîne (hypothèses : voir rapport)
# ---------------------------------------------------------------------------
CONFIG = dict(
    wavelength=1.030e-3,          # mm (1030 nm)
    mfd=6.0e-3,                   # mm (MFD = 6 µm -> w0 = 3 µm), hypothèse utilisateur
    na_nominal=None,              # NA de la fibre (information seulement, non utilisée)
    n_rays=1201,
    theta_factor=3.0,             # rayons tracés jusqu'à 3 theta0
    collimator="AC254-040-B-ML",
    l1="ACN127-030-B",
    l2="AC254-060-B",
    # Orientation (flip=True : la dernière surface de la fiche fait face à la source).
    # Règle usuelle pour un achromat : la face la plus courbée (R1 de la fiche)
    # du côté du faisceau collimaté. Collimateur et L2 ont le faisceau collimaté
    # en SORTIE -> retournés. L1 reçoit le faisceau collimaté -> sens de la fiche.
    # HYPOTHÈSES À CONFIRMER.
    flip_collimator=True,
    flip_l1=False,
    flip_l2=True,
    gap_coll_l1=50.0,             # mm, collimateur (dernier sommet) -> L1 (1er sommet)
    target_d_collimated=8.5,      # mm, diamètre 1/e² visé avant le beam expander
    target_magnification=2.0,
)

FORCE_STANDIN = False      # True : substitution même si les données sont remplies (tests)
STANDIN_N = 1.5
STANDIN_THICKNESS = {"AC254-040-B-ML": 5.0, "ACN127-030-B": 2.0, "AC254-060-B": 4.0}


def symmetric_radius_for_efl(efl: float, n: float, t: float) -> float:
    """Rayon R d'une lentille symétrique (R, -R) d'épaisseur t et d'indice n
    dans l'air ayant la focale efl, en résolvant exactement la formule de
    Gullstrand  1/f = (n-1)[2c - (n-1) t c² / n],  c = 1/R."""
    a, b = (n - 1) ** 2 * t / n, 2 * (n - 1)
    c = (b - np.sqrt(b * b - 4 * a / efl)) / (2 * a)
    return 1.0 / c


def standin_lens(key: str, z_front: float = 0.0) -> ThickLens:
    d = lens_data.LENSES[key]
    t = STANDIN_THICKNESS[key]
    R = symmetric_radius_for_efl(d["efl_nominal"], STANDIN_N, t)
    return ThickLens(R, -R, t, STANDIN_N, aperture=d["clear_aperture"] or d["diameter"],
                     z_front=z_front, name=f"{key} [SUBSTITUTION]")


def using_standins() -> bool:
    return FORCE_STANDIN or bool(any(lens_data.missing_fields(CONFIG[k])
                                     for k in ("collimator", "l1", "l2")))


def make_lens(role: str, z_front: float = 0.0):
    key = CONFIG[role]
    if FORCE_STANDIN or lens_data.missing_fields(key):
        return standin_lens(key, z_front)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return lens_data.build_lens(key, flip=CONFIG[f"flip_{role}"], z_front=z_front,
                                    expected_wavelength_nm=CONFIG["wavelength"] * 1e6)


def make_source(n_rays=None, theta_factor=None) -> GaussianFiberSource:
    return GaussianFiberSource(x=0.0, z=0.0, wavelength=CONFIG["wavelength"], mfd=CONFIG["mfd"],
                               n_rays=n_rays or CONFIG["n_rays"],
                               theta_factor=theta_factor or CONFIG["theta_factor"],
                               na_nominal=CONFIG["na_nominal"])


# ---------------------------------------------------------------------------
# Sous-systèmes
# ---------------------------------------------------------------------------
def build_collimator(defocus: float = 0.0):
    """Collimateur placé pour que la fibre (z = 0) soit à FFD + defocus du 1er sommet."""
    probe = make_lens("collimator", 0.0)
    ffd = paraxial.cardinal(probe.surfaces)["FFD"]
    lens = make_lens("collimator", ffd + defocus)
    return OpticalSystem([lens]), lens


def build_expander(z_front_l1: float):
    """L1 au z donné, L2 placée à la séparation afocale (matrices + géométrie réelle)."""
    l1 = make_lens("l1", z_front_l1)
    l2_probe = make_lens("l2", 0.0)
    gap = paraxial.afocal_gap(l1, l2_probe)
    l2 = make_lens("l2", l1.z_back + gap)
    if gap <= 0:
        warnings.warn(f"Séparation afocale sommet-sommet négative ({gap:.3f} mm) : "
                      "collision mécanique des lentilles.")
    return OpticalSystem([l1, l2]), l1, l2, gap


def build_chain(defocus: float = 0.0, gap_coll_l1: float = None):
    gap_coll_l1 = CONFIG["gap_coll_l1"] if gap_coll_l1 is None else gap_coll_l1
    coll_sys, coll = build_collimator(defocus)
    exp_sys, l1, l2, gap = build_expander(coll.z_back + gap_coll_l1)
    full = OpticalSystem([coll, l1, l2])
    return dict(full=full, collimator=coll_sys, expander=exp_sys,
                coll=coll, l1=l1, l2=l2, afocal_gap=gap, defocus=defocus)


def expander_figures(exp_sys, l1, l2, gap) -> dict:
    """Grandeurs paraxiales du beam expander."""
    M = paraxial.system_matrix(exp_sys.surfaces)
    c1, c2 = paraxial.cardinal(l1.surfaces), paraxial.cardinal(l2.surfaces)
    return dict(
        matrix=M, A=M[0, 0], C=M[1, 0], D=M[1, 1],
        G_paraxial=M[0, 0],
        G_from_efl=-c2["EFL"] / c1["EFL"],
        afocal_gap_vertex=gap,
        principal_plane_separation=c2["z_H_object"] - c1["z_H_image"],   # doit valoir f1 + f2
        f1=c1["EFL"], f2=c2["EFL"],
    )


# ---------------------------------------------------------------------------
# Analyses du collimateur
# ---------------------------------------------------------------------------
def collimator_divergence(defocus: float, source=None, z_offset: float = 1.0):
    """Divergence rms (poids gaussiens "cut") en sortie du collimateur pour un defocus donné."""
    from optical_sim import output_divergence
    source = source or make_source()
    sysc, lens = build_collimator(defocus)
    rays = sysc.trace(source.generate_rays())
    return output_divergence(rays, lens.z_back + z_offset, source), rays, sysc, lens


def chain_divergence(defocus: float, source=None, z_offset: float = 1.0):
    """Divergence rms (poids "cut") en sortie de la chaîne complète."""
    from optical_sim import output_divergence
    source = source or make_source()
    c = build_chain(defocus)
    rays = c["full"].trace(source.generate_rays())
    return output_divergence(rays, c["l2"].z_back + z_offset, source), rays, c


def best_defocus(source=None, span: float = 0.5, n: int = 41, target: str = "collimator"):
    """Defocus minimisant la divergence rms géométrique en sortie du collimateur
    (target="collimator") ou de la chaîne complète (target="chain").

    Avec des aberrations, la meilleure collimation (au sens rms pondéré) n'est
    pas exactement au foyer paraxial. Recherche par balayage puis raffinement
    parabolique ; renvoie (defocus, theta_rms).
    """
    source = source or make_source(n_rays=401)
    f = collimator_divergence if target == "collimator" else chain_divergence
    center = 0.0
    for _ in range(8):                       # recentre la fenêtre tant que le min est au bord
        ds = center + np.linspace(-span, span, n)
        rms = np.array([f(d, source)[0].theta_rms for d in ds])
        i = int(np.argmin(rms))
        if 0 < i < n - 1:
            break
        center = ds[i]
    # raffinement : fenêtre resserrée autour du minimum
    ds = np.linspace(ds[i - 1], ds[i + 1], n)
    rms = np.array([f(d, source)[0].theta_rms for d in ds])
    i = int(np.clip(np.argmin(rms), 1, n - 2))
    a, b, c = np.polyfit(ds[i - 1:i + 2], rms[i - 1:i + 2], 2)
    d_best = -b / (2 * a) if a > 0 else ds[i]
    return float(d_best), float(f(d_best, source)[0].theta_rms)
