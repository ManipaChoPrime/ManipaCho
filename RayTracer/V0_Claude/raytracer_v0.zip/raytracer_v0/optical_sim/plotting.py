"""Visualisation (Matplotlib) des surfaces et des rayons.

Code couleur : un segment est coloré selon le milieu dans lequel il se
propage (premier milieu = "incident", milieux suivants = "réfracté").
"""

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from .ray import TIR, MISSED


def plot_system(system, rays, ax=None, source=None, show_intersections=True,
                plane_half_height=None, title=None, x_lim=None, z_lim=None):
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 5))

    # --- Rayons ----------------------------------------------------------
    for ray in rays:
        pts = ray.path()
        for k in range(len(pts) - 1):
            color = "tab:blue" if k == 0 else "tab:red"
            ax.plot(pts[k:k + 2, 1], pts[k:k + 2, 0], color=color, lw=0.8, alpha=0.8)
        if show_intersections and len(pts) > 1:
            surf_pts = np.array([ev.position for ev in ray.history if ev.surface is not None])
            if len(surf_pts):
                ax.plot(surf_pts[:, 1], surf_pts[:, 0], ".", color="k", ms=2)
        if ray.status == TIR:
            ax.plot(ray.z, ray.x, "x", color="tab:purple", ms=6, mew=1.5)

    # --- Surfaces --------------------------------------------------------
    all_x = np.concatenate([r.path()[:, 0] for r in rays]) if rays else np.array([1.0])
    default_h = 1.15 * np.max(np.abs(all_x)) if plane_half_height is None else plane_half_height
    for surf in system.surfaces:
        h = min(surf.semi_aperture, default_h)
        xs = np.linspace(-h, h, 400)
        ax.plot(surf.sag(xs), xs, color="k", lw=2)
        lbl = "plan" if surf.is_plane else f"R = {surf.R:g}"
        ax.annotate(f"{surf.name or lbl}\nn: {surf.n1:g} | {surf.n2:g}",
                    (float(surf.sag(-h)), -h), textcoords="offset points", xytext=(5, 2), fontsize=8)

    # --- Source ------------------------------------------------------------
    if source is not None:
        ax.plot(source.z, source.x, "o", color="gold", mec="k", ms=9, zorder=5)

    # --- Mise en forme -----------------------------------------------------
    ax.axhline(0, color="0.6", lw=0.6, ls="--")
    legend = [
        Line2D([], [], color="tab:blue", label="rayon incident"),
        Line2D([], [], color="tab:red", label="rayon réfracté"),
        Line2D([], [], color="k", lw=2, label="surface"),
    ]
    if source is not None:
        legend.append(Line2D([], [], marker="o", ls="", color="gold", mec="k", label="source"))
    if any(r.status == TIR for r in rays):
        legend.append(Line2D([], [], marker="x", ls="", color="tab:purple", mew=1.5,
                             label="réflexion totale interne"))
    if any(r.status == MISSED for r in rays):
        legend.append(Line2D([], [], color="none", label="(rayons hors ouverture arrêtés)"))
    ax.legend(handles=legend, loc="best", fontsize=8)
    ax.set_xlabel("z (axe optique)")
    ax.set_ylabel("x (transverse)")
    ax.set_aspect("equal")
    if x_lim is not None:
        ax.set_ylim(*x_lim)
    if z_lim is not None:
        ax.set_xlim(*z_lim)
    if title:
        ax.set_title(title)
    return ax
