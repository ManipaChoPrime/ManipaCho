"""optical_sim — petit ray tracer 2D non-paraxial (plan x-z), version V0.

CONVENTIONS GLOBALES (utilisées partout dans le package)
--------------------------------------------------------
* Repère : z = axe optique, x = coordonnée transverse.
* Tous les vecteurs 2D sont des tableaux NumPy dans l'ordre (x, z).
* Une direction de rayon est toujours un vecteur unitaire (dx, dz).
* Angle d'un rayon : theta mesuré depuis +z, positif vers +x,
  donc direction = (sin theta, cos theta).
* Surface sphérique : sommet en z_vertex sur l'axe, rayon de courbure R
  (convention de signe "centre de courbure") :
      R > 0 : centre en z_vertex + R, situé vers +z (surface convexe vue de -z)
      R < 0 : centre situé vers -z (surface concave vue de -z)
      R = inf : surface plane
* Indices : chaque surface porte n1 (milieu côté -z) et n2 (milieu côté +z).
  Un rayon qui traverse vers +z passe de n1 à n2 ; dans l'autre sens, de n2 à n1.
* Unités de longueur : arbitraires mais cohérentes (par ex. mm).
"""

from .ray import Ray, RayEvent
from .refraction import refract, RefractionResult
from .surface import SphericalSurface
from .system import OpticalSystem
from .source import PointSource
from .plotting import plot_system

__all__ = [
    "Ray",
    "RayEvent",
    "refract",
    "RefractionResult",
    "SphericalSurface",
    "OpticalSystem",
    "PointSource",
    "plot_system",
]
