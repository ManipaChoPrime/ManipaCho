"""Système optique : liste ordonnée de surfaces, traversées séquentiellement.

V0 = tracé SÉQUENTIEL : le rayon rencontre les surfaces dans l'ordre de la
liste (comme dans un logiciel de conception optique classique). Ce n'est
pas un tracé "non séquentiel" où l'on chercherait la surface la plus proche.
"""

from __future__ import annotations

from typing import Optional
import warnings

import numpy as np

from .ray import Ray, MISSED, TIR, ALIVE
from .surface import SphericalSurface


class OpticalSystem:
    def __init__(self, surfaces: Optional[list] = None):
        self.surfaces: list[SphericalSurface] = list(surfaces or [])

    def add(self, surface: SphericalSurface) -> "OpticalSystem":
        self.surfaces.append(surface)
        return self

    def trace(self, ray: Ray, z_final: Optional[float] = None) -> Ray:
        """Propage `ray` à travers toutes les surfaces (modifie le rayon en place).

        À chaque surface :
          1. intersection exacte -> distance t (None : rayon perdu, statut MISSED)
          2. propagation rectiligne de t dans le milieu courant
          3. réfraction vectorielle ; en cas de réflexion totale, statut TIR et arrêt
        Si `z_final` est donné, les rayons survivants sont ensuite propagés
        jusqu'au plan z = z_final (s'il est devant eux).

        L'historique (ray.history) contient pour chaque étape : position,
        direction, indice, distance parcourue sur le segment, surface rencontrée.
        """
        for i, surf in enumerate(self.surfaces):
            if not ray.alive:
                break
            t = surf.intersect(ray.position, ray.direction)
            if t is None:
                ray.status = MISSED
                ray.history[-1].status = MISSED
                break

            ray.propagate(t, surface=i)
            result, n_in, n_out = surf.refract(ray.direction, ray.position)

            if not np.isclose(n_in, ray.n):
                warnings.warn(
                    f"Surface {i} : le rayon arrive avec n = {ray.n} mais la "
                    f"surface attend n = {n_in} de ce côté. Vérifier la "
                    f"cohérence des indices entre surfaces successives."
                )

            if result.transmitted:
                ray.update_after_surface(result.direction, n_out, ALIVE)
            else:
                # Réflexion totale interne : le rayon s'arrête au point d'incidence.
                ray.update_after_surface(None, n_in, TIR)
                break

        if z_final is not None and ray.alive:
            dz = ray.direction[1]
            if abs(dz) > 1e-15 and (z_final - ray.z) / dz > 0:
                ray.propagate_to_z(z_final)
        return ray

    def trace_all(self, rays, z_final: Optional[float] = None) -> list:
        return [self.trace(r, z_final=z_final) for r in rays]
