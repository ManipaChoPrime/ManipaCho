"""Source ponctuelle : un éventail de rayons issus d'un même point."""

from __future__ import annotations

import numpy as np

from .ray import Ray


class PointSource:
    """Source ponctuelle en (x, z), dans un milieu d'indice n.

    Les angles sont mesurés depuis l'axe +z, positifs vers +x :
        direction = (sin theta, cos theta)
    et uniformément répartis dans [theta_center - theta_max, theta_center + theta_max].
    (Pour un éventail vers -z, prendre theta_center = pi.)
    """

    def __init__(self, x: float = 0.0, z: float = 0.0, theta_max: float = np.deg2rad(10),
                 n_rays: int = 101, n: float = 1.0, theta_center: float = 0.0):
        self.x = float(x)
        self.z = float(z)
        self.theta_max = float(theta_max)
        self.n_rays = int(n_rays)
        self.n = float(n)
        self.theta_center = float(theta_center)

    @property
    def position(self) -> np.ndarray:
        return np.array([self.x, self.z])

    def angles(self) -> np.ndarray:
        if self.n_rays == 1:
            return np.array([self.theta_center])
        return self.theta_center + np.linspace(-self.theta_max, self.theta_max, self.n_rays)

    def generate_rays(self) -> list[Ray]:
        return [Ray(self.position, (np.sin(th), np.cos(th)), n=self.n) for th in self.angles()]
